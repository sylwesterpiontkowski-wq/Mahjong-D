package pl.mahjong.d;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Color;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle state) { super.onCreate(state); setContentView(new Board(this)); }

    static class Tile { int kind; boolean removed; Tile(int k) { kind=k; } }
    class Board extends View {
        final Paint p = new Paint(3);
        final List<Tile> tiles = new ArrayList<>();
        int first = -1, pairs = 16, moves = 0;
        String message = "Wybierz dwie takie same płytki";
        float tileW, tileH, startX, startY, gap;
        Board(Activity a) { super(a); setBackgroundColor(Color.rgb(16, 100, 76)); newGame(); }
        void newGame() {
            tiles.clear(); List<Integer> kinds = new ArrayList<>();
            for (int i=0;i<16;i++) { kinds.add(i); kinds.add(i); }
            Collections.shuffle(kinds);
            for (int k : kinds) tiles.add(new Tile(k));
            first=-1; pairs=16; moves=0; message="Wybierz dwie takie same płytki"; invalidate();
        }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c); float w=getWidth(), h=getHeight();
            p.setColor(Color.rgb(16,100,76)); c.drawRect(0,0,w,h,p);
            p.setColor(Color.WHITE); p.setTextAlign(Paint.Align.CENTER); p.setTextSize(Math.min(w*.055f,42));
            c.drawText("MAHJONG D", w/2, h*.07f,p);
            p.setTextSize(Math.min(w*.035f,27)); c.drawText("Pary: "+(16-pairs)+"/16     Ruchy: "+moves,w/2,h*.115f,p);
            c.drawText(message,w/2,h*.16f,p);
            int cols=8, rows=4; gap=w*.012f; tileW=(w-gap*(cols+1))/cols; tileH=Math.min(tileW*1.35f,h*.135f);
            float boardH=rows*tileH+(rows-1)*gap; startX=gap; startY=Math.max(h*.21f,(h+boardH)*.5f-boardH*.5f);
            String[] symbols={"一","二","三","四","五","六","七","八","九","東","南","西","北","中","發","白"};
            for(int i=0;i<tiles.size();i++) { Tile t=tiles.get(i); if(t.removed) continue;
                int row=i/cols,col=i%cols; float x=startX+col*(tileW+gap), y=startY+row*(tileH+gap);
                p.setColor(i==first?Color.rgb(255,214,90):Color.rgb(248,239,210));
                c.drawRoundRect(new RectF(x,y,x+tileW,y+tileH),8,8,p);
                p.setColor(Color.rgb(96,64,35)); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2); c.drawRoundRect(new RectF(x+3,y+3,x+tileW-3,y+tileH-3),6,6,p); p.setStyle(Paint.Style.FILL);
                p.setColor(t.kind==12?Color.RED:(t.kind==14?Color.rgb(20,130,65):Color.rgb(35,54,74)));
                p.setTextSize(Math.min(tileW*.55f,44)); c.drawText(symbols[t.kind],x+tileW/2,y+tileH*.62f,p);
            }
            float by=h*.91f, bw=w*.42f; p.setColor(Color.rgb(248,239,210)); c.drawRoundRect(new RectF(w*.06f,by-bw*.22f,w*.06f+bw,by+bw*.02f),14,14,p); c.drawRoundRect(new RectF(w*.52f,by-bw*.22f,w*.94f,by+bw*.02f),14,14,p);
            p.setColor(Color.rgb(40,55,45)); p.setTextSize(Math.min(w*.042f,32)); c.drawText("Nowa gra",w*.27f,by,p); c.drawText("Cofnij wybór",w*.73f,by,p);
        }
        @Override public boolean onTouchEvent(MotionEvent e) {
            if(e.getAction()!=MotionEvent.ACTION_UP) return true; float x=e.getX(),y=e.getY(),h=getHeight(),w=getWidth();
            if(y>h*.86f) { if(x<w*.5f) newGame(); else {first=-1;message="Wybierz dwie takie same płytki";invalidate();} return true; }
            int cols=8; for(int i=0;i<tiles.size();i++) { Tile t=tiles.get(i); if(t.removed) continue; int row=i/cols,col=i%cols;
                float l=startX+col*(tileW+gap), top=startY+row*(tileH+gap);
                if(x>=l&&x<=l+tileW&&y>=top&&y<=top+tileH) {
                    if(first<0) {first=i;message="Teraz wybierz drugą płytkę";}
                    else if(first==i) {first=-1;message="Wybierz dwie takie same płytki";}
                    else {moves++; if(tiles.get(first).kind==t.kind) {tiles.get(first).removed=true;t.removed=true;pairs--;message=pairs==0?"Wygrana! Świetna gra!":"Dobra para! Wybierz kolejne płytki";} else message="To nie para. Spróbuj ponownie"; first=-1;}
                    invalidate(); return true;
                }
            } return true;
        }
    }
}
