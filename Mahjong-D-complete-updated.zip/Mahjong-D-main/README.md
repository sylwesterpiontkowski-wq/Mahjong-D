# Mahjong-D

Klasyczna gra w dopasowywanie płytek Mahjong na Androida. Działa offline, bez reklam i bez dodatkowych uprawnień.

## Budowanie APK

Repozytorium zawiera kompletny projekt Android/Gradle. GitHub Actions automatycznie buduje APK po wypchnięciu zmian do gałęzi `main` lub po ręcznym uruchomieniu workflow `Build Mahjong-D APK`.

Gotowy plik można pobrać z sekcji **Actions → zakończony przebieg → Artifacts → Mahjong-D-debug-apk**.
