MAHJONG D — WZORY REFERENCYJNE

Zestaw zawiera planszę poglądową oraz osobne wycinki wszystkich 22 wzorów pokazanych na planszy: 18 wzorów kotowatych (Rudy i Kot 2 po 3; tygrys, lampart, pantera śnieżna i lew po 3) oraz 4 wzory dodatków (2 miseczki i 2 kłębki wełny). Każdy wzór jest pokazany jako para.

WAŻNE: to zasoby graficzne referencyjne do projektu, nie twierdzenie, że wszystkie wzory zostały już wpięte do renderera gry. Przed użyciem w grze należy przygotować czyste grafiki pojedynczych kafelków i podłączyć je w kodzie.

- Rudy_1: Rudy_1.png (wzór poglądowy; para pokazana na grafice).
- Rudy_2: Rudy_2.png (wzór poglądowy; para pokazana na grafice).
- Rudy_3: Rudy_3.png (wzór poglądowy; para pokazana na grafice).
- Kot_2_1: Kot_2_1.png (wzór poglądowy; para pokazana na grafice).
- Kot_2_2: Kot_2_2.png (wzór poglądowy; para pokazana na grafice).
- Kot_2_3: Kot_2_3.png (wzór poglądowy; para pokazana na grafice).
- Tygrys_1: Tygrys_1.png (wzór poglądowy; para pokazana na grafice).
- Tygrys_2: Tygrys_2.png (wzór poglądowy; para pokazana na grafice).
- Tygrys_3: Tygrys_3.png (wzór poglądowy; para pokazana na grafice).
- Lampart_1: Lampart_1.png (wzór poglądowy; para pokazana na grafice).
- Lampart_2: Lampart_2.png (wzór poglądowy; para pokazana na grafice).
- Lampart_3: Lampart_3.png (wzór poglądowy; para pokazana na grafice).
- Pantera_sniezna_1: Pantera_sniezna_1.png (wzór poglądowy; para pokazana na grafice).
- Pantera_sniezna_2: Pantera_sniezna_2.png (wzór poglądowy; para pokazana na grafice).
- Pantera_sniezna_3: Pantera_sniezna_3.png (wzór poglądowy; para pokazana na grafice).
- Lew_1: Lew_1.png (wzór poglądowy; para pokazana na grafice).
- Lew_2: Lew_2.png (wzór poglądowy; para pokazana na grafice).
- Lew_3: Lew_3.png (wzór poglądowy; para pokazana na grafice).
- Miseczka_jedzenie_1: Miseczka_jedzenie_1.png (wzór poglądowy; para pokazana na grafice).
- Miseczka_jedzenie_2: Miseczka_jedzenie_2.png (wzór poglądowy; para pokazana na grafice).
- Klebek_welny_1: Klebek_welny_1.png (wzór poglądowy; para pokazana na grafice).
- Klebek_welny_2: Klebek_welny_2.png (wzór poglądowy; para pokazana na grafice).
