# Mahjong D — pakiet z wizualizacjami

To archiwum zachowuje bazowy projekt Android z poprzedniego pakietu oraz dodaje dokumentację wizualną ustaleń.

## Co zawiera
- `app/src/main/assets/cat_rudy.jpg` — zdjęcie Rudego używane jako zasób gry.
- `app/src/main/assets/cat_nr2.jpg` — zdjęcie kota nr 2 używane jako zasób gry.
- `docs/wizualizacje-zaakceptowane/1000024018.jpg` i `1000024019.jpg` — zrzuty rozmowy zawierające wcześniej uzgodnione wizualizacje kafelków i ekranów.
- Pozostałe pliki PNG w tym katalogu są planszami poglądowymi, a nie gotowymi, osobnymi sprite'ami do bezpośredniego użycia.

## Ustalenia wizualne do zachowania
- Rudy: 3 wzory, każdy w parze (6 kafelków).
- Kot nr 2: 3 wzory, każdy w parze (6 kafelków).
- Wielkie koty: tygrys, lew, lampart, pantera śnieżna.
- Kafelki specjalne: łapka, kłębek wełny, ryba, miska, roślina, latarnia, bambus, kwiat, kamienie i góra.
- Tradycyjne symbole mahjonga pozostają w zestawie.
- Kremowe, zaokrąglone kafelki, zielona plansza i delikatne zdobienia roślinne.
- Przyciski: Nowa gra, Cofnij, Podpowiedź, Pauza i Poziom.
- Gra offline, bez reklam.

## Ważne — zakres weryfikacji
To jest pakiet źródłowy z dokumentacją wizualną. Nie oznacza to, że wszystkie motywy z plans poglądowych zostały już wycięte na osobne pliki graficzne i zintegrowane z kodem gry. Kompilacja APK nie została wykonana w ramach przygotowania tego archiwum.
