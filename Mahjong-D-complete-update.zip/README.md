# Mahjong D — wersja z grafikami kotów

Projekt Android (Java), bez reklam i bez uprawnień sieciowych. Zawiera zdjęcia dwóch kotów z materiałów przekazanych w projekcie, kafelki z symbolami mahjonga oraz przyciski: Nowa gra, Cofnij, Podpowiedź, Pauza i Poziom.

## Budowanie APK
Repozytorium zawiera workflow GitHub Actions `.github/workflows/build-apk.yml`. Po wgraniu plików do repozytorium uruchom **Actions → Build Mahjong-D APK → Run workflow**. Gotowy APK będzie w artefaktach uruchomienia.

## Ważne
To archiwum zawiera kompletny projekt źródłowy. Nie zawiera gotowego APK ani Gradle Wrappera; workflow instaluje Gradle w środowisku GitHub Actions.
