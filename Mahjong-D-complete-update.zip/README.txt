Mahjong D — poprawka grafiki i układu
- Projekt Android w Kotlin DSL: build.gradle.kts, settings.gradle.kts, app/build.gradle.kts.
- Kafelki zwierząt są ilustracjami w kremowo-złotej oprawie, nie zdjęciami.
- Grafiki kafelków zwierzęcych są rysowane jako pełne kafelki; usunięto nakładanie ich na drugi, wewnętrzny medalion.
- Zmniejszono przesunięcie warstw, aby ograniczyć przypadkowe zasłanianie ilustracji.
- Zestaw obejmuje Rudy/Kot 2, tygrysa, lwa, leoparda i irbisa oraz symbole mahjonga.
- Rudy 3 tymczasowo wykorzystuje ilustrację Rudy 2, ponieważ wcześniejszy zasób opisany jako Rudy 3 przedstawiał lwa.
- APK nie jest dołączone; kompilację należy zweryfikować w GitHub Actions.

Poprawka dostępności: kafelek wyższej warstwy blokuje tylko kafelek bezpośrednio pod nim (ta sama kolumna i rząd), nie sąsiednie kafelki. Wolny bok sprawdzany jest przez bezpośrednich sąsiadów w tym samym rzędzie.

Audyt kodu: poprawiono geometrię planszy. Wcześniej pozycje kafelków przy krawędzi były dociskane (clampowane) do granicy, przez co różne kolumny mogły nakładać się na ten sam obszar ekranu, mimo że logika dostępności traktowała je jako odrębne pola. Teraz odstęp i przesunięcie warstw są wyliczane tak, aby kafelki mieściły się w planszy bez dociskania do krawędzi.
