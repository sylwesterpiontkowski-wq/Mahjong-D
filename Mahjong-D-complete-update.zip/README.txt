Mahjong D — etap grafiki zwierząt
- Projekt Android używa Kotlin DSL: build.gradle.kts, settings.gradle.kts, app/build.gradle.kts.
- Kafelki mają kremowo-złotą oprawę; grafiki zwierząt są ilustracjami, nie zdjęciami.
- Zestaw zwierząt: Rudy (3 warianty), Kot 2 (3 warianty), tygrys, lew, leopard i irbis (śnieżny leopard).
- Każdy typ występuje jako identyczna para w grze.
- Archiwum nie zawiera gotowego APK; kompilację trzeba sprawdzić w GitHub Actions.
