Mahjong D — pakiet projektu Android (wersja poprawionego układu)

Zawartość:
- app/src/main/java/pl/mahjong/d/MainActivity.java
- pliki Gradle i manifest Androida

Budowanie:
Projekt wymaga JDK 17 i Gradle 8.9 lub zgodnego środowiska Android Gradle Plugin.
W GitHub Actions należy rozpakować archiwum w katalogu repozytorium i uruchomić:
gradle --no-daemon assembleDebug

Uwaga:
To pakiet bazowy z poprawionym kodem planszy, a nie pełna kopia wcześniejszego projektu z ilustracjami kotów i dodatkowymi zasobami. Nie został jeszcze skompilowany ani przetestowany na urządzeniu.
