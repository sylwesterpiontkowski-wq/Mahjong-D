Mahjong D — poprawka grafiki i układu
- Projekt Android w Kotlin DSL: build.gradle.kts, settings.gradle.kts, app/build.gradle.kts.
- Kafelki zwierząt są ilustracjami w kremowo-złotej oprawie, nie zdjęciami.
- Grafiki kafelków zwierzęcych są rysowane jako pełne kafelki; usunięto nakładanie ich na drugi, wewnętrzny medalion.
- Zmniejszono przesunięcie warstw, aby ograniczyć przypadkowe zasłanianie ilustracji.
- Zestaw obejmuje Rudy/Kot 2, tygrysa, lwa, leoparda i irbisa oraz symbole mahjonga.
- Rudy 3 tymczasowo wykorzystuje ilustrację Rudy 2, ponieważ wcześniejszy zasób opisany jako Rudy 3 przedstawiał lwa.
- APK nie jest dołączone; kompilację należy zweryfikować w GitHub Actions.
