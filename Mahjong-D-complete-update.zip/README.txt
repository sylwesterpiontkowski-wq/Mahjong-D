Mahjong D — poprawka grafiki i układu
- Projekt Android w Kotlin DSL: build.gradle.kts, settings.gradle.kts, app/build.gradle.kts.
- Kafelki zwierząt są ilustracjami w kremowo-złotej oprawie, nie zdjęciami.
- Grafiki kafelków zwierzęcych są rysowane jako pełne kafelki; usunięto nakładanie ich na drugi, wewnętrzny medalion.
- Zmniejszono przesunięcie warstw, aby ograniczyć przypadkowe zasłanianie ilustracji.
- Zestaw obejmuje Rudy/Kot 2, tygrysa, lwa, leoparda i irbisa oraz symbole mahjonga.
- Rudy 3 tymczasowo wykorzystuje ilustrację Rudy 2, ponieważ wcześniejszy zasób opisany jako Rudy 3 przedstawiał lwa.
- APK nie jest dołączone; kompilację należy zweryfikować w GitHub Actions.

Poprawka dostępności: kafelek wyższej warstwy blokuje tylko kafelek bezpośrednio pod nim (ta sama kolumna i rząd), nie sąsiednie kafelki. Wolny bok sprawdzany jest przez bezpośrednich sąsiadów w tym samym rzędzie.

Audyt kodu: poprawiono geometrię planszy. Wcześniej pozycje kafelków przy krawędzi były dociskane (clampowane) do granicy, przez co różne kolumny mogły nakładać się na ten sam obszar ekranu, mimo że logika dostępności traktowała je jako odrębne pola. Teraz odstęp i przesunięcie warstw są wyliczane tak, aby kafelki mieściły się w planszy bez dociskania do krawędzi.

Poprawka par w schowku: logika dopasowania korzysta z sameTileType; obejmuje identyczne ID i tymczasowo łączy ID 17/18, ponieważ obecne grafiki Rudy 2 i Rudy 3 są takie same. Podpowiedź i sprawdzanie pełnego schowka korzystają z tej samej reguły.
\nInterfejs: usunięto „Wybierz poziom” z ekranu pauzy. Pauza służy wyłącznie wznowieniu bieżącej partii; wybór poziomu dostępny jest po naciśnięciu „Nowa gra” na ekranie głównym.\n\nPoprawka obsługi par: tapnięcie dostępnego kafelka, który pasuje do typu już znajdującego się w schowku, od razu usuwa parę. Przeciąganie nadal służy do wkładania do schowka kafelków, które nie mają jeszcze pary.\n
Poprawka hit-testu: dotyk kafelka zablokowanego nie przerywa już wyszukiwania. Program sprawdza dalej kafelki leżące pod palcem w kolejności odwrotnej do rysowania i wybiera pierwszy dostępny. Dzięki temu nakładający się kafelek zablokowany nie przechwytuje dotyku na odsłoniętym fragmencie dostępnego kafelka.
\nPoprawka dopasowania widocznych ilustracji: sześć ID domowych kotów (16–21) jest traktowanych jako jedna rodzina dopasowania, ponieważ obecny zestaw ilustracji ma powtórzone/niedokładnie przypisane pozy. Symbole mahjonga oraz gatunki dzikich kotów nadal wymagają dokładnego dopasowania ID. To rozwiązanie tymczasowe do czasu uporządkowania unikalnych grafik i ich identyfikatorów.\n
Korekta po audycie: usunięto tymczasowe łączenie ID domowych kotów. Każdy identyfikator jest osobnym typem; para, podpowiedź i sprawdzanie schowka wymagają dokładnej zgodności ID.

Aktualizacja dostępności: doprecyzowano regułę wolnego boku, dodano kontrolę zakresu indeksu i czyszczenie prostokątów dotyku w każdej klatce rysowania. Ma to wyeliminować stare obszary dotyku po usunięciu/ukryciu kafelków oraz przypadkowe blokowanie przez sąsiednie warstwy.
