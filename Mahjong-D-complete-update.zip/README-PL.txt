Mahjong D — pakiet aktualizacji roboczej

Zawartość projektu:
- kompletny projekt Androida do budowania APK przez GitHub Actions;
- sześć plików PNG kafelków: po trzy warianty każdego z dwóch wskazanych kotów;
- sterowanie przeciąganiem: samo dotknięcie nie przenosi kafelka; kafelek trafia do schowka po przeciągnięciu i puszczeniu nad schowkiem;
- podstawowe funkcje: poziomy trudności, cofanie, podpowiedź, pauza i zapis stanu;
- folder docs/referencje-graficzne zawiera zaakceptowane makiety koncepcyjne jako materiały referencyjne.

WAŻNE:
Makiety z folderu docs są referencjami projektowymi, nie kompletnymi, osobnymi grafikami wszystkich kafelków i ekranów w aplikacji. W tej wersji aplikacja renderuje klasyczne symbole tekstowo, a sześć ilustracji kotów jako bitmapy. Nie są jeszcze wdrożone osobne ilustracje tygrysów, lwów, lampartów, panter śnieżnych ani pełna makieta przycisków.

Weryfikacja:
W pliku MainActivity.java poprawiono dwa błędy kompilacji dotyczące symbols.length. Pakiet nie został skompilowany w tym środowisku ani przetestowany na urządzeniu. Po przesłaniu do GitHub Actions należy sprawdzić kompilację i działanie APK.
