Mahjong D — kompletny projekt Android

Projekt zawiera:
- app/src/main/java/pl/mahjong/d/MainActivity.java
- app/src/main/AndroidManifest.xml
- app/build.gradle.kts
- pliki Gradle projektu
- .github/workflows/build-apk.yml

Workflow buduje APK bez pliku gradlew, używając Gradle 8.9 i JDK 17.
Aby workflow zadziałał w repozytorium, plik ZIP musi być w repozytorium pod nazwą
Mahjong-D-complete-update.zip, a workflow z tego pakietu musi być zapisany jako
.github/workflows/build-apk.yml.

Uwaga: sam upload ZIP-a do GitHuba nie rozpakowuje go automatycznie. Workflow
rozpakowuje archiwum w trakcie budowania. Przed instalacją APK trzeba potwierdzić,
że GitHub Actions zakończył się sukcesem.
