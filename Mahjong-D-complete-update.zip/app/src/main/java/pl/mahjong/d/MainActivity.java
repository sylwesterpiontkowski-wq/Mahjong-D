package pl.mahjong.d;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Color;
import android.graphics.RectF;
import android.graphics.LinearGradient;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.Path;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class MainActivity extends Activity {
    private Board board;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        board = new Board();
        setContentView(board);
        board.restoreSavedGame();
    }

    @Override protected void onPause() {
        if (board != null) board.saveGame();
        super.onPause();
    }

    static class Tile {
        int kind, layer, col, row;
        boolean removed;
        Tile(int kind, int layer, int col, int row) {
            this.kind = kind; this.layer = layer; this.col = col; this.row = row;
        }
    }

    class Board extends View {
        static final int MAX_UNDOS = 5, RACK_SIZE = 5;
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        final ArrayList<Tile> tiles = new ArrayList<>();
        final ArrayList<Integer> rack = new ArrayList<>();
        final ArrayList<String> history = new ArrayList<>();
        final SharedPreferences prefs = getSharedPreferences("mahjong_d_save", MODE_PRIVATE);
        final Random random = new Random();
        final String[] symbols = {"一","二","三","四","五","六","七","八","九","東","南","西","北","中","發","白"};
        final int TOTAL_TILE_KINDS = 26;
        final int cream = Color.rgb(250, 242, 218);
        final int ink = Color.rgb(49, 54, 45);
        final int green = Color.rgb(17, 96, 73);
        final int wood = Color.rgb(65, 38, 25);
        final int gold = Color.rgb(190, 145, 66);
        final Bitmap[] animalTiles = new Bitmap[] {
            BitmapFactory.decodeResource(getResources(), R.drawable.rudy_illustration_1),
            BitmapFactory.decodeResource(getResources(), R.drawable.rudy_illustration_2),
            BitmapFactory.decodeResource(getResources(), R.drawable.rudy_illustration_3),
            BitmapFactory.decodeResource(getResources(), R.drawable.kot2_illustration_1),
            BitmapFactory.decodeResource(getResources(), R.drawable.kot2_illustration_2),
            BitmapFactory.decodeResource(getResources(), R.drawable.kot2_illustration_3),
            BitmapFactory.decodeResource(getResources(), R.drawable.tiger_illustration),
            BitmapFactory.decodeResource(getResources(), R.drawable.lion_illustration),
            BitmapFactory.decodeResource(getResources(), R.drawable.leopard_illustration),
            BitmapFactory.decodeResource(getResources(), R.drawable.snowleopard_illustration)
        };
        final int[] animalKinds = {16,17,18,19,20,21,22,23,24,25};

        int difficulty = 1, undosLeft = MAX_UNDOS, moves = 0, pairsRemoved = 0;
        boolean paused = false, won = false, difficultyMenu = false;
        int hintA = -1, hintB = -1;
        String message = "Wybierz dwie takie same płytki";

        float headerBottom, rackTop, rackBottom, boardLeft, boardTop, boardRight, boardBottom;
        float tileW, tileH, gap, controlTop;
        final float[][] tileRects = new float[64][4];
        final float[][] buttonRects = new float[5][4];
        final float[][] modalRects = new float[3][4];
        int dragIndex = -1, selectedTile = -1;
        float downX, downY, dragX, dragY, dragOffsetX, dragOffsetY;
        boolean dragging = false;
        final float[] rackRect = new float[4];

        Board() { super(MainActivity.this); setLayerType(View.LAYER_TYPE_SOFTWARE, null); newGame(1); }

        void newGame(int level) {
            difficulty = Math.max(0, Math.min(2, level));
            tiles.clear(); rack.clear(); history.clear();
            undosLeft = MAX_UNDOS; moves = 0; pairsRemoved = 0;
            paused = false; won = false; difficultyMenu = false; hintA = hintB = -1;
            ArrayList<int[]> positions = makeLayout(difficulty);
            ArrayList<Integer> pairKinds = new ArrayList<>();
            // Keep all agreed animal categories represented at every difficulty.
            for (int k = 16; k <= 25 && pairKinds.size() < positions.size()/2; k++) pairKinds.add(k);
            // Fill remaining pairs with traditional Mahjong characters; repeat only when a layout needs more pairs.
            for (int k = 0; pairKinds.size() < positions.size()/2; k++) pairKinds.add(k % symbols.length);
            Collections.shuffle(pairKinds, random);
            ArrayList<Integer> kinds = new ArrayList<>();
            for (int k : pairKinds) { kinds.add(k); kinds.add(k); }
            Collections.shuffle(kinds, random);
            for (int i = 0; i < positions.size(); i++) {
                int[] q = positions.get(i);
                tiles.add(new Tile(kinds.get(i), q[0], q[1], q[2]));
            }
            message = "Wybierz dostępną płytkę";
            saveGame(); invalidate();
        }

        ArrayList<int[]> makeLayout(int level) {
            ArrayList<int[]> out = new ArrayList<>();
            if (level == 0) {
                for (int r=0;r<4;r++) for (int c=0;c<6;c++) out.add(new int[]{0,c+1,r+1});
            } else if (level == 1) {
                // 28 base tiles plus 8 raised tiles = 36 tiles / 18 pairs.
                for (int r=0;r<4;r++) for (int c=0;c<8;c++) {
                    if ((r==0 || r==3) && (c==0 || c==7)) continue;
                    out.add(new int[]{0,c,r});
                }
                for (int r=1;r<=2;r++) for (int c=2;c<=5;c++) out.add(new int[]{1,c,r});
            } else {
                for (int r=0;r<4;r++) for (int c=0;c<8;c++) out.add(new int[]{0,c,r});
                for (int r=1;r<=2;r++) for (int c=1;c<=6;c++) out.add(new int[]{1,c,r});
                for (int r=1;r<=2;r++) for (int c=3;c<=4;c++) out.add(new int[]{2,c,r});
            }
            // All layouts must contain an even number of tiles.
            if ((out.size() & 1) != 0) out.remove(out.size()-1);
            return out;
        }

        boolean isAvailable(int index) {
            Tile t = tiles.get(index);
            if (t.removed) return false;
            boolean covered = false, left = false, right = false;
            for (int j=0;j<tiles.size();j++) {
                if (j==index) continue;
                Tile o=tiles.get(j);
                if (o.removed) continue;
                // A raised tile covers only the tile directly beneath it, not all surrounding cells.
                if (o.layer>t.layer && o.col==t.col && o.row==t.row) covered=true;
                if (o.layer==t.layer && o.row==t.row && o.col==t.col-1) left=true;
                if (o.layer==t.layer && o.row==t.row && o.col==t.col+1) right=true;
            }
            return !covered && (!left || !right);
        }

        String stateJson() {
            try {
                JSONObject root=new JSONObject();
                root.put("version",2);
                root.put("difficulty",difficulty); root.put("undosLeft",undosLeft);
                root.put("moves",moves); root.put("pairsRemoved",pairsRemoved);
                root.put("paused",paused); root.put("won",won); root.put("message",message);
                JSONArray ts=new JSONArray();
                for(Tile t:tiles) {
                    JSONObject o=new JSONObject();
                    o.put("kind",t.kind); o.put("layer",t.layer); o.put("col",t.col);
                    o.put("row",t.row); o.put("removed",t.removed); ts.put(o);
                }
                root.put("tiles",ts);
                JSONArray rs=new JSONArray(); for(int k:rack) rs.put(k); root.put("rack",rs);
                JSONArray hs=new JSONArray(); for(String s:history) hs.put(s); root.put("history",hs);
                return root.toString();
            } catch(Exception e) { return ""; }
        }

        void saveGame() {
            if (!tiles.isEmpty()) prefs.edit().putString("state",stateJson()).apply();
        }

        void restoreSavedGame() {
            String saved=prefs.getString("state","");
            if(saved.isEmpty()) { invalidate(); return; }
            try {
                JSONObject root=new JSONObject(saved);
                int savedVersion=root.optInt("version",0);
                if(savedVersion < 2) {
                    int savedDifficulty=Math.max(0,Math.min(2,root.optInt("difficulty",1)));
                    newGame(savedDifficulty);
                    message="Nowy układ — poprawiono identyfikatory kafelków";
                    return;
                }
                tiles.clear(); rack.clear(); history.clear();
                difficulty=root.optInt("difficulty",1);
                undosLeft=root.optInt("undosLeft",MAX_UNDOS);
                moves=root.optInt("moves",0); pairsRemoved=root.optInt("pairsRemoved",0);
                paused=root.optBoolean("paused",false); won=root.optBoolean("won",false);
                message=root.optString("message","Wybierz dostępną płytkę");
                JSONArray ts=root.getJSONArray("tiles");
                for(int i=0;i<ts.length();i++) {
                    JSONObject o=ts.getJSONObject(i);
                    Tile t=new Tile(o.getInt("kind"),o.getInt("layer"),o.getInt("col"),o.getInt("row"));
                    t.removed=o.optBoolean("removed",false); tiles.add(t);
                }
                JSONArray rs=root.optJSONArray("rack");
                if(rs!=null) for(int i=0;i<rs.length();i++) rack.add(rs.getInt(i));
                JSONArray hs=root.optJSONArray("history");
                if(hs!=null) for(int i=0;i<hs.length();i++) history.add(hs.getString(i));
            } catch(Exception e) { newGame(1); }
            invalidate();
        }

        void saveUndo() {
            history.add(stateJsonWithoutHistory());
            if(history.size()>MAX_UNDOS) history.remove(0);
        }

        String stateJsonWithoutHistory() {
            ArrayList<String> old = new ArrayList<>(history);
            history.clear();
            String s=stateJson();
            history.addAll(old);
            return s;
        }

        void undo() {
            if(undosLeft<=0 || history.isEmpty()) { message="Brak dostepnego cofniecia"; invalidate(); return; }
            String s=history.remove(history.size()-1);
            try {
                JSONObject root=new JSONObject(s);
                tiles.clear(); rack.clear();
                difficulty=root.optInt("difficulty",difficulty);
                moves=root.optInt("moves",moves); pairsRemoved=root.optInt("pairsRemoved",pairsRemoved);
                JSONArray ts=root.getJSONArray("tiles");
                for(int i=0;i<ts.length();i++) {
                    JSONObject o=ts.getJSONObject(i);
                    Tile t=new Tile(o.getInt("kind"),o.getInt("layer"),o.getInt("col"),o.getInt("row"));
                    t.removed=o.optBoolean("removed",false); tiles.add(t);
                }
                JSONArray rs=root.optJSONArray("rack");
                if(rs!=null) for(int i=0;i<rs.length();i++) rack.add(rs.getInt(i));
                undosLeft--; won=false; paused=false; hintA=hintB=-1;
                message="Cofnieto ostatni ruch";
            } catch(Exception e) { message="Nie udało się cofnac ruchu"; }
            saveGame(); invalidate();
        }

        void pick(int i) {
            if(i<0 || i>=tiles.size() || !isAvailable(i) || paused || won) return;
            int kind=tiles.get(i).kind;
            boolean canMatchRack=false;
            for(int rackKind : rack) if(sameTileType(rackKind,kind)) { canMatchRack=true; break; }
            if(rack.size()>=RACK_SIZE && !canMatchRack) {
                message="Schowek pelny — cofnij ruch"; invalidate(); return;
            }
            saveUndo();
            tiles.get(i).removed=true; moves++;
            int match=-1;
            for(int r=0;r<rack.size();r++) {
                if(sameTileType(rack.get(r),kind)) { match=r; break; }
            }
            if(match>=0) {
                rack.remove(match);
                pairsRemoved++;
                message="Para usunięta";
            } else {
                rack.add(kind);
                message="Płytka trafiła do schowka";
            }
            hintA=hintB=-1;
            boolean any=false; for(Tile t:tiles) if(!t.removed) { any=true; break; }
            if(!any) { won=true; message="WYGRANA! Wszystkie plytki usuniete."; }
            else if(rack.size()==RACK_SIZE) message="Schowek pelny — dopasuj plytke lub cofnij";
            saveGame(); invalidate();
        }

        boolean sameTileType(int a, int b) {
            if(a==b) return true;
            // Rudy 3 currently reuses Rudy 2 artwork. Treat these IDs as the same type
            // until the dedicated third illustration is added, so visually matching tiles pair.
            return (a==17 && b==18) || (a==18 && b==17);
        }

        void hint() {
            hintA=hintB=-1;
            for(int i=0;i<tiles.size();i++) if(isAvailable(i))
                for(int j=i+1;j<tiles.size();j++)
                    if(isAvailable(j) && sameTileType(tiles.get(i).kind,tiles.get(j).kind)) {
                        hintA=i; hintB=j; message="Podswietlono pasujaca pare"; invalidate(); return;
                    }
            message="Nie widze teraz pasujacej pary"; invalidate();
        }

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            float w=getWidth(), h=getHeight();
            p.setStyle(Paint.Style.FILL);
            p.setShader(new LinearGradient(0,0,w,h,Color.rgb(8,48,37),Color.rgb(29,104,72),Shader.TileMode.CLAMP));
            c.drawRect(0,0,w,h,p); p.setShader(null);
            headerBottom=h*.135f;
            p.setShader(new LinearGradient(0,0,0,headerBottom,Color.rgb(103,63,37),Color.rgb(39,23,17),Shader.TileMode.CLAMP));
            c.drawRect(0,0,w,headerBottom,p); p.setShader(null);
            p.setColor(gold); c.drawRect(0,headerBottom-2,w,headerBottom,p);
            p.setShader(new LinearGradient(0,h*.86f,0,h,Color.rgb(48,30,22),Color.rgb(18,29,23),Shader.TileMode.CLAMP));
            c.drawRect(0,h*.86f,w,h,p); p.setShader(null);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1f); p.setColor(Color.argb(28,238,211,154));
            for(int k=0;k<7;k++){ float cx=(k+.5f)*w/7f, cy=h*.56f; c.drawCircle(cx,cy,Math.min(w,h)*.12f,p); c.drawCircle(cx,cy,Math.min(w,h)*.105f,p); }
            p.setStyle(Paint.Style.FILL);
            // Gold corner ornaments, thin double borders and walnut rail highlights.
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1.3f); p.setColor(Color.argb(185,201,157,82));
            c.drawRect(3,3,w-3,h*.13f-3,p);
            c.drawRect(3,h*.86f+3,w-3,h-3,p);
            c.drawRect(4,h*.13f+4,w-4,h*.86f-4,p);
            float corner=Math.min(w,h)*.035f;
            for(int sx=0;sx<2;sx++) for(int sy=0;sy<2;sy++) {
                float xx=sx==0?9:w-9, yy=sy==0?h*.145f:h*.845f;
                c.drawLine(xx,yy,xx+(sx==0?corner:-corner),yy,p);
                c.drawLine(xx,yy,xx,yy+(sy==0?corner:-corner),p);
                c.drawCircle(xx+(sx==0?corner*.45f:-corner*.45f),yy+(sy==0?corner*.45f:-corner*.45f),Math.max(1.5f,w*.003f),p);
            }
            p.setStyle(Paint.Style.FILL);

            p.setColor(cream); p.setTextAlign(Paint.Align.LEFT); p.setFakeBoldText(true);
            p.setTextSize(Math.min(w*.061f,42)); c.drawText("Mahjong D",w*.04f,h*.065f,p);
            p.setFakeBoldText(false); p.setTextAlign(Paint.Align.RIGHT);
            p.setTextSize(Math.min(w*.031f,22));
            c.drawText(difficultyName(),w*.96f,h*.052f,p);
            c.drawText("Pary: "+pairsRemoved+"/"+(tiles.size()/2)+"   Ruchy: "+moves,w*.96f,h*.102f,p);

            // Rack is anchored to the top of the playing field, never over the board.
            float rackW=w*.84f, rackX=(w-rackW)/2f;
            rackTop=h*.155f; rackBottom=h*.255f;
            rackRect[0]=rackX; rackRect[1]=rackTop; rackRect[2]=rackX+rackW; rackRect[3]=rackBottom;
            p.setColor(Color.rgb(103,65,37));
            c.drawRoundRect(new RectF(rackX,rackTop,rackX+rackW,rackBottom),12,12,p);
            float slotW=rackW/5f;
            for(int s=0;s<5;s++) {
                float l=rackX+s*slotW+3, t=rackTop+3, r=l+slotW-6, b=rackBottom-3;
                p.setColor(Color.rgb(37,28,21)); c.drawRoundRect(new RectF(l,t,r,b),7,7,p);
                if(s<rack.size()) drawTileFace(c,l+2,t+2,slotW-10,b-t-4,rack.get(s),false);
            }
            p.setTextAlign(Paint.Align.CENTER); p.setColor(cream);
            p.setTextSize(Math.min(w*.029f,20));
            c.drawText("Schowek "+rack.size()+"/5",w/2f,h*.285f,p);

            // Responsive board: tile rectangles are computed once and reused for hit testing.
            boardLeft=w*.035f; boardRight=w*.965f;
            boardTop=h*.315f; boardBottom=h*.805f;
            float usableW=boardRight-boardLeft, usableH=boardBottom-boardTop;
            tileW=Math.min(usableW/8.25f, usableH/5.7f);
            tileH=Math.min(tileW*1.20f, usableH/5.7f);
            gapX(usableW,tileW);
            for(int i=0;i<tileRects.length;i++) { tileRects[i][0]=-1; tileRects[i][1]=-1; tileRects[i][2]=-1; tileRects[i][3]=-1; }

            // Keep every layer inside the board without clamping. Clamping made edge tiles
            // from different columns share the same screen rectangle while availability used
            // their original grid coordinates — the source of false blocked/free tiles.
            float layerOffsetX=tileW*.08f, layerOffsetY=tileH*.07f;
            float stepX=(usableW-tileW-2f*layerOffsetX)/7.0f;
            float stepY=(usableH-tileH-2f*layerOffsetY)/3.0f;
            for(int layer=0;layer<3;layer++) for(int i=0;i<tiles.size();i++) {
                Tile t=tiles.get(i);
                if(t.removed || t.layer!=layer || (dragging && i==dragIndex)) continue;
                float x=boardLeft+layerOffsetX+t.col*stepX+(layer-1)*layerOffsetX;
                float y=boardTop+t.row*stepY+layer*layerOffsetY;
                tileRects[i][0]=x; tileRects[i][1]=y; tileRects[i][2]=x+tileW; tileRects[i][3]=y+tileH;
                boolean available=isAvailable(i);
                if(i==hintA || i==hintB) {
                    p.setColor(Color.rgb(255,216,105));
                    c.drawRoundRect(new RectF(x-4,y-4,x+tileW+4,y+tileH+4),9,9,p);
                }
                drawTileFace(c,x,y,tileW,tileH,t.kind,!available);
            }

            if(dragging && dragIndex>=0 && dragIndex<tiles.size()) {
                p.setColor(Color.argb(75,0,0,0));
                c.drawRoundRect(new RectF(dragX+4,dragY+5,dragX+tileW+4,dragY+tileH+5),8,8,p);
                drawTileFace(c,dragX,dragY,tileW,tileH,tiles.get(dragIndex).kind,false);
            }
            if(selectedTile>=0 && selectedTile<tiles.size() && !tiles.get(selectedTile).removed && !dragging) {
                float[] sr=tileRects[selectedTile];
                if(sr[0]>=0) { p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(3f); p.setColor(Color.rgb(255,211,105)); c.drawRoundRect(new RectF(sr[0]-3,sr[1]-3,sr[2]+3,sr[3]+3),8,8,p); p.setStyle(Paint.Style.FILL); }
            }
            controlTop=h*.875f;
            float left=w*.025f, right=w*.975f, bw=(right-left)/4f;
            String[] labels={"Cofnij ("+undosLeft+")","Nowa gra","Podpowiedź","Pauza"};
            for(int i=0;i<4;i++) {
                setRect(buttonRects[i],left+i*bw+3,controlTop,right-(3*bw)+i*bw-3,h*.945f);
                drawButton(c,buttonRects[i],labels[i]);
            }
            p.setColor(cream); p.setTextAlign(Paint.Align.CENTER); p.setTextSize(Math.min(w*.027f,18));
            c.drawText(message,w/2f,h*.975f,p);
            if(paused || won || difficultyMenu) drawOverlay(c,w,h);
        }

        // Kept separate to make the responsive sizing calculation explicit.
        void gapX(float usableW,float tw) { gap=Math.max(2f,(usableW-8*tw)/7f); }

        void drawTileFace(Canvas c,float x,float y,float tw,float th,int kind,boolean dim) {
            float rad=Math.max(5f,tw*.09f);
            p.setStyle(Paint.Style.FILL); p.setShader(null); p.setColor(Color.argb(dim?22:58,0,0,0));
            c.drawRoundRect(new RectF(x+tw*.055f,y+th*.045f,x+tw+tw*.055f,y+th+th*.045f),rad,rad,p);
            p.setShader(new LinearGradient(x,y,x+tw,y+th,dim?Color.rgb(202,195,175):Color.rgb(255,251,235),dim?Color.rgb(176,166,143):Color.rgb(229,213,175),Shader.TileMode.CLAMP));
            c.drawRoundRect(new RectF(x,y,x+tw,y+th),rad,rad,p); p.setShader(null);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(Math.max(1f,tw*.026f)); p.setColor(dim?Color.rgb(142,128,101):gold);
            c.drawRoundRect(new RectF(x+tw*.045f,y+th*.025f,x+tw*.955f,y+th*.975f),rad*.72f,rad*.72f,p);
            p.setStrokeWidth(Math.max(.7f,tw*.009f)); p.setColor(Color.rgb(224,193,127));
            c.drawRoundRect(new RectF(x+tw*.09f,y+th*.065f,x+tw*.91f,y+th*.935f),rad*.55f,rad*.55f,p);
            p.setStyle(Paint.Style.FILL); p.setColor(gold); float dot=Math.max(1f,tw*.023f);
            c.drawCircle(x+tw*.13f,y+th*.11f,dot,p); c.drawCircle(x+tw*.87f,y+th*.11f,dot,p); c.drawCircle(x+tw*.13f,y+th*.89f,dot,p); c.drawCircle(x+tw*.87f,y+th*.89f,dot,p);
            float cx=x+tw/2f, cy=y+th*.49f, rr=Math.min(tw,th)*.31f;
            p.setShader(new RadialGradient(cx-rr*.25f,cy-rr*.3f,rr,new int[]{Color.rgb(255,255,246),Color.rgb(244,229,194),Color.rgb(218,193,143)},null,Shader.TileMode.CLAMP));
            c.drawCircle(cx,cy,rr,p); p.setShader(null); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(Math.max(1f,tw*.018f)); p.setColor(Color.argb(190,151,112,55)); c.drawCircle(cx,cy,rr,p); p.setStyle(Paint.Style.FILL);
            int animalIndex = -1;
            for (int ai=0; ai<animalKinds.length; ai++) if (animalKinds[ai] == kind) { animalIndex=ai; break; }
            if(animalIndex >= 0) {
                Bitmap art=animalTiles[animalIndex];
                // Place the animal illustration inside the ceramic tile, leaving its own outer gold frame visible.
                p.setStyle(Paint.Style.FILL);
                p.setShader(null);
                RectF dst=new RectF(x+tw*.115f,y+th*.105f,x+tw*.885f,y+th*.865f);
                int save=c.save();
                Path clip=new Path();
                clip.addRoundRect(dst,Math.max(2f,rad*.45f),Math.max(2f,rad*.45f),Path.Direction.CW);
                c.clipPath(clip);
                c.drawBitmap(art,null,dst,p);
                c.restoreToCount(save);
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(Math.max(.8f,tw*.014f));
                p.setColor(Color.rgb(164,113,51));
                c.drawRoundRect(dst,Math.max(2f,rad*.45f),Math.max(2f,rad*.45f),p);
                p.setStyle(Paint.Style.FILL);
            }
            else {
                int[] inks={Color.rgb(37,105,69),Color.rgb(37,105,69),Color.rgb(37,105,69),Color.rgb(37,105,69),Color.rgb(37,105,69),Color.rgb(37,105,69),Color.rgb(37,105,69),Color.rgb(37,105,69),Color.rgb(37,105,69),Color.rgb(37,105,69),Color.rgb(37,105,69),Color.rgb(37,105,69),Color.rgb(37,105,69),Color.rgb(164,43,37),Color.rgb(35,112,67),Color.rgb(42,54,48)};
                p.setColor(dim?Color.rgb(103,102,88):inks[kind%symbols.length]); p.setTextAlign(Paint.Align.CENTER); p.setFakeBoldText(true); p.setTextSize(Math.min(tw*.53f,th*.43f)); c.drawText(symbols[kind%symbols.length],cx,y+th*.61f,p); p.setFakeBoldText(false);
                p.setColor(Color.argb(dim?70:145,151,112,55)); p.setStrokeWidth(Math.max(1f,tw*.012f)); c.drawLine(x+tw*.29f,y+th*.79f,x+tw*.71f,y+th*.79f,p); c.drawCircle(cx,y+th*.79f,Math.max(1f,tw*.018f),p);
            }
        }

        void drawCat(Canvas c,float cx,float cy,float r,int kind,boolean dim) {
            boolean ginger=kind<=12; int fur=dim?Color.rgb(145,135,115):(ginger?Color.rgb(202,112,48):Color.rgb(79,83,78));
            int light=dim?Color.rgb(190,181,160):(ginger?Color.rgb(246,195,124):Color.rgb(224,222,206)); int dark=ginger?Color.rgb(106,55,28):Color.rgb(43,47,44);
            float hy=cy-r*.02f, hr=r*.60f; p.setStyle(Paint.Style.FILL); p.setColor(fur);
            Path ear=new Path(); ear.moveTo(cx-hr*.72f,hy-hr*.35f); ear.lineTo(cx-hr*.82f,hy-hr*1.08f); ear.lineTo(cx-hr*.18f,hy-hr*.65f); ear.close(); c.drawPath(ear,p);
            ear.reset(); ear.moveTo(cx+hr*.72f,hy-hr*.35f); ear.lineTo(cx+hr*.82f,hy-hr*1.08f); ear.lineTo(cx+hr*.18f,hy-hr*.65f); ear.close(); c.drawPath(ear,p);
            p.setColor(fur); c.drawCircle(cx,hy,hr*.76f,p); p.setColor(light); c.drawOval(new RectF(cx-hr*.43f,hy+hr*.05f,cx+hr*.43f,hy+hr*.63f),p);
            p.setColor(dark); float ey=hy-hr*.04f, er=Math.max(1.1f,r*.055f); c.drawCircle(cx-hr*.29f,ey,er,p); c.drawCircle(cx+hr*.29f,ey,er,p);
            p.setColor(ginger?Color.rgb(176,83,75):Color.rgb(194,133,143)); Path nose=new Path(); nose.moveTo(cx,hy+hr*.17f); nose.lineTo(cx-hr*.11f,hy+hr*.27f); nose.lineTo(cx+hr*.11f,hy+hr*.27f); nose.close(); c.drawPath(nose,p);
            p.setColor(dark); p.setStrokeWidth(Math.max(1f,r*.025f)); c.drawLine(cx,hy+hr*.27f,cx,hy+hr*.39f,p); c.drawLine(cx,hy+hr*.39f,cx-hr*.13f,hy+hr*.43f,p); c.drawLine(cx,hy+hr*.39f,cx+hr*.13f,hy+hr*.43f,p);
            p.setStrokeWidth(Math.max(.7f,r*.018f)); c.drawLine(cx-hr*.2f,hy+hr*.29f,cx-hr*.72f,hy+hr*.22f,p); c.drawLine(cx-hr*.2f,hy+hr*.37f,cx-hr*.7f,hy+hr*.43f,p); c.drawLine(cx+hr*.2f,hy+hr*.29f,cx+hr*.72f,hy+hr*.22f,p); c.drawLine(cx+hr*.2f,hy+hr*.37f,cx+hr*.7f,hy+hr*.43f,p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(Math.max(1f,r*.045f)); p.setColor(fur); if(kind%3==1)c.drawArc(new RectF(cx-r*.45f,cy+r*.27f,cx+r*.45f,cy+r*.78f),190,160,false,p); else if(kind%3==2)c.drawArc(new RectF(cx+r*.15f,cy+r*.25f,cx+r*.67f,cy+r*.72f),45,260,false,p); p.setStyle(Paint.Style.FILL);
        }

        String difficultyName() { return difficulty==0?"LATWY":difficulty==1?"NORMALNY":"TRUDNY"; }
        void setRect(float[] r,float l,float t,float right,float b) { r[0]=l; r[1]=t; r[2]=right; r[3]=b; }
        boolean inside(float[] r,float x,float y) { return x>=r[0]&&x<=r[2]&&y>=r[1]&&y<=r[3]; }

        void drawButton(Canvas c,float[] r,String label) {
            p.setStyle(Paint.Style.FILL); p.setShader(new LinearGradient(r[0],r[1],r[0],r[3],Color.rgb(255,249,228),Color.rgb(220,197,151),Shader.TileMode.CLAMP));
            c.drawRoundRect(new RectF(r[0]+1,r[1]+2,r[2]+1,r[3]+3),9,9,p); c.drawRoundRect(new RectF(r[0],r[1],r[2],r[3]),9,9,p); p.setShader(null);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1.5f);
            p.setColor(Color.rgb(151,112,55));
            c.drawRoundRect(new RectF(r[0]+1,r[1]+1,r[2]-1,r[3]-1),8,8,p);
            p.setStyle(Paint.Style.FILL); p.setColor(ink);
            p.setTextAlign(Paint.Align.CENTER); p.setTextSize(Math.min(getWidth()*.027f,18));
            c.drawText(label,(r[0]+r[2])/2f,(r[1]+r[3])/2f-(p.ascent()+p.descent())/2f,p);
        }

        void drawOverlay(Canvas c,float w,float h) {
            p.setColor(Color.argb(185,0,0,0)); c.drawRect(0,0,w,h,p);
            float l=w*.12f,t=h*.30f,r=w*.88f,b=h*.70f;
            p.setColor(wood); c.drawRoundRect(new RectF(l,t,r,b),18,18,p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(3);
            p.setColor(Color.rgb(201,157,82)); c.drawRoundRect(new RectF(l+2,t+2,r-2,b-2),16,16,p);
            p.setStyle(Paint.Style.FILL); p.setTextAlign(Paint.Align.CENTER); p.setColor(cream);
            p.setTextSize(Math.min(w*.065f,40));
            c.drawText(difficultyMenu?"Wybierz poziom":won?"Wygrana!":"Pauza",w/2f,t+h*.09f,p);
            p.setTextSize(Math.min(w*.034f,22));
            c.drawText(difficultyMenu?"Rozpocznij nowa partie":won?"Wszystkie pary znalezione":"Gra zostala zapisana",w/2f,t+h*.16f,p);
            if(difficultyMenu) {
                setRect(modalRects[0],w*.2f,h*.43f,w*.8f,h*.49f);
                setRect(modalRects[1],w*.2f,h*.51f,w*.8f,h*.57f);
                setRect(modalRects[2],w*.2f,h*.59f,w*.8f,h*.65f);
                drawButton(c,modalRects[0],"Latwy");
                drawButton(c,modalRects[1],"Normalny");
                drawButton(c,modalRects[2],"Trudny");
            } else {
                // Pause overlay has exactly one action: resume the current game.
                // Difficulty selection belongs to the "Nowa gra" button on the main screen.
                setRect(modalRects[0],w*.2f,h*.53f,w*.8f,h*.61f);
                drawButton(c,modalRects[0],won?"Nowa gra":"Wznow gre");
                modalRects[1][0]=modalRects[1][1]=modalRects[1][2]=modalRects[1][3]=-1;
            }
        }

        @Override public boolean onTouchEvent(MotionEvent e) {
            float x=e.getX(), y=e.getY();
            if(e.getAction()==MotionEvent.ACTION_DOWN) {
                downX=x; downY=y; dragX=x; dragY=y; dragging=false; dragIndex=-1;
                if(paused || won || difficultyMenu) return true;
                for(int b=0;b<4;b++) if(inside(buttonRects[b],x,y)) return true;
                for(int layer=2;layer>=0;layer--) {
                    for(int i=tiles.size()-1;i>=0;i--) {
                        if(tiles.get(i).layer!=layer || tiles.get(i).removed) continue;
                        float[] r=tileRects[i];
                        if(r[0]>=0 && x>=r[0] && x<=r[2] && y>=r[1] && y<=r[3]) {
                            if(!isAvailable(i)) { message="Kafelek jest zakryty lub ma zablokowane oba boki"; invalidate(); return true; }
                            dragIndex=i; dragOffsetX=x-r[0]; dragOffsetY=y-r[1];
                            selectedTile=i; invalidate(); return true;
                        }
                    }
                }
                return true;
            }
            if(e.getAction()==MotionEvent.ACTION_MOVE) {
                if(dragIndex>=0 && !paused && !won) {
                    if(Math.abs(x-downX)>8 || Math.abs(y-downY)>8) dragging=true;
                    if(dragging) { dragX=x-dragOffsetX; dragY=y-dragOffsetY; invalidate(); }
                }
                return true;
            }
            if(e.getAction()==MotionEvent.ACTION_CANCEL) {
                dragging=false; dragIndex=-1; invalidate(); return true;
            }
            if(e.getAction()!=MotionEvent.ACTION_UP) return true;

            if(paused || won || difficultyMenu) {
                if(difficultyMenu) {
                    if(inside(modalRects[0],x,y)) { newGame(0); return true; }
                    if(inside(modalRects[1],x,y)) { newGame(1); return true; }
                    if(inside(modalRects[2],x,y)) { newGame(2); return true; }
                    return true;
                }
                if(inside(modalRects[0],x,y)) {
                    if(won) newGame(difficulty);
                    else { paused=false; message="Rozgrywka wznowiona"; saveGame(); invalidate(); }
                    return true;
                }
                return true;
            }
            if(dragIndex>=0) {
                int target=dragIndex; boolean wasDrag=dragging;
                dragging=false; dragIndex=-1;
                if(wasDrag && x>=rackRect[0] && x<=rackRect[2] && y>=rackRect[1]-tileH*.35f && y<=rackRect[3]+tileH*.35f) {
                    pick(target); selectedTile=-1;
                } else if(wasDrag) {
                    message="Upuść kafelek w schowku";
                } else {
                    // A tap on a tile that matches something already in the rack should
                    // complete the pair immediately. Dragging is only needed to add a new tile.
                    int rackMatch=-1;
                    for(int r=0;r<rack.size();r++) {
                        if(sameTileType(rack.get(r),tiles.get(target).kind)) { rackMatch=r; break; }
                    }
                    if(rackMatch>=0) {
                        pick(target);
                        selectedTile=-1;
                    } else {
                        selectedTile=target;
                        message="Przeciągnij zaznaczony kafelek do schowka";
                    }
                }
                invalidate(); return true;
            }
            for(int b=0;b<4;b++) if(inside(buttonRects[b],x,y)) {
                selectedTile=-1;
                if(b==0) undo();
                else if(b==1) { paused=true; difficultyMenu=true; invalidate(); }
                else if(b==2) hint();
                else { paused=true; saveGame(); invalidate(); }
                return true;
            }
            return true;
        }
    }
}
