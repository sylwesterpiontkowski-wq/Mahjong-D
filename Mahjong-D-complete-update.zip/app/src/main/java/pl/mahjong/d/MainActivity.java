package pl.mahjong.d;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.LinearGradient;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.Path;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class MainActivity extends Activity {
    private Board board;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        board = new Board();
        setContentView(board);
        board.restoreSavedGame();
    }

    @Override protected void onPause() {
        if (board != null) board.saveGame();
        super.onPause();
    }

    static class Tile {
        private static int nextTileId = 1;
        final int tileId;       // unique identity of this physical tile instance
        final int pairTypeId;   // matching identity shared by the two tiles in a pair
        int kind, layer, col, row;
        boolean removed;
        Tile(int kind, int layer, int col, int row) {
            this.tileId = nextTileId++;
            this.kind = kind;
            this.pairTypeId = (kind == 18 ? 17 : kind);
            this.layer = layer; this.col = col; this.row = row;
        }
    }

    class Board extends View {
        static final int MAX_UNDOS = 5, RACK_SIZE = 5;
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        final ArrayList<Tile> tiles = new ArrayList<>();
        final ArrayList<Integer> rack = new ArrayList<>();
        final ArrayList<String> history = new ArrayList<>();
        final SharedPreferences prefs = getSharedPreferences("mahjong_d_save", MODE_PRIVATE);
        final Random random = new Random();
        final String[] symbols = {"一","二","三","四","五","六","七","八","九","東","南","西","北","中","發","白"};
        final int TOTAL_TILE_KINDS = 26;
        final int cream = Color.rgb(250, 242, 218);
        final int ink = Color.rgb(49, 54, 45);
        final int green = Color.rgb(17, 96, 73);
        final int wood = Color.rgb(65, 38, 25);
        final int gold = Color.rgb(190, 145, 66);
        final Bitmap[] animalTiles = new Bitmap[] {
            BitmapFactory.decodeResource(getResources(), R.drawable.rudy_illustration_1),
            BitmapFactory.decodeResource(getResources(), R.drawable.rudy_illustration_2),
            BitmapFactory.decodeResource(getResources(), R.drawable.rudy_illustration_3),
            BitmapFactory.decodeResource(getResources(), R.drawable.kot2_illustration_1),
            BitmapFactory.decodeResource(getResources(), R.drawable.kot2_illustration_2),
            BitmapFactory.decodeResource(getResources(), R.drawable.kot2_illustration_3),
            BitmapFactory.decodeResource(getResources(), R.drawable.tiger_illustration),
            BitmapFactory.decodeResource(getResources(), R.drawable.lion_illustration),
            BitmapFactory.decodeResource(getResources(), R.drawable.leopard_illustration),
            BitmapFactory.decodeResource(getResources(), R.drawable.snowleopard_illustration)
        };
        final int[] animalKinds = {16,17,18,19,20,21,22,23,24,25};

        int difficulty = 1, undosLeft = MAX_UNDOS, moves = 0, pairsRemoved = 0, shufflesLeft = 3;
        boolean paused = false, won = false, difficultyMenu = false;
        int hintA = -1, hintB = -1;
        String message = "Wybierz dwie takie same płytki";

        float headerBottom, rackTop, rackBottom, boardLeft, boardTop, boardRight, boardBottom;
        float tileW, tileH, gap, controlTop;
        final float[][] tileRects = new float[64][4];
        final float[][] buttonRects = new float[5][4];
        final float[][] modalRects = new float[3][4];
        int dragIndex = -1, selectedTile = -1, selectionBeforeTouch = -1;
        float downX, downY, dragX, dragY, dragOffsetX, dragOffsetY;
        boolean dragging = false;
        final int touchSlop = ViewConfiguration.get(MainActivity.this).getScaledTouchSlop();
        final float[] rackRect = new float[4];

        Board() { super(MainActivity.this); setLayerType(View.LAYER_TYPE_SOFTWARE, null); newGame(1); }

        void newGame(int level) {
            difficulty = Math.max(0, Math.min(2, level));
            tiles.clear(); rack.clear(); history.clear();
            undosLeft = MAX_UNDOS; moves = 0; pairsRemoved = 0; shufflesLeft = 3;
            paused = false; won = false; difficultyMenu = false; hintA = hintB = -1;
            ArrayList<int[]> positions = makeLayout(difficulty);
            ArrayList<Integer> pairKinds = new ArrayList<>();
            // Keep all agreed animal categories represented at every difficulty.
            for (int k = 16; k <= 25 && pairKinds.size() < positions.size()/2; k++) pairKinds.add(k);
            // Fill remaining pairs with traditional Mahjong characters; repeat only when a layout needs more pairs.
            for (int k = 0; pairKinds.size() < positions.size()/2; k++) pairKinds.add(k % symbols.length);
            Collections.shuffle(pairKinds, random);
            ArrayList<Integer> kinds = new ArrayList<>();
            for (int k : pairKinds) { kinds.add(k); kinds.add(k); }
            Collections.shuffle(kinds, random);
            for (int i = 0; i < positions.size(); i++) {
                int[] q = positions.get(i);
                tiles.add(new Tile(kinds.get(i), q[0], q[1], q[2]));
            }
            message = "Wybierz dostępną płytkę";
            saveGame(); invalidate();
        }

        ArrayList<int[]> makeLayout(int level) {
            ArrayList<int[]> out = new ArrayList<>();
            // Hand-authored silhouettes rather than a rectangular grid. Rows are
            // deliberately staggered to create the compact, layered composition
            // in the approved reference. Tile counts remain even for pair matching.
            if (level == 0) {
                int[][] rows = {
                    {2,3,4,5},
                    {1,2,3,4,5},
                    {1,2,3,4,5},
                    {0,1,2,3,4,5},
                    {2,3}
                };
                for (int r=0;r<rows.length;r++) for (int c:rows[r]) out.add(new int[]{0,c,r});
            } else if (level == 1) {
                // 28 tiles in a six-row, staggered base + 8 raised tiles = 36.
                int[][] rows = {
                    {2,3,4},
                    {1,2,3,4,5},
                    {1,2,3,4,5,6},
                    {0,1,2,3,4,5},
                    {1,2,3,4,5},
                    {2,3,4}
                };
                for (int r=0;r<rows.length;r++) for (int c:rows[r]) out.add(new int[]{0,c,r});
                // Raised tiles form a compact central crown, not a second flat row.
                int[][] raised = {{2,1},{3,1},{4,1},{2,2},{3,2},{4,2},{2,3},{4,3}};
                for (int[] q:raised) out.add(new int[]{1,q[0],q[1]});
            } else {
                // 30-tile broad base + 11 raised tiles + 1 crown = 42 tiles.
                int[][] rows = {
                    {2,3,4},
                    {1,2,3,4,5},
                    {0,1,2,3,4,5},
                    {0,1,2,3,4,5,6},
                    {1,2,3,4,5},
                    {2,3,4}
                };
                for (int r=0;r<rows.length;r++) for (int c:rows[r]) out.add(new int[]{0,c,r});
                int[][] raised = {
                    {1,1},{2,1},{3,1},{4,1},{5,1},
                    {1,3},{2,3},{4,3},{5,3},
                    {2,2},{4,2}
                };
                for (int[] q:raised) out.add(new int[]{1,q[0],q[1]});
                out.add(new int[]{2,3,2});
            }
            return out;
        }

        int maxCol() { int m=0; for(Tile t:tiles) if(t.col>m) m=t.col; return m; }
        int maxRow() { int m=0; for(Tile t:tiles) if(t.row>m) m=t.row; return m; }
        float layerX() { return tileW*.11f; }
        float layerY() { return tileH*.075f; }
        float stepX(float usableW) { return (usableW-tileW-layerX()*2f)/Math.max(1,maxCol()); }
        float stepY(float usableH) { return Math.min(tileH*.64f,(usableH-tileH-layerY()*2f)/Math.max(1,maxRow())); }
        float tileX(Tile t,float left,float usableW) { return left+layerX()+t.col*stepX(usableW)+t.layer*layerX(); }
        float tileY(Tile t,float top,float usableH) { return top+t.row*stepY(usableH)-t.layer*layerY(); }

        boolean isAvailable(int index) {
            if(index<0 || index>=tiles.size()) return false;
            Tile t=tiles.get(index);
            if(t.removed) return false;

            // Use the same rendered geometry as the board, rather than only logical
            // grid coordinates. This avoids marking visually exposed tiles as blocked
            // when layers are offset or the layout is scaled to the phone screen.
            float w=getWidth(), h=getHeight();
            if(w<=0 || h<=0 || tileW<=0 || tileH<=0) {
                // Safe fallback before the first layout pass.
                return isAvailableByGrid(index);
            }
            float left=w*.035f, right=w*.965f, top=h*.315f, bottom=h*.855f;
            float usableW=right-left, usableH=bottom-top;
            float tx=tileX(t,left,usableW);
            float ty=tileY(t,top,usableH);
            float eps=Math.max(2f, tileW*.08f);
            boolean covered=false, leftBlocked=false, rightBlocked=false;
            for(int j=0;j<tiles.size();j++) {
                if(j==index) continue;
                Tile o=tiles.get(j);
                if(o.removed) continue;
                float ox1=tileX(o,left,usableW);
                float oy1=tileY(o,top,usableH);
                float overlapX=Math.min(tx+tileW,ox1+tileW)-Math.max(tx,ox1);
                float overlapY=Math.min(ty+tileH,oy1+tileH)-Math.max(ty,oy1);
                if(o.layer>t.layer && overlapX>tileW*.45f && overlapY>tileH*.45f) {
                    covered=true; break;
                }
                if(o.layer==t.layer && overlapY>tileH*.5f) {
                    if(ox1+tileW<=tx+eps && tx-(ox1+tileW)<stepX(usableW)*.35f) leftBlocked=true;
                    if(ox1>=tx+tileW-eps && ox1-(tx+tileW)<stepX(usableW)*.35f) rightBlocked=true;
                }
            }
            return !covered && !(leftBlocked && rightBlocked);
        }

        boolean isAvailableByGrid(int index) {
            Tile t=tiles.get(index);
            boolean covered=false, leftBlocked=false, rightBlocked=false;
            for(int j=0;j<tiles.size();j++) {
                if(j==index) continue;
                Tile o=tiles.get(j);
                if(o.removed) continue;
                if(o.layer>t.layer && o.col==t.col && o.row==t.row) covered=true;
                if(o.layer==t.layer && o.row==t.row) {
                    if(o.col==t.col-1) leftBlocked=true;
                    if(o.col==t.col+1) rightBlocked=true;
                }
            }
            return !covered && !(leftBlocked && rightBlocked);
        }

        String stateJson() {
            try {
                JSONObject root=new JSONObject();
                root.put("version",2);
                root.put("difficulty",difficulty); root.put("undosLeft",undosLeft);
                root.put("moves",moves); root.put("pairsRemoved",pairsRemoved); root.put("shufflesLeft",shufflesLeft);
                root.put("paused",paused); root.put("won",won); root.put("message",message);
                JSONArray ts=new JSONArray();
                for(Tile t:tiles) {
                    JSONObject o=new JSONObject();
                    o.put("kind",t.kind); o.put("layer",t.layer); o.put("col",t.col);
                    o.put("row",t.row); o.put("removed",t.removed); ts.put(o);
                }
                root.put("tiles",ts);
                JSONArray rs=new JSONArray(); for(int k:rack) rs.put(k); root.put("rack",rs);
                JSONArray hs=new JSONArray(); for(String s:history) hs.put(s); root.put("history",hs);
                return root.toString();
            } catch(Exception e) { return ""; }
        }

        void saveGame() {
            if (!tiles.isEmpty()) prefs.edit().putString("state",stateJson()).apply();
        }

        void restoreSavedGame() {
            String saved=prefs.getString("state","");
            if(saved.isEmpty()) { invalidate(); return; }
            try {
                JSONObject root=new JSONObject(saved);
                int savedVersion=root.optInt("version",0);
                if(savedVersion < 2) {
                    int savedDifficulty=Math.max(0,Math.min(2,root.optInt("difficulty",1)));
                    newGame(savedDifficulty);
                    message="Nowy układ — poprawiono identyfikatory kafelków";
                    return;
                }
                tiles.clear(); rack.clear(); history.clear();
                difficulty=root.optInt("difficulty",1);
                undosLeft=root.optInt("undosLeft",MAX_UNDOS);
                moves=root.optInt("moves",0); pairsRemoved=root.optInt("pairsRemoved",0); shufflesLeft=root.optInt("shufflesLeft",3);
                paused=root.optBoolean("paused",false); won=root.optBoolean("won",false);
                message=root.optString("message","Wybierz dostępną płytkę");
                JSONArray ts=root.getJSONArray("tiles");
                for(int i=0;i<ts.length();i++) {
                    JSONObject o=ts.getJSONObject(i);
                    Tile t=new Tile(o.getInt("kind"),o.getInt("layer"),o.getInt("col"),o.getInt("row"));
                    t.removed=o.optBoolean("removed",false); tiles.add(t);
                }
                JSONArray rs=root.optJSONArray("rack");
                if(rs!=null) for(int i=0;i<rs.length();i++) rack.add(rs.getInt(i));
                JSONArray hs=root.optJSONArray("history");
                if(hs!=null) for(int i=0;i<hs.length();i++) history.add(hs.getString(i));
            } catch(Exception e) { newGame(1); }
            invalidate();
        }

        void saveUndo() {
            history.add(stateJsonWithoutHistory());
            if(history.size()>MAX_UNDOS) history.remove(0);
        }

        String stateJsonWithoutHistory() {
            ArrayList<String> old = new ArrayList<>(history);
            history.clear();
            String s=stateJson();
            history.addAll(old);
            return s;
        }

        void undo() {
            if(undosLeft<=0 || history.isEmpty()) { message="Brak dostepnego cofniecia"; invalidate(); return; }
            String s=history.remove(history.size()-1);
            try {
                JSONObject root=new JSONObject(s);
                tiles.clear(); rack.clear();
                difficulty=root.optInt("difficulty",difficulty);
                moves=root.optInt("moves",moves); pairsRemoved=root.optInt("pairsRemoved",pairsRemoved); shufflesLeft=root.optInt("shufflesLeft",3);
                JSONArray ts=root.getJSONArray("tiles");
                for(int i=0;i<ts.length();i++) {
                    JSONObject o=ts.getJSONObject(i);
                    Tile t=new Tile(o.getInt("kind"),o.getInt("layer"),o.getInt("col"),o.getInt("row"));
                    t.removed=o.optBoolean("removed",false); tiles.add(t);
                }
                JSONArray rs=root.optJSONArray("rack");
                if(rs!=null) for(int i=0;i<rs.length();i++) rack.add(rs.getInt(i));
                undosLeft--; won=false; paused=false; hintA=hintB=-1;
                message="Cofnieto ostatni ruch";
            } catch(Exception e) { message="Nie udało się cofnac ruchu"; }
            saveGame(); invalidate();
        }


        void removeBoardPair(int first, int second) {
            if(first<0 || second<0 || first>=tiles.size() || second>=tiles.size()
                    || first==second || tiles.get(first).removed || tiles.get(second).removed
                    || !isAvailable(first) || !isAvailable(second)
                    || !sameTileType(tiles.get(first).kind, tiles.get(second).kind)) {
                message="Para niedostępna lub kafelki nie pasują"; invalidate(); return;
            }
            saveUndo();
            tiles.get(first).removed=true;
            tiles.get(second).removed=true;
            moves++;
            pairsRemoved++;
            selectedTile=-1;
            hintA=hintB=-1;
            boolean any=false;
            for(Tile t:tiles) if(!t.removed) { any=true; break; }
            if(!any) { won=true; message="WYGRANA! Wszystkie plytki usuniete."; }
            else message="Para usunięta";
            saveGame();
            invalidate();
        }

        void pick(int i) {
            if(i<0 || i>=tiles.size() || !isAvailable(i) || paused || won) return;
            int kind=tiles.get(i).kind;
            boolean canMatchRack=false;
            for(int rackKind : rack) if(sameTileType(rackKind,kind)) { canMatchRack=true; break; }
            if(rack.size()>=RACK_SIZE && !canMatchRack) {
                message="Schowek pelny — cofnij ruch"; invalidate(); return;
            }
            saveUndo();
            tiles.get(i).removed=true; moves++;
            int match=-1;
            for(int r=0;r<rack.size();r++) {
                if(sameTileType(rack.get(r),kind)) { match=r; break; }
            }
            if(match>=0) {
                rack.remove(match);
                pairsRemoved++;
                message="Para usunięta";
            } else {
                rack.add(kind);
                message="Płytka trafiła do schowka";
            }
            hintA=hintB=-1;
            boolean any=false; for(Tile t:tiles) if(!t.removed) { any=true; break; }
            if(!any) { won=true; message="WYGRANA! Wszystkie plytki usuniete."; }
            else if(rack.size()==RACK_SIZE) message="Schowek pelny — dopasuj plytke lub cofnij";
            saveGame(); invalidate();
        }

        void shuffleRemainingTiles() {
            if(paused || won || difficultyMenu) return;
            if(shufflesLeft<=0) {
                message="Wykorzystano wszystkie 3 tasowania";
                invalidate();
                return;
            }

            // Preserve the exact board layout: only tile kinds are reassigned to existing
            // active board/rack slots. Coordinates, layers, removed flags and move count stay.
            ArrayList<Integer> boardIndexes = new ArrayList<>();
            ArrayList<Integer> kinds = new ArrayList<>();
            for(int i=0;i<tiles.size();i++) {
                Tile t=tiles.get(i);
                if(!t.removed) {
                    boardIndexes.add(i);
                    kinds.add(t.kind);
                }
            }
            kinds.addAll(rack);
            if(kinds.size()<2) {
                message="Za mało kafelków do tasowania";
                invalidate();
                return;
            }

            ArrayList<Integer> originalKinds = new ArrayList<>(kinds);
            ArrayList<Integer> chosen = null;
            int boardCount=boardIndexes.size();
            int rackCount=rack.size();

            // Prefer a shuffle that doesn't create duplicate matching types in the rack.
            for(int attempt=0;attempt<100;attempt++) {
                Collections.shuffle(kinds,random);
                boolean validRack=true;
                for(int a=boardCount;a<boardCount+rackCount && validRack;a++) {
                    for(int b=a+1;b<boardCount+rackCount;b++) {
                        if(sameTileType(kinds.get(a),kinds.get(b))) {
                            validRack=false;
                            break;
                        }
                    }
                }
                if(validRack) { chosen=new ArrayList<>(kinds); break; }
            }

            if(chosen==null) {
                // Safe fallback: shuffle only active board tiles and leave the rack untouched.
                chosen=new ArrayList<>(originalKinds);
                ArrayList<Integer> boardKinds=new ArrayList<>(chosen.subList(0,boardCount));
                Collections.shuffle(boardKinds,random);
                for(int i=0;i<boardCount;i++) chosen.set(i,boardKinds.get(i));
                for(int i=0;i<rackCount;i++) chosen.set(boardCount+i,rack.get(i));
            }

            boolean changed=false;
            for(int i=0;i<boardCount;i++) {
                Tile t=tiles.get(boardIndexes.get(i));
                int newKind=chosen.get(i);
                if(t.kind!=newKind) changed=true;
            }
            for(int i=0;i<rackCount;i++) {
                if(rack.get(i).intValue()!=chosen.get(boardCount+i).intValue()) changed=true;
            }
            if(!changed) {
                message="Tasowanie nie zmieniło układu symboli — spróbuj ponownie";
                invalidate();
                return;
            }

            saveUndo();
            shufflesLeft--;
            for(int i=0;i<boardCount;i++) tiles.get(boardIndexes.get(i)).kind=chosen.get(i);
            rack.clear();
            for(int i=0;i<rackCount;i++) rack.add(chosen.get(boardCount+i));
            selectedTile=-1;
            hintA=hintB=-1;
            message="Kafelki przetasowane — pozostało tasowań: "+shufflesLeft;
            saveGame();
            invalidate();
        }

        int canonicalTileType(int kind) {
            // Identical Rudy 2/3 artwork uses one shared pair type.
            return kind == 18 ? 17 : kind;
        }

        boolean sameTileType(int a, int b) {
            // Matching compares pair types, never unique tile-instance IDs.
            return canonicalTileType(a) == canonicalTileType(b);
        }

        void hint() {
            hintA=hintB=-1;
            for(int i=0;i<tiles.size();i++) if(isAvailable(i))
                for(int j=i+1;j<tiles.size();j++)
                    if(isAvailable(j) && sameTileType(tiles.get(i).kind,tiles.get(j).kind)) {
                        hintA=i; hintB=j; message="Podswietlono pasujaca pare"; invalidate(); return;
                    }
            message="Nie widze teraz pasujacej pary"; invalidate();
        }

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            // Clear hit rectangles each frame so removed or hidden tiles cannot leave stale hit targets.
            for(int i=0;i<tileRects.length;i++) {
                tileRects[i][0]=-1; tileRects[i][1]=-1; tileRects[i][2]=-1; tileRects[i][3]=-1;
            }
            float w=getWidth(), h=getHeight();
            p.setStyle(Paint.Style.FILL);
            p.setShader(new LinearGradient(0,0,w,h,Color.rgb(7,39,31),Color.rgb(24,83,61),Shader.TileMode.CLAMP));
            c.drawRect(0,0,w,h,p); p.setShader(null);
            // Walnut wood rails around the play surface, with a subtle warm grain.
            float rail = Math.max(5f,w*.022f);
            p.setShader(new LinearGradient(0,0,w,0,
                    new int[]{Color.rgb(31,18,13),Color.rgb(92,52,28),Color.rgb(132,83,43),Color.rgb(52,29,19)},
                    null,Shader.TileMode.CLAMP));
            c.drawRect(0,0,w,rail*1.35f,p);
            c.drawRect(0,h*.13f-rail*.55f,w,h*.13f+rail*.55f,p);
            c.drawRect(0,h*.86f-rail*.55f,w,h*.86f+rail*.55f,p);
            c.drawRect(0,h-rail*1.35f,w,h,p);
            c.drawRect(0,0,rail,h,p);
            c.drawRect(w-rail,0,w,h,p);
            p.setShader(null);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(Math.max(1f,w*.002f));
            p.setColor(Color.rgb(207,159,76));
            c.drawRect(rail*.3f,rail*.3f,w-rail*.3f,h-rail*.3f,p);
            p.setStrokeWidth(Math.max(.7f,w*.0009f));
            p.setColor(Color.argb(200,246,214,145));
            c.drawRect(rail*.8f,rail*.8f,w-rail*.8f,h-rail*.8f,p);
            p.setStyle(Paint.Style.FILL);
            // Target look: a restrained walnut-and-gold frame around the emerald felt.
            p.setStyle(Paint.Style.FILL);
            p.setShader(new LinearGradient(0,0,w,0,
                    new int[]{Color.rgb(35,20,14),Color.rgb(111,66,35),Color.rgb(46,27,18)},
                    null,Shader.TileMode.CLAMP));
            c.drawRect(0,0,w,h,p); p.setShader(null);
            p.setColor(Color.rgb(9,48,36));
            c.drawRect(w*.018f, h*.008f, w*.982f, h*.992f, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(Math.max(1.2f,w*.003f));
            p.setColor(Color.rgb(183,133,57));
            c.drawRoundRect(new RectF(w*.012f,h*.006f,w*.988f,h*.994f),w*.018f,w*.018f,p);
            p.setStrokeWidth(Math.max(.7f,w*.0012f));
            p.setColor(Color.argb(180,244,211,139));
            c.drawRoundRect(new RectF(w*.022f,h*.014f,w*.978f,h*.986f),w*.014f,w*.014f,p);
            // Subtle botanical texture on the green felt; decorative only.
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeWidth(Math.max(1f,w*.003f));
            for (int side=0; side<2; side++) {
                float bx = side==0 ? w*.018f : w*.982f;
                float dir = side==0 ? 1f : -1f;
                p.setColor(Color.argb(20,176,198,126));
                c.drawLine(bx,h*.37f,bx+dir*w*.035f,h*.72f,p);
                for (int leaf=0; leaf<5; leaf++) {
                    float ly=h*(.405f+leaf*.058f);
                    Path leafPath=new Path();
                    leafPath.moveTo(bx+dir*w*.009f,ly);
                    leafPath.quadTo(bx+dir*w*.025f,ly-h*.018f,bx+dir*w*.041f,ly-h*.012f);
                    c.drawPath(leafPath,p);
                    leafPath.reset();
                    leafPath.moveTo(bx+dir*w*.014f,ly+h*.018f);
                    leafPath.quadTo(bx+dir*w*.028f,ly+h*.035f,bx+dir*w*.043f,ly+h*.025f);
                    c.drawPath(leafPath,p);
                }
            }
            p.setStyle(Paint.Style.FILL);
            headerBottom=h*.135f;
            p.setShader(new LinearGradient(0,0,0,headerBottom,
                    new int[]{Color.rgb(105,62,31),Color.rgb(57,31,19),Color.rgb(91,51,27)},
                    null,Shader.TileMode.CLAMP));
            c.drawRect(rail,0,w-rail,headerBottom,p); p.setShader(null);
            // Restrained horizontal grain lines, decorative only.
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(Math.max(.7f,w*.001f));
            p.setColor(Color.argb(36,235,187,115));
            for(int grain=0;grain<5;grain++) {
                float gy=headerBottom*(.12f+grain*.17f);
                c.drawLine(w*.04f,gy,w*.96f,gy,p);
            }
            p.setStyle(Paint.Style.FILL);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(Math.max(1f,w*.002f));
            p.setColor(Color.rgb(207,159,76));
            c.drawRoundRect(new RectF(w*.012f,h*.008f,w*.988f,headerBottom-h*.008f),w*.018f,w*.018f,p);
            p.setStrokeWidth(Math.max(.7f,w*.0009f));
            p.setColor(Color.argb(190,246,214,145));
            c.drawRoundRect(new RectF(w*.024f,h*.018f,w*.976f,headerBottom-h*.018f),w*.012f,w*.012f,p);
            p.setStyle(Paint.Style.FILL);
            p.setColor(gold); c.drawRect(0,headerBottom-2,w,headerBottom,p);
            p.setShader(new LinearGradient(0,h*.86f,0,h,
                    new int[]{Color.rgb(101,59,30),Color.rgb(45,25,17),Color.rgb(79,44,24)},
                    null,Shader.TileMode.CLAMP));
            c.drawRect(rail,h*.86f,w-rail,h-rail,p); p.setShader(null);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(Math.max(.7f,w*.001f));
            p.setColor(Color.argb(34,235,187,115));
            for(int grain=0;grain<4;grain++) {
                float gy=h*(.875f+grain*.027f);
                c.drawLine(w*.035f,gy,w*.965f,gy,p);
            }
            p.setStyle(Paint.Style.FILL);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1f); p.setColor(Color.argb(12,238,211,154));
            for(int k=0;k<7;k++){ float cx=(k+.5f)*w/7f, cy=h*.56f; c.drawCircle(cx,cy,Math.min(w,h)*.12f,p); c.drawCircle(cx,cy,Math.min(w,h)*.105f,p); }
            // Faint traditional cloud/coin medallions in the felt, kept away from touch logic.
            p.setStrokeWidth(Math.max(1f,w*.0016f));
            for (int k=0;k<4;k++) {
                float mx=w*(.16f+k*.23f), my=h*.69f, mr=Math.min(w,h)*.026f;
                p.setColor(Color.argb(14,226,194,121));
                c.drawCircle(mx,my,mr,p);
                c.drawCircle(mx,my,mr*.68f,p);
                c.drawLine(mx-mr*.42f,my,mx+mr*.42f,my,p);
                c.drawLine(mx,my-mr*.42f,mx,my+mr*.42f,p);
            }
            p.setStyle(Paint.Style.FILL);
            // Single restrained corner decoration. The outer walnut frame is drawn once;
            // avoid separate header/board/footer rectangles that created intersecting lines.
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(Math.max(1f,w*.0015f));
            p.setColor(Color.argb(165,201,157,82));
            float corner=Math.min(w,h)*.022f;
            float inset=w*.027f;
            float[] xs={inset,w-inset};
            float[] ys={h*.018f,h*.982f};
            for(float xx:xs) for(float yy:ys) {
                float dx=xx< w/2f ? 1f : -1f;
                float dy=yy< h/2f ? 1f : -1f;
                c.drawLine(xx,yy,xx+dx*corner,yy,p);
                c.drawLine(xx,yy,xx,yy+dy*corner,p);
                c.drawLine(xx+dx*corner*.32f,yy+dy*corner*.32f,
                           xx+dx*corner*.72f,yy+dy*corner*.72f,p);
            }
            p.setStyle(Paint.Style.FILL);

            p.setColor(cream); p.setTextAlign(Paint.Align.LEFT); p.setFakeBoldText(true);
            p.setTextSize(Math.min(w*.061f,42)); c.drawText("Mahjong D",w*.04f,h*.065f,p);
            p.setFakeBoldText(false); p.setTextAlign(Paint.Align.RIGHT);
            p.setTextSize(Math.min(w*.031f,22));
            c.drawText(difficultyName(),w*.96f,h*.052f,p);
            c.drawText("Pary: "+pairsRemoved+"/"+(tiles.size()/2)+"   Ruchy: "+moves,w*.96f,h*.102f,p);

            // Rack is anchored to the top of the playing field, never over the board.
            float rackW=w*.84f, rackX=(w-rackW)/2f;
            rackTop=h*.155f; rackBottom=h*.255f;
            rackRect[0]=rackX; rackRect[1]=rackTop; rackRect[2]=rackX+rackW; rackRect[3]=rackBottom;
            p.setColor(Color.rgb(103,65,37));
            c.drawRoundRect(new RectF(rackX,rackTop,rackX+rackW,rackBottom),12,12,p);
            float slotW=rackW/5f;
            for(int s=0;s<5;s++) {
                float l=rackX+s*slotW+3, t=rackTop+3, r=l+slotW-6, b=rackBottom-3;
                p.setColor(Color.rgb(37,28,21)); c.drawRoundRect(new RectF(l,t,r,b),7,7,p);
                if(s<rack.size()) drawTileFace(c,l+2,t+2,slotW-10,b-t-4,rack.get(s),false);
            }
            p.setTextAlign(Paint.Align.CENTER); p.setColor(cream);
            p.setTextSize(Math.min(w*.029f,20));
            c.drawText("Schowek "+rack.size()+"/5",w/2f,h*.285f,p);

            // Responsive board: tile rectangles are computed once and reused for hit testing.
            boardLeft=w*.035f; boardRight=w*.965f;
            boardTop=h*.315f; boardBottom=h*.855f;
            float usableW=boardRight-boardLeft, usableH=boardBottom-boardTop;
            tileW=usableW/6.7f;
            tileH=tileW*1.20f;
            if(tileH*3.55f>usableH) { tileH=usableH/3.55f; tileW=tileH/1.20f; }
            for(int i=0;i<tileRects.length;i++) { tileRects[i][0]=-1; tileRects[i][1]=-1; tileRects[i][2]=-1; tileRects[i][3]=-1; }

            // Keep every layer inside the board without clamping. Clamping made edge tiles
            // from different columns share the same screen rectangle while availability used
            // their original grid coordinates — the source of false blocked/free tiles.
            // Keep layer offsets visually restrained. Large offsets made the borders of
            // several neighboring tiles show through as multiple ghost frames.
            // Give stacked layers a visible but restrained offset so lower tiles remain identifiable.
            // Keep layers aligned horizontally to avoid neighboring frames ghosting over each other.
            // A small vertical offset still reveals the lower tile edges.
            float layerOffsetX=layerX(), layerOffsetY=layerY();
            float stepX=stepX(usableW), stepY=stepY(usableH);
            for(int layer=0;layer<3;layer++) for(int i=0;i<tiles.size();i++) {
                Tile t=tiles.get(i);
                if(t.removed || t.layer!=layer || (dragging && i==dragIndex)) continue;
                float x=tileX(t,boardLeft,usableW);
                float y=tileY(t,boardTop,usableH);
                tileRects[i][0]=x; tileRects[i][1]=y; tileRects[i][2]=x+tileW; tileRects[i][3]=y+tileH;
                boolean available=isAvailable(i);
                if(i==hintA || i==hintB) {
                    p.setColor(Color.rgb(255,216,105));
                    c.drawRoundRect(new RectF(x-4,y-4,x+tileW+4,y+tileH+4),9,9,p);
                }
                drawTileFace(c,x,y,tileW,tileH,t.kind,!available);
            }

            if(dragging && dragIndex>=0 && dragIndex<tiles.size()) {
                p.setColor(Color.argb(75,0,0,0));
                c.drawRoundRect(new RectF(dragX+4,dragY+5,dragX+tileW+4,dragY+tileH+5),8,8,p);
                drawTileFace(c,dragX,dragY,tileW,tileH,tiles.get(dragIndex).kind,false);
            }
            if(selectedTile>=0 && selectedTile<tiles.size() && !tiles.get(selectedTile).removed && !dragging) {
                float[] sr=tileRects[selectedTile];
                if(sr[0]>=0) { p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(3f); p.setColor(Color.rgb(255,211,105)); c.drawRoundRect(new RectF(sr[0]-3,sr[1]-3,sr[2]+3,sr[3]+3),8,8,p); p.setStyle(Paint.Style.FILL); }
            }
            controlTop=h*.875f;
            float left=w*.025f, right=w*.975f, bw=(right-left)/5f;
            String[] labels={"Cofnij ("+undosLeft+")","Nowa gra","Podpowiedź","Pauza","Tasuj ("+shufflesLeft+")"};
            for(int i=0;i<5;i++) {
                setRect(buttonRects[i],left+i*bw+2,controlTop,left+(i+1)*bw-2,h*.945f);
                drawButton(c,buttonRects[i],labels[i]);
            }
            p.setColor(cream); p.setTextAlign(Paint.Align.CENTER); p.setTextSize(Math.min(w*.027f,18));
            c.drawText(message,w/2f,h*.975f,p);
            if(paused || won || difficultyMenu) drawOverlay(c,w,h);
        }

        // Kept separate to make the responsive sizing calculation explicit.
        void gapX(float usableW,float tw) { gap=Math.max(2f,(usableW-8*tw)/7f); }

        void drawTileFace(Canvas c,float x,float y,float tw,float th,int kind,boolean dim) {
            float rad=Math.max(5f,tw*.09f);
            // One soft shadow only; repeated heavy borders made each tile look like
            // several offset tiles stacked together on the board.
            p.setStyle(Paint.Style.FILL); p.setShader(null);
            p.setShader(new LinearGradient(x,y+th*.82f,x,y+th+th*.10f,
                    new int[]{Color.rgb(108,68,31),Color.rgb(61,37,20),Color.rgb(37,25,17)},null,Shader.TileMode.CLAMP));
            c.drawRoundRect(new RectF(x+tw*.018f,y+th*.045f,x+tw+tw*.018f,y+th+th*.055f),rad,rad,p); p.setShader(null);
            p.setColor(Color.argb(dim?18:38,0,0,0));
            c.drawRoundRect(new RectF(x+tw*.025f,y+th*.018f,x+tw+tw*.025f,y+th+th*.018f),rad,rad,p);
            p.setShader(new LinearGradient(x,y,x+tw,y+th,
                    dim?Color.rgb(221,211,187):Color.rgb(255,253,241),
                    dim?Color.rgb(196,180,147):Color.rgb(239,222,184),
                    Shader.TileMode.CLAMP));
            c.drawRoundRect(new RectF(x,y,x+tw,y+th),rad,rad,p); p.setShader(null);
            // A single walnut outline and one fine gold inset line form the tile frame.
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(Math.max(1f,tw*.018f));
            p.setColor(dim?Color.rgb(128,116,94):Color.rgb(126,78,36));
            c.drawRoundRect(new RectF(x+tw*.035f,y+th*.025f,x+tw*.965f,y+th*.975f),rad*.78f,rad*.78f,p);
            p.setStrokeWidth(Math.max(.7f,tw*.008f));
            p.setColor(dim?Color.rgb(155,143,117):Color.rgb(201,151,65));
            c.drawRoundRect(new RectF(x+tw*.065f,y+th*.05f,x+tw*.935f,y+th*.95f),rad*.62f,rad*.62f,p);
            p.setStyle(Paint.Style.FILL);
            // Four small corner flourishes give the ceramic frame a consistent ornamental language.
            p.setColor(dim?Color.rgb(157,142,111):Color.rgb(190,143,61));
            float ornament=Math.max(1.2f,tw*.025f);
            for(int sx=-1;sx<=1;sx+=2) for(int sy=-1;sy<=1;sy+=2) {
                float ox=x+tw*(sx<0?.13f:.87f), oy=y+th*(sy<0?.105f:.895f);
                c.drawCircle(ox,oy,ornament,p);
                p.setStrokeWidth(Math.max(.7f,tw*.008f)); p.setStyle(Paint.Style.STROKE);
                c.drawLine(ox,oy,ox-sx*tw*.035f,oy,p); c.drawLine(ox,oy,ox,oy-sy*th*.022f,p);
                p.setStyle(Paint.Style.FILL);
            }
            float cx=x+tw/2f, cy=y+th*.49f, rr=Math.min(tw,th)*.325f;
            p.setShader(new RadialGradient(cx-rr*.25f,cy-rr*.3f,rr,new int[]{Color.rgb(255,255,246),Color.rgb(244,229,194),Color.rgb(218,193,143)},null,Shader.TileMode.CLAMP));
            c.drawCircle(cx,cy,rr,p); p.setShader(null); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(Math.max(1f,tw*.018f)); p.setColor(Color.argb(190,151,112,55)); c.drawCircle(cx,cy,rr,p); p.setStyle(Paint.Style.FILL);
            int animalIndex = -1;
            for (int ai=0; ai<animalKinds.length; ai++) if (animalKinds[ai] == kind) { animalIndex=ai; break; }
            if(animalIndex >= 0) {
                Bitmap art=animalTiles[animalIndex];
                // Place the animal illustration inside the ceramic tile, leaving its own outer gold frame visible.
                p.setStyle(Paint.Style.FILL);
                p.setShader(null);
                RectF dst=new RectF(x+tw*.105f,y+th*.095f,x+tw*.895f,y+th*.875f);
                int save=c.save();
                Path clip=new Path();
                clip.addRoundRect(dst,Math.max(2f,rad*.45f),Math.max(2f,rad*.45f),Path.Direction.CW);
                c.clipPath(clip);
                // Show the full illustration with a small inset so its silhouette is not
                // pressed against the tile border. Preserve source proportions and never crop.
                float insetX = dst.width() * 0.06f;
                float insetY = dst.height() * 0.06f;
                RectF inner = new RectF(dst.left + insetX, dst.top + insetY,
                        dst.right - insetX, dst.bottom - insetY);
                float sourceRatio = (float) art.getWidth() / (float) art.getHeight();
                float targetRatio = inner.width() / inner.height();
                RectF artDst = new RectF(inner);
                if (sourceRatio > targetRatio) {
                    float fittedHeight = inner.width() / sourceRatio;
                    float top = inner.centerY() - fittedHeight / 2f;
                    artDst.set(inner.left, top, inner.right, top + fittedHeight);
                } else {
                    float fittedWidth = inner.height() * sourceRatio;
                    float left = inner.centerX() - fittedWidth / 2f;
                    artDst.set(left, inner.top, left + fittedWidth, inner.bottom);
                }
                c.drawBitmap(art, null, artDst, p);
                c.restoreToCount(save);
                p.setStyle(Paint.Style.STROKE);
                // Keep only a fine separator around the illustration, not another heavy frame.
                p.setStrokeWidth(Math.max(.6f,tw*.006f));
                p.setColor(Color.argb(dim?90:145,164,113,51));
                c.drawRoundRect(dst,Math.max(2f,rad*.45f),Math.max(2f,rad*.45f),p);
                p.setStyle(Paint.Style.FILL);
            }
            else {
                int[] inks={Color.rgb(37,105,69),Color.rgb(37,105,69),Color.rgb(37,105,69),Color.rgb(37,105,69),Color.rgb(37,105,69),Color.rgb(37,105,69),Color.rgb(37,105,69),Color.rgb(37,105,69),Color.rgb(37,105,69),Color.rgb(37,105,69),Color.rgb(37,105,69),Color.rgb(37,105,69),Color.rgb(37,105,69),Color.rgb(164,43,37),Color.rgb(35,112,67),Color.rgb(42,54,48)};
                p.setColor(dim?Color.rgb(103,102,88):inks[kind%symbols.length]); p.setTextAlign(Paint.Align.CENTER); p.setFakeBoldText(true); p.setTextSize(Math.min(tw*.53f,th*.43f)); c.drawText(symbols[kind%symbols.length],cx,y+th*.61f,p); p.setFakeBoldText(false);
                p.setColor(Color.argb(dim?70:145,151,112,55)); p.setStrokeWidth(Math.max(1f,tw*.012f)); c.drawLine(x+tw*.29f,y+th*.79f,x+tw*.71f,y+th*.79f,p); c.drawCircle(cx,y+th*.79f,Math.max(1f,tw*.018f),p);
            }
        }

        void drawCat(Canvas c,float cx,float cy,float r,int kind,boolean dim) {
            boolean ginger=kind<=12; int fur=dim?Color.rgb(145,135,115):(ginger?Color.rgb(202,112,48):Color.rgb(79,83,78));
            int light=dim?Color.rgb(190,181,160):(ginger?Color.rgb(246,195,124):Color.rgb(224,222,206)); int dark=ginger?Color.rgb(106,55,28):Color.rgb(43,47,44);
            float hy=cy-r*.02f, hr=r*.60f; p.setStyle(Paint.Style.FILL); p.setColor(fur);
            Path ear=new Path(); ear.moveTo(cx-hr*.72f,hy-hr*.35f); ear.lineTo(cx-hr*.82f,hy-hr*1.08f); ear.lineTo(cx-hr*.18f,hy-hr*.65f); ear.close(); c.drawPath(ear,p);
            ear.reset(); ear.moveTo(cx+hr*.72f,hy-hr*.35f); ear.lineTo(cx+hr*.82f,hy-hr*1.08f); ear.lineTo(cx+hr*.18f,hy-hr*.65f); ear.close(); c.drawPath(ear,p);
            p.setColor(fur); c.drawCircle(cx,hy,hr*.76f,p); p.setColor(light); c.drawOval(new RectF(cx-hr*.43f,hy+hr*.05f,cx+hr*.43f,hy+hr*.63f),p);
            p.setColor(dark); float ey=hy-hr*.04f, er=Math.max(1.1f,r*.055f); c.drawCircle(cx-hr*.29f,ey,er,p); c.drawCircle(cx+hr*.29f,ey,er,p);
            p.setColor(ginger?Color.rgb(176,83,75):Color.rgb(194,133,143)); Path nose=new Path(); nose.moveTo(cx,hy+hr*.17f); nose.lineTo(cx-hr*.11f,hy+hr*.27f); nose.lineTo(cx+hr*.11f,hy+hr*.27f); nose.close(); c.drawPath(nose,p);
            p.setColor(dark); p.setStrokeWidth(Math.max(1f,r*.025f)); c.drawLine(cx,hy+hr*.27f,cx,hy+hr*.39f,p); c.drawLine(cx,hy+hr*.39f,cx-hr*.13f,hy+hr*.43f,p); c.drawLine(cx,hy+hr*.39f,cx+hr*.13f,hy+hr*.43f,p);
            p.setStrokeWidth(Math.max(.7f,r*.018f)); c.drawLine(cx-hr*.2f,hy+hr*.29f,cx-hr*.72f,hy+hr*.22f,p); c.drawLine(cx-hr*.2f,hy+hr*.37f,cx-hr*.7f,hy+hr*.43f,p); c.drawLine(cx+hr*.2f,hy+hr*.29f,cx+hr*.72f,hy+hr*.22f,p); c.drawLine(cx+hr*.2f,hy+hr*.37f,cx+hr*.7f,hy+hr*.43f,p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(Math.max(1f,r*.045f)); p.setColor(fur); if(kind%3==1)c.drawArc(new RectF(cx-r*.45f,cy+r*.27f,cx+r*.45f,cy+r*.78f),190,160,false,p); else if(kind%3==2)c.drawArc(new RectF(cx+r*.15f,cy+r*.25f,cx+r*.67f,cy+r*.72f),45,260,false,p); p.setStyle(Paint.Style.FILL);
        }

        String difficultyName() { return difficulty==0?"LATWY":difficulty==1?"NORMALNY":"TRUDNY"; }
        void setRect(float[] r,float l,float t,float right,float b) { r[0]=l; r[1]=t; r[2]=right; r[3]=b; }
        boolean inside(float[] r,float x,float y) { return x>=r[0]&&x<=r[2]&&y>=r[1]&&y<=r[3]; }

        void drawButton(Canvas c,float[] r,String label) {
            // Walnut control with a warm inset highlight and gold trim, matching the target UI.
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.argb(100,0,0,0));
            c.drawRoundRect(new RectF(r[0]+2,r[1]+3,r[2]+2,r[3]+4),9,9,p);
            p.setShader(new LinearGradient(r[0],r[1],r[2],r[3],
                    new int[]{Color.rgb(118,70,35),Color.rgb(58,31,19),Color.rgb(95,53,27)},
                    null,Shader.TileMode.CLAMP));
            c.drawRoundRect(new RectF(r[0],r[1],r[2],r[3]),9,9,p);
            p.setShader(null);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(Math.max(1f,getWidth()*.002f));
            p.setColor(Color.rgb(205,157,75));
            c.drawRoundRect(new RectF(r[0]+1,r[1]+1,r[2]-1,r[3]-1),8,8,p);
            p.setStrokeWidth(Math.max(.7f,getWidth()*.0008f));
            p.setColor(Color.argb(190,244,211,139));
            c.drawRoundRect(new RectF(r[0]+4,r[1]+4,r[2]-4,r[3]-4),6,6,p);
            p.setStyle(Paint.Style.FILL); p.setColor(cream);
            p.setTextAlign(Paint.Align.CENTER); p.setTextSize(Math.min(getWidth()*.027f,18));
            c.drawText(label,(r[0]+r[2])/2f,(r[1]+r[3])/2f-(p.ascent()+p.descent())/2f,p);
        }

        void drawOverlay(Canvas c,float w,float h) {
            p.setColor(Color.argb(185,0,0,0)); c.drawRect(0,0,w,h,p);
            float l=w*.12f,t=h*.30f,r=w*.88f,b=h*.70f;
            p.setColor(wood); c.drawRoundRect(new RectF(l,t,r,b),18,18,p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(3);
            p.setColor(Color.rgb(201,157,82)); c.drawRoundRect(new RectF(l+2,t+2,r-2,b-2),16,16,p);
            p.setStyle(Paint.Style.FILL); p.setTextAlign(Paint.Align.CENTER); p.setColor(cream);
            p.setTextSize(Math.min(w*.065f,40));
            c.drawText(difficultyMenu?"Wybierz poziom":won?"Wygrana!":"Pauza",w/2f,t+h*.09f,p);
            p.setTextSize(Math.min(w*.034f,22));
            c.drawText(difficultyMenu?"Rozpocznij nowa partie":won?"Wszystkie pary znalezione":"Gra zostala zapisana",w/2f,t+h*.16f,p);
            if(difficultyMenu) {
                setRect(modalRects[0],w*.2f,h*.43f,w*.8f,h*.49f);
                setRect(modalRects[1],w*.2f,h*.51f,w*.8f,h*.57f);
                setRect(modalRects[2],w*.2f,h*.59f,w*.8f,h*.65f);
                drawButton(c,modalRects[0],"Latwy");
                drawButton(c,modalRects[1],"Normalny");
                drawButton(c,modalRects[2],"Trudny");
            } else {
                // Pause overlay has exactly one action: resume the current game.
                // Difficulty selection belongs to the "Nowa gra" button on the main screen.
                setRect(modalRects[0],w*.2f,h*.53f,w*.8f,h*.61f);
                drawButton(c,modalRects[0],won?"Nowa gra":"Wznow gre");
                modalRects[1][0]=modalRects[1][1]=modalRects[1][2]=modalRects[1][3]=-1;
            }
        }

        @Override public boolean onTouchEvent(MotionEvent e) {
            float x=e.getX(), y=e.getY();
            if(e.getAction()==MotionEvent.ACTION_DOWN) {
                downX=x; downY=y; dragX=x; dragY=y; dragging=false; dragIndex=-1; selectionBeforeTouch=selectedTile;
                if(paused || won || difficultyMenu) return true;
                for(int b=0;b<5;b++) if(inside(buttonRects[b],x,y)) return true;
                int blockedHit=-1;
                // Hit-test in reverse drawing order. If a blocked tile overlaps an exposed
                // part of another tile, do not consume the touch immediately: keep searching
                // for the topmost AVAILABLE tile under the finger.
                for(int layer=2;layer>=0;layer--) {
                    for(int i=tiles.size()-1;i>=0;i--) {
                        if(tiles.get(i).layer!=layer || tiles.get(i).removed) continue;
                        float[] r=tileRects[i];
                        if(r[0]>=0 && x>=r[0] && x<=r[2] && y>=r[1] && y<=r[3]) {
                            if(!isAvailable(i)) { if(blockedHit<0) blockedHit=i; continue; }
                            dragIndex=i; dragOffsetX=x-r[0]; dragOffsetY=y-r[1];
                            selectedTile=i; invalidate(); return true;
                        }
                    }
                }
                if(blockedHit>=0) message="Kafelek jest zakryty lub ma zablokowane oba boki";
                invalidate();
                return true;
            }
            if(e.getAction()==MotionEvent.ACTION_MOVE) {
                if(dragIndex>=0 && !paused && !won) {
                    // Use Android touch slop (density-aware) so tiny finger movement does not turn a tap into a drag.
                    if(Math.abs(x-downX)>touchSlop || Math.abs(y-downY)>touchSlop) dragging=true;
                    if(dragging) { dragX=x-dragOffsetX; dragY=y-dragOffsetY; invalidate(); }
                }
                return true;
            }
            if(e.getAction()==MotionEvent.ACTION_CANCEL) {
                dragging=false; dragIndex=-1; invalidate(); return true;
            }
            if(e.getAction()!=MotionEvent.ACTION_UP) return true;

            if(paused || won || difficultyMenu) {
                if(difficultyMenu) {
                    if(inside(modalRects[0],x,y)) { newGame(0); return true; }
                    if(inside(modalRects[1],x,y)) { newGame(1); return true; }
                    if(inside(modalRects[2],x,y)) { newGame(2); return true; }
                    return true;
                }
                if(inside(modalRects[0],x,y)) {
                    if(won) newGame(difficulty);
                    else { paused=false; message="Rozgrywka wznowiona"; saveGame(); invalidate(); }
                    return true;
                }
                return true;
            }
            if(dragIndex>=0) {
                int target=dragIndex; boolean wasDrag=dragging;
                dragging=false; dragIndex=-1;
                if(wasDrag && x>=rackRect[0] && x<=rackRect[2] && y>=rackRect[1]-tileH*.35f && y<=rackRect[3]+tileH*.35f) {
                    pick(target); selectedTile=-1;
                } else if(wasDrag) {
                    message="Upuść kafelek w schowku";
                } else {
                    // A tap on a tile that matches something already in the rack should
                    // complete the pair immediately. Dragging is only needed to add a new tile.
                    int rackMatch=-1;
                    for(int r=0;r<rack.size();r++) {
                        if(sameTileType(rack.get(r),tiles.get(target).kind)) { rackMatch=r; break; }
                    }
                    if(rackMatch>=0) {
                        pick(target);
                        selectedTile=-1;
                    } else if(selectionBeforeTouch>=0 && selectionBeforeTouch!=target
                            && selectionBeforeTouch<tiles.size()
                            && !tiles.get(selectionBeforeTouch).removed
                            && isAvailable(selectionBeforeTouch)
                            && sameTileType(tiles.get(selectionBeforeTouch).kind, tiles.get(target).kind)) {
                        removeBoardPair(selectionBeforeTouch, target);
                        selectedTile=-1;
                    } else {
                        selectedTile=target;
                        message="Wybierz drugi identyczny kafelek albo przeciągnij do schowka";
                    }
                }
                invalidate(); return true;
            }
            for(int b=0;b<5;b++) if(inside(buttonRects[b],x,y)) {
                selectedTile=-1;
                if(b==0) undo();
                else if(b==1) { paused=true; difficultyMenu=true; invalidate(); }
                else if(b==2) hint();
                else if(b==3) { paused=true; saveGame(); invalidate(); }
                else shuffleRemainingTiles();
                return true;
            }
            return true;
        }
    }
}
