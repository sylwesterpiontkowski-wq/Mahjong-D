package pl.mahjong.d;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.LinearGradient;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.Path;
import android.graphics.Region;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class MainActivity extends Activity {
    private Board board;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        board = new Board();
        setContentView(board);
        board.restoreSavedGame();
    }

    @Override protected void onPause() {
        if (board != null) board.saveGame();
        super.onPause();
    }

    static class Tile {
        private static int nextTileId = 1;
        final int tileId;       // unique identity of this physical tile instance
        final int pairTypeId;   // matching identity shared by the two tiles in a pair
        int kind, layer, col, row;
        boolean removed;
        Tile(int kind, int layer, int col, int row) {
            this.tileId = nextTileId++;
            this.kind = kind;
            this.pairTypeId = kind;
            this.layer = layer; this.col = col; this.row = row;
        }
    }

    class Board extends View {
        static final int MAX_UNDOS = 5, RACK_SIZE = 5;
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        final ArrayList<Tile> tiles = new ArrayList<>();
        final ArrayList<Integer> rack = new ArrayList<>();
        final ArrayList<String> history = new ArrayList<>();
        final SharedPreferences prefs = getSharedPreferences("mahjong_d_save", MODE_PRIVATE);
        final Random random = new Random();
        final String[] symbols = {"一","二","三","四","五","六","七","八","九","東","南","西","北","中","發","白","春","夏","秋","冬","梅","蘭","菊","竹","日","月","山","川","風","雲","龍","鳳","福","壽","喜","財","玉","松","鶴","魚","蝶","蓮","桃","橘","葫","鯉","壹","貳","參","肆","伍","陸","柒","捌","玖","吉","祥","如","意","和","合","平","安","寶","花","星","竹","琴","茶","貓"};
        final int TOTAL_TILE_KINDS = 71;
        final int cream = Color.rgb(250, 242, 218);
        final int ink = Color.rgb(49, 54, 45);
        final int green = Color.rgb(17, 96, 73);
        final int wood = Color.rgb(65, 38, 25);
        final int gold = Color.rgb(190, 145, 66);
        // 22 real artwork assets, kinds 16..37. Each kind is a distinct pair pattern.
        final Bitmap[] animalTiles = new Bitmap[] {
            loadAnimalTile(R.drawable.rudy_illustration_1),
            loadAnimalTile(R.drawable.rudy_illustration_2),
            loadAnimalTile(R.drawable.rudy_illustration_3),
            loadAnimalTile(R.drawable.kot2_illustration_1),
            loadAnimalTile(R.drawable.kot2_illustration_2),
            loadAnimalTile(R.drawable.kot2_illustration_3),
            loadAnimalTile(R.drawable.tiger_illustration_1),
            loadAnimalTile(R.drawable.tiger_illustration_2),
            loadAnimalTile(R.drawable.tiger_illustration_3),
            loadAnimalTile(R.drawable.leopard_illustration_1),
            loadAnimalTile(R.drawable.leopard_illustration_2),
            loadAnimalTile(R.drawable.leopard_illustration_3),
            loadAnimalTile(R.drawable.snowleopard_illustration_1),
            loadAnimalTile(R.drawable.snowleopard_illustration_2),
            loadAnimalTile(R.drawable.snowleopard_illustration_3),
            loadAnimalTile(R.drawable.lion_illustration_1),
            loadAnimalTile(R.drawable.lion_illustration_2),
            loadAnimalTile(R.drawable.lion_illustration_3),
            loadAnimalTile(R.drawable.cat_bowl_illustration_1),
            loadAnimalTile(R.drawable.cat_bowl_illustration_2),
            loadAnimalTile(R.drawable.yarn_ball_illustration_1),
            loadAnimalTile(R.drawable.yarn_ball_illustration_2)
        };
        Bitmap loadAnimalTile(int resourceId) {
            // Decode at a modest size: artwork is displayed inside small tiles, so full-size
            // bitmaps waste memory and can contribute to Android killing the app on low-RAM phones.
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inSampleSize = 2;
            options.inPreferredConfig = Bitmap.Config.RGB_565;
            try {
                return BitmapFactory.decodeResource(getResources(), resourceId, options);
            } catch (RuntimeException | OutOfMemoryError ex) {
                return null;
            }
        }
        final int[] animalKinds = {16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37};

        int difficulty = 1, undosLeft = MAX_UNDOS, moves = 0, pairsRemoved = 0, shufflesLeft = 3;
        boolean paused = false, won = false, difficultyMenu = false;
        int hintA = -1, hintB = -1;
        String message = "Wybierz dwie takie same płytki";

        float headerBottom, rackTop, rackBottom, boardLeft, boardTop, boardRight, boardBottom;
        float tileW, tileH, gap, controlTop;
        final float[][] tileRects = new float[64][4];
        final float[][] buttonRects = new float[5][4];
        final float[][] modalRects = new float[3][4];
        int dragIndex = -1, selectedTile = -1, selectionBeforeTouch = -1;
        float downX, downY, dragX, dragY, dragOffsetX, dragOffsetY;
        boolean dragging = false;
        final int touchSlop = ViewConfiguration.get(MainActivity.this).getScaledTouchSlop();
        final float[] rackRect = new float[4];

        // Human-readable label used in the board header.
        String difficultyName() {
            switch (difficulty) {
                case 0: return "ŁATWY";
                case 2: return "TRUDNY";
                default: return "NORMALNY";
            }
        }

        // Store rectangle edges in the shared [left, top, right, bottom] format.
        void setRect(float[] rect, float left, float top, float right, float bottom) {
            if (rect == null || rect.length < 4) return;
            rect[0] = left;
            rect[1] = top;
            rect[2] = right;
            rect[3] = bottom;
        }

        Board() { super(MainActivity.this); setLayerType(View.LAYER_TYPE_SOFTWARE, null); newGame(1); }

        void newGame(int level) {
            difficulty = Math.max(0, Math.min(2, level));
            tiles.clear(); rack.clear(); history.clear();
            undosLeft = MAX_UNDOS; moves = 0; pairsRemoved = 0; shufflesLeft = 3;
            paused = false; won = false; difficultyMenu = false; hintA = hintB = -1;
            ArrayList<int[]> positions = makeLayout(difficulty);
            ArrayList<Integer> pairKinds = new ArrayList<>();
            // Keep all agreed animal categories represented at every difficulty.
            for (int k = 16; k <= 27 && pairKinds.size() < positions.size()/2; k++) pairKinds.add(k);
            // Fill remaining pairs with traditional Mahjong characters; repeat only when a layout needs more pairs.
            for (int k = 0; pairKinds.size() < positions.size()/2; k++) pairKinds.add(k % symbols.length);
            Collections.shuffle(pairKinds, random);
            ArrayList<Integer> kinds = new ArrayList<>();
            for (int k : pairKinds) { kinds.add(k); kinds.add(k); }
            Collections.shuffle(kinds, random);
            for (int i = 0; i < positions.size(); i++) {
                int[] q = positions.get(i);
                tiles.add(new Tile(kinds.get(i), q[0], q[1], q[2]));
            }
            message = "Wybierz dostępną płytkę";
            saveGame(); invalidate();
        }

        ArrayList<int[]> makeLayout(int level) {
            ArrayList<int[]> out = new ArrayList<>();
            // Hand-authored silhouettes rather than a rectangular grid. Rows are
            // deliberately staggered to create the compact, layered composition
            // in the approved reference. Tile counts remain even for pair matching.
            if (level == 0) {
                int[][] rows = {
                    {2,3,4,5},
                    {1,2,3,4,5},
                    {1,2,3,4,5},
                    {0,1,2,3,4,5},
                    {2,3}
                };
                for (int r=0;r<rows.length;r++) for (int c:rows[r]) out.add(new int[]{0,c,r});
            } else if (level == 1) {
                // 28 tiles in a six-row, staggered base + 8 raised tiles = 36.
                int[][] rows = {
                    {2,3,4},
                    {1,2,3,4,5},
                    {1,2,3,4,5,6},
                    {0,1,2,3,4,5},
                    {1,2,3,4,5},
                    {2,3,4}
                };
                for (int r=0;r<rows.length;r++) for (int c:rows[r]) out.add(new int[]{0,c,r});
                // Raised tiles form a compact central crown, not a second flat row.
                int[][] raised = {{2,1},{3,1},{4,1},{2,2},{3,2},{4,2},{2,3},{4,3}};
                for (int[] q:raised) out.add(new int[]{1,q[0],q[1]});
            } else {
                // 30-tile broad base + 11 raised tiles + 1 crown = 42 tiles.
                int[][] rows = {
                    {1,2,3,4},
                    {1,2,3,4,5},
                    {0,1,2,3,4,5},
                    {0,1,2,3,4,5,6},
                    {1,2,3,4,5},
                    {2,3,4}
                };
                for (int r=0;r<rows.length;r++) for (int c:rows[r]) out.add(new int[]{0,c,r});
                int[][] raised = {
                    {1,1},{2,1},{3,1},{4,1},{5,1},
                    {1,3},{2,3},{4,3},{5,3},
                    {2,2},{4,2}
                };
                for (int[] q:raised) out.add(new int[]{1,q[0],q[1]});
                out.add(new int[]{2,3,2});
            }
            return out;
        }

        int maxCol() { int m=0; for(Tile t:tiles) if(t.col>m) m=t.col; return m; }
        int maxRow() { int m=0; for(Tile t:tiles) if(t.row>m) m=t.row; return m; }
        float layerX() { return tileW*.11f; }
        float layerY() { return tileH*.075f; }
        float stepX(float usableW) { return (usableW-tileW-layerX()*2f)/Math.max(1,maxCol()); }
        float stepY(float usableH) { return Math.min(tileH*.96f,(usableH-tileH-layerY()*2f)/Math.max(1,maxRow())); }
        float tileX(Tile t,float left,float usableW) { return left+layerX()+t.col*stepX(usableW)+t.layer*layerX(); }
        float tileY(Tile t,float top,float usableH) { return top+t.row*stepY(usableH)-t.layer*layerY(); }

        boolean isAvailable(int index) {
            if(index<0 || index>=tiles.size()) return false;
            Tile t=tiles.get(index);
            if(t.removed) return false;

            float w=getWidth(), h=getHeight();
            if(w<=0 || h<=0 || tileW<=0 || tileH<=0) return isAvailableByGrid(index);
            float left=w*.035f, right=w*.965f, top=h*.305f, bottom=h*.875f;
            float usableW=right-left, usableH=bottom-top;
            float tx=tileX(t,left,usableW), ty=tileY(t,top,usableH);
            final float edgeTolerance=Math.max(2f,tileW*.16f);
            final float minVerticalOverlap=tileH*.45f;
            boolean covered=false, leftBlocked=false, rightBlocked=false;

            for(int j=0;j<tiles.size();j++) {
                if(j==index) continue;
                Tile o=tiles.get(j);
                if(o.removed) continue;
                float ox=tileX(o,left,usableW), oy=tileY(o,top,usableH);
                float overlapX=Math.min(tx+tileW,ox+tileW)-Math.max(tx,ox);
                float overlapY=Math.min(ty+tileH,oy+tileH)-Math.max(ty,oy);

                // A higher layer is drawn over this tile. Any substantial intersection
                // means the lower tile is covered, regardless of whether its sides are free.
                if(o.layer>t.layer && overlapX>tileW*.12f && overlapY>tileH*.12f) {
                    covered=true;
                    break;
                }

                // Side availability follows the logical Mahjong grid, not pixel-edge
                // distances. The rendered tiles intentionally overlap, so edge-distance
                // checks can incorrectly mark an exposed end tile as blocked on both sides.
                if(o.layer==t.layer && o.row==t.row) {
                    if(o.col==t.col-1) leftBlocked=true;
                    if(o.col==t.col+1) rightBlocked=true;
                }
            }
            return !covered && !(leftBlocked && rightBlocked);
        }

        boolean isAvailableByGrid(int index) {
            Tile t=tiles.get(index);
            boolean covered=false, leftBlocked=false, rightBlocked=false;
            for(int j=0;j<tiles.size();j++) {
                if(j==index) continue;
                Tile o=tiles.get(j);
                if(o.removed) continue;
                if(o.layer>t.layer && o.col==t.col && o.row==t.row) covered=true;
                if(o.layer==t.layer && o.row==t.row) {
                    if(o.col==t.col-1) leftBlocked=true;
                    if(o.col==t.col+1) rightBlocked=true;
                }
            }
            return !covered && !(leftBlocked && rightBlocked);
        }

        String stateJson() {
            try {
                JSONObject root=new JSONObject();
                root.put("version",2);
                root.put("difficulty",difficulty); root.put("undosLeft",undosLeft);
                root.put("moves",moves); root.put("pairsRemoved",pairsRemoved); root.put("shufflesLeft",shufflesLeft);
                root.put("paused",paused); root.put("won",won); root.put("message",message);
                JSONArray ts=new JSONArray();
                for(Tile t:tiles) {
                    JSONObject o=new JSONObject();
                    o.put("kind",t.kind); o.put("layer",t.layer); o.put("col",t.col);
                    o.put("row",t.row); o.put("removed",t.removed); ts.put(o);
                }
                root.put("tiles",ts);
                JSONArray rs=new JSONArray(); for(int k:rack) rs.put(k); root.put("rack",rs);
                JSONArray hs=new JSONArray(); for(String s:history) hs.put(s); root.put("history",hs);
                return root.toString();
            } catch(Exception e) { return ""; }
        }

        void saveGame() {
            if (!tiles.isEmpty()) prefs.edit().putString("state",stateJson()).apply();
        }

        void restoreSavedGame() {
            String saved=prefs.getString("state","");
            if(saved.isEmpty()) { invalidate(); return; }
            try {
                JSONObject root=new JSONObject(saved);
                int savedVersion=root.optInt("version",0);
                if(savedVersion < 2) {
                    int savedDifficulty=Math.max(0,Math.min(2,root.optInt("difficulty",1)));
                    newGame(savedDifficulty);
                    message="Nowy układ — poprawiono identyfikatory kafelków";
                    return;
                }
                tiles.clear(); rack.clear(); history.clear();
                difficulty=root.optInt("difficulty",1);
                undosLeft=Math.max(0,Math.min(MAX_UNDOS,root.optInt("undosLeft",MAX_UNDOS)));
                moves=Math.max(0,root.optInt("moves",0));
                pairsRemoved=Math.max(0,root.optInt("pairsRemoved",0));
                shufflesLeft=Math.max(0,Math.min(3,root.optInt("shufflesLeft",3)));
                paused=root.optBoolean("paused",false); won=root.optBoolean("won",false);
                message=root.optString("message","Wybierz dostępną płytkę");
                JSONArray ts=root.getJSONArray("tiles");
                for(int i=0;i<ts.length();i++) {
                    JSONObject o=ts.getJSONObject(i);
                    int kind=o.optInt("kind",0);
                    int layer=o.optInt("layer",0), col=o.optInt("col",0), row=o.optInt("row",0);
                    if(kind<0 || kind>=TOTAL_TILE_KINDS || layer<0 || layer>2 || col<0 || col>12 || row<0 || row>12) {
                        throw new IllegalArgumentException("Invalid saved tile data");
                    }
                    Tile t=new Tile(kind,layer,col,row);
                    t.removed=o.optBoolean("removed",false); tiles.add(t);
                }
                JSONArray rs=root.optJSONArray("rack");
                if(rs!=null) for(int i=0;i<rs.length() && i<RACK_SIZE;i++) {
                    int value=rs.getInt(i);
                    if(value>=0 && value<TOTAL_TILE_KINDS) rack.add(value);
                }
                JSONArray hs=root.optJSONArray("history");
                if(hs!=null) for(int i=0;i<hs.length();i++) history.add(hs.getString(i));
            } catch(Exception e) { newGame(1); }
            invalidate();
        }

        void saveUndo() {
            history.add(stateJsonWithoutHistory());
            if(history.size()>MAX_UNDOS) history.remove(0);
        }

        String stateJsonWithoutHistory() {
            ArrayList<String> old = new ArrayList<>(history);
            history.clear();
            String s=stateJson();
            history.addAll(old);
            return s;
        }

        void undo() {
            if(undosLeft<=0 || history.isEmpty()) { message="Brak dostepnego cofniecia"; invalidate(); return; }
            String s=history.remove(history.size()-1);
            try {
                JSONObject root=new JSONObject(s);
                tiles.clear(); rack.clear();
                difficulty=root.optInt("difficulty",difficulty);
                moves=root.optInt("moves",moves); pairsRemoved=root.optInt("pairsRemoved",pairsRemoved); shufflesLeft=root.optInt("shufflesLeft",3);
                JSONArray ts=root.getJSONArray("tiles");
                for(int i=0;i<ts.length();i++) {
                    JSONObject o=ts.getJSONObject(i);
                    int kind=o.optInt("kind",0);
                    int layer=o.optInt("layer",0), col=o.optInt("col",0), row=o.optInt("row",0);
                    if(kind<0 || kind>=TOTAL_TILE_KINDS || layer<0 || layer>2 || col<0 || col>12 || row<0 || row>12) {
                        throw new IllegalArgumentException("Invalid saved tile data");
                    }
                    Tile t=new Tile(kind,layer,col,row);
                    t.removed=o.optBoolean("removed",false); tiles.add(t);
                }
                JSONArray rs=root.optJSONArray("rack");
                if(rs!=null) for(int i=0;i<rs.length() && i<RACK_SIZE;i++) {
                    int value=rs.getInt(i);
                    if(value>=0 && value<TOTAL_TILE_KINDS) rack.add(value);
                }
                undosLeft--; won=false; paused=false; hintA=hintB=-1;
                message="Cofnieto ostatni ruch";
            } catch(Exception e) { message="Nie udało się cofnac ruchu"; }
            saveGame(); invalidate();
        }


        void removeBoardPair(int first, int second) {
            if(first<0 || second<0 || first>=tiles.size() || second>=tiles.size()
                    || first==second || tiles.get(first).removed || tiles.get(second).removed
                    || !isAvailable(first) || !isAvailable(second)
                    || !sameTileType(tiles.get(first).kind, tiles.get(second).kind)) {
                message="Para niedostępna lub kafelki nie pasują"; invalidate(); return;
            }
            saveUndo();
            tiles.get(first).removed=true;
            tiles.get(second).removed=true;
            moves++;
            pairsRemoved++;
            selectedTile=-1;
            hintA=hintB=-1;
            boolean any=false;
            for(Tile t:tiles) if(!t.removed) { any=true; break; }
            if(!any) { won=true; message="WYGRANA! Wszystkie plytki usuniete."; }
            else message="Para usunięta";
            saveGame();
            invalidate();
        }

        void pick(int i) {
            if(i<0 || i>=tiles.size() || !isAvailable(i) || paused || won) return;
            int kind=tiles.get(i).kind;
            boolean canMatchRack=false;
            for(int rackKind : rack) if(sameTileType(rackKind,kind)) { canMatchRack=true; break; }
            if(rack.size()>=RACK_SIZE && !canMatchRack) {
                message="Schowek pelny — cofnij ruch"; invalidate(); return;
            }
            saveUndo();
            tiles.get(i).removed=true; moves++;
            int match=-1;
            for(int r=0;r<rack.size();r++) {
                if(sameTileType(rack.get(r),kind)) { match=r; break; }
            }
            if(match>=0) {
                rack.remove(match);
                pairsRemoved++;
                message="Para usunięta";
            } else {
                rack.add(kind);
                message="Płytka trafiła do schowka";
            }
            hintA=hintB=-1;
            boolean any=false; for(Tile t:tiles) if(!t.removed) { any=true; break; }
            if(!any) { won=true; message="WYGRANA! Wszystkie plytki usuniete."; }
            else if(rack.size()==RACK_SIZE) message="Schowek pelny — dopasuj plytke lub cofnij";
            saveGame(); invalidate();
        }

        void shuffleRemainingTiles() {
            if(paused || won || difficultyMenu) return;
            if(shufflesLeft<=0) {
                message="Wykorzystano wszystkie 3 tasowania";
                invalidate();
                return;
            }

            // Preserve the exact board layout: only tile kinds are reassigned to existing
            // active board/rack slots. Coordinates, layers, removed flags and move count stay.
            ArrayList<Integer> boardIndexes = new ArrayList<>();
            ArrayList<Integer> kinds = new ArrayList<>();
            for(int i=0;i<tiles.size();i++) {
                Tile t=tiles.get(i);
                if(!t.removed) {
                    boardIndexes.add(i);
                    kinds.add(t.kind);
                }
            }
            kinds.addAll(rack);
            if(kinds.size()<2) {
                message="Za mało kafelków do tasowania";
                invalidate();
                return;
            }

            ArrayList<Integer> originalKinds = new ArrayList<>(kinds);
            ArrayList<Integer> chosen = null;
            int boardCount=boardIndexes.size();
            int rackCount=rack.size();

            // Prefer a shuffle that doesn't create duplicate matching types in the rack.
            for(int attempt=0;attempt<100;attempt++) {
                Collections.shuffle(kinds,random);
                boolean validRack=true;
                for(int a=boardCount;a<boardCount+rackCount && validRack;a++) {
                    for(int b=a+1;b<boardCount+rackCount;b++) {
                        if(sameTileType(kinds.get(a),kinds.get(b))) {
                            validRack=false;
                            break;
                        }
                    }
                }
                if(validRack) { chosen=new ArrayList<>(kinds); break; }
            }

            if(chosen==null) {
                // Safe fallback: shuffle only active board tiles and leave the rack untouched.
                chosen=new ArrayList<>(originalKinds);
                ArrayList<Integer> boardKinds=new ArrayList<>(chosen.subList(0,boardCount));
                Collections.shuffle(boardKinds,random);
                for(int i=0;i<boardCount;i++) chosen.set(i,boardKinds.get(i));
                for(int i=0;i<rackCount;i++) chosen.set(boardCount+i,rack.get(i));
            }

            boolean changed=false;
            for(int i=0;i<boardCount;i++) {
                Tile t=tiles.get(boardIndexes.get(i));
                int newKind=chosen.get(i);
                if(t.kind!=newKind) changed=true;
            }
            for(int i=0;i<rackCount;i++) {
                if(rack.get(i).intValue()!=chosen.get(boardCount+i).intValue()) changed=true;
            }
            if(!changed) {
                message="Tasowanie nie zmieniło układu symboli — spróbuj ponownie";
                invalidate();
                return;
            }

            saveUndo();
            shufflesLeft--;
            for(int i=0;i<boardCount;i++) tiles.get(boardIndexes.get(i)).kind=chosen.get(i);
            rack.clear();
            for(int i=0;i<rackCount;i++) rack.add(chosen.get(boardCount+i));
            selectedTile=-1;
            hintA=hintB=-1;
            message="Kafelki przetasowane — pozostało tasowań: "+shufflesLeft;
            saveGame();
            invalidate();
        }

        int canonicalTileType(int kind) {
            // Identical Rudy 2/3 artwork uses one shared pair type.
            return kind == 18 ? 17 : kind;
        }

        boolean sameTileType(int a, int b) {
            // Matching compares pair types, never unique tile-instance IDs.
            return canonicalTileType(a) == canonicalTileType(b);
        }

        void hint() {
            hintA=hintB=-1;
            for(int i=0;i<tiles.size();i++) if(isAvailable(i))
                for(int j=i+1;j<tiles.size();j++)
                    if(isAvailable(j) && sameTileType(tiles.get(i).kind,tiles.get(j).kind)) {
                        hintA=i; hintB=j; message="Podswietlono pasujaca pare"; invalidate(); return;
                    }
            message="Nie widze teraz pasujacej pary"; invalidate();
        }

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            // Clear hit rectangles each frame so removed or hidden tiles cannot leave stale hit targets.
            for(int i=0;i<tileRects.length;i++) {
                tileRects[i][0]=-1; tileRects[i][1]=-1; tileRects[i][2]=-1; tileRects[i][3]=-1;
            }
            float w=getWidth(), h=getHeight();
            p.setStyle(Paint.Style.FILL);
            p.setShader(new LinearGradient(0,0,w,h,Color.rgb(7,39,31),Color.rgb(24,83,61),Shader.TileMode.CLAMP));
            c.drawRect(0,0,w,h,p); p.setShader(null);
            // Walnut wood rails around the play surface, with a subtle warm grain.
            float rail = Math.max(5f,w*.022f);
            p.setShader(new LinearGradient(0,0,w,0,
                    new int[]{Color.rgb(31,18,13),Color.rgb(92,52,28),Color.rgb(132,83,43),Color.rgb(52,29,19)},
                    null,Shader.TileMode.CLAMP));
            c.drawRect(0,0,w,rail*1.35f,p);
            c.drawRect(0,h*.13f-rail*.55f,w,h*.13f+rail*.55f,p);
            c.drawRect(0,h*.86f-rail*.55f,w,h*.86f+rail*.55f,p);
            c.drawRect(0,h-rail*1.35f,w,h,p);
            c.drawRect(0,0,rail,h,p);
            c.drawRect(w-rail,0,w,h,p);
            p.setShader(null);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(Math.max(1f,w*.002f));
            p.setColor(Color.rgb(207,159,76));
            c.drawRect(rail*.3f,rail*.3f,w-rail*.3f,h-rail*.3f,p);
            p.setStrokeWidth(Math.max(.7f,w*.0009f));
            p.setColor(Color.argb(200,246,214,145));
            c.drawRect(rail*.8f,rail*.8f,w-rail*.8f,h-rail*.8f,p);
            p.setStyle(Paint.Style.FILL);
            // Target look: a restrained walnut-and-gold frame around the emerald felt.
            p.setStyle(Paint.Style.FILL);
            p.setShader(new LinearGradient(0,0,w,0,
                    new int[]{Color.rgb(35,20,14),Color.rgb(111,66,35),Color.rgb(46,27,18)},
                    null,Shader.TileMode.CLAMP));
            c.drawRect(0,0,w,h,p); p.setShader(null);
            p.setColor(Color.rgb(9,48,36));
            c.drawRect(w*.018f, h*.008f, w*.982f, h*.992f, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(Math.max(1.2f,w*.003f));
            p.setColor(Color.rgb(183,133,57));
            c.drawRoundRect(new RectF(w*.012f,h*.006f,w*.988f,h*.994f),w*.018f,w*.018f,p);
            p.setStrokeWidth(Math.max(.7f,w*.0012f));
            p.setColor(Color.argb(180,244,211,139));
            c.drawRoundRect(new RectF(w*.022f,h*.014f,w*.978f,h*.986f),w*.014f,w*.014f,p);
            // Subtle botanical texture on the green felt; decorative only.
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeWidth(Math.max(1f,w*.003f));
            for (int side=0; side<2; side++) {
                float bx = side==0 ? w*.018f : w*.982f;
                float dir = side==0 ? 1f : -1f;
                p.setColor(Color.argb(20,176,198,126));
                c.drawLine(bx,h*.37f,bx+dir*w*.035f,h*.72f,p);
                for (int leaf=0; leaf<5; leaf++) {
                    float ly=h*(.405f+leaf*.058f);
                    Path leafPath=new Path();
                    leafPath.moveTo(bx+dir*w*.009f,ly);
                    leafPath.quadTo(bx+dir*w*.025f,ly-h*.018f,bx+dir*w*.041f,ly-h*.012f);
                    c.drawPath(leafPath,p);
                    leafPath.reset();
                    leafPath.moveTo(bx+dir*w*.014f,ly+h*.018f);
                    leafPath.quadTo(bx+dir*w*.028f,ly+h*.035f,bx+dir*w*.043f,ly+h*.025f);
                    c.drawPath(leafPath,p);
                }
            }
            p.setStyle(Paint.Style.FILL);
            headerBottom=h*.135f;
            p.setShader(new LinearGradient(0,0,0,headerBottom,
                    new int[]{Color.rgb(105,62,31),Color.rgb(57,31,19),Color.rgb(91,51,27)},
                    null,Shader.TileMode.CLAMP));
            c.drawRect(rail,0,w-rail,headerBottom,p); p.setShader(null);
            // Restrained horizontal grain lines, decorative only.
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(Math.max(.7f,w*.001f));
            p.setColor(Color.argb(36,235,187,115));
            for(int grain=0;grain<5;grain++) {
                float gy=headerBottom*(.12f+grain*.17f);
                c.drawLine(w*.04f,gy,w*.96f,gy,p);
            }
            p.setStyle(Paint.Style.FILL);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(Math.max(1f,w*.002f));
            p.setColor(Color.rgb(207,159,76));
            c.drawRoundRect(new RectF(w*.012f,h*.008f,w*.988f,headerBottom-h*.008f),w*.018f,w*.018f,p);
            p.setStrokeWidth(Math.max(.7f,w*.0009f));
            p.setColor(Color.argb(190,246,214,145));
            c.drawRoundRect(new RectF(w*.024f,h*.018f,w*.976f,headerBottom-h*.018f),w*.012f,w*.012f,p);
            p.setStyle(Paint.Style.FILL);
            p.setColor(gold); c.drawRect(0,headerBottom-2,w,headerBottom,p);
            p.setShader(new LinearGradient(0,h*.86f,0,h,
                    new int[]{Color.rgb(101,59,30),Color.rgb(45,25,17),Color.rgb(79,44,24)},
                    null,Shader.TileMode.CLAMP));
            c.drawRect(rail,h*.86f,w-rail,h-rail,p); p.setShader(null);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(Math.max(.7f,w*.001f));
            p.setColor(Color.argb(34,235,187,115));
            for(int grain=0;grain<4;grain++) {
                float gy=h*(.875f+grain*.027f);
                c.drawLine(w*.035f,gy,w*.965f,gy,p);
            }
            p.setStyle(Paint.Style.FILL);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1f); p.setColor(Color.argb(12,238,211,154));
            for(int k=0;k<7;k++){ float cx=(k+.5f)*w/7f, cy=h*.56f; c.drawCircle(cx,cy,Math.min(w,h)*.12f,p); c.drawCircle(cx,cy,Math.min(w,h)*.105f,p); }
            // Faint traditional cloud/coin medallions in the felt, kept away from touch logic.
            p.setStrokeWidth(Math.max(1f,w*.0016f));
            for (int k=0;k<4;k++) {
                float mx=w*(.16f+k*.23f), my=h*.69f, mr=Math.min(w,h)*.026f;
                p.setColor(Color.argb(14,226,194,121));
                c.drawCircle(mx,my,mr,p);
                c.drawCircle(mx,my,mr*.68f,p);
                c.drawLine(mx-mr*.42f,my,mx+mr*.42f,my,p);
                c.drawLine(mx,my-mr*.42f,mx,my+mr*.42f,p);
            }
            p.setStyle(Paint.Style.FILL);
            // Single restrained corner decoration. The outer walnut frame is drawn once;
            // avoid separate header/board/footer rectangles that created intersecting lines.
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(Math.max(1f,w*.0015f));
            p.setColor(Color.argb(165,201,157,82));
            float corner=Math.min(w,h)*.022f;
            float inset=w*.027f;
            float[] xs={inset,w-inset};
            float[] ys={h*.018f,h*.982f};
            for(float xx:xs) for(float yy:ys) {
                float dx=xx< w/2f ? 1f : -1f;
                float dy=yy< h/2f ? 1f : -1f;
                c.drawLine(xx,yy,xx+dx*corner,yy,p);
                c.drawLine(xx,yy,xx,yy+dy*corner,p);
                c.drawLine(xx+dx*corner*.32f,yy+dy*corner*.32f,
                           xx+dx*corner*.72f,yy+dy*corner*.72f,p);
            }
            p.setStyle(Paint.Style.FILL);

            // Visual milestone 2: integrate the Chinese landscape into the wood banner.
            // Unlike the previous floating card, this panorama has no boxed background;
            // the timber grain remains visible behind it, closer to the approved reference.
            p.setTextAlign(Paint.Align.LEFT); p.setTypeface(Typeface.create("serif", Typeface.BOLD));
            p.setFakeBoldText(true); p.setTextSize(Math.min(w*.058f,40));
            p.setShader(new LinearGradient(0,h*.025f,0,h*.078f,
                    new int[]{Color.rgb(255,232,157),Color.rgb(221,173,78),Color.rgb(155,98,35)},
                    null,Shader.TileMode.CLAMP));
            c.drawText("Mahjong D",w*.04f,h*.065f,p); p.setShader(null);
            p.setFakeBoldText(false);
            float vx=w*.365f, vy=h*.024f, vw=w*.265f, vh=h*.078f;
            // Distant mountains, low-contrast so they decorate rather than obscure the title.
            p.setColor(Color.rgb(67,43,27));
            Path ridge=new Path(); ridge.moveTo(vx,vy+vh*.91f);
            ridge.lineTo(vx+vw*.12f,vy+vh*.55f); ridge.lineTo(vx+vw*.22f,vy+vh*.72f);
            ridge.lineTo(vx+vw*.39f,vy+vh*.37f); ridge.lineTo(vx+vw*.51f,vy+vh*.68f);
            ridge.lineTo(vx+vw*.68f,vy+vh*.48f); ridge.lineTo(vx+vw*.84f,vy+vh*.72f);
            ridge.lineTo(vx+vw,vy+vh*.56f); ridge.lineTo(vx+vw,vy+vh*.96f); ridge.close(); c.drawPath(ridge,p);
            // Warm moon and a tiny pagoda silhouette provide a recognisable Chinese motif.
            p.setColor(Color.rgb(211,157,73)); c.drawCircle(vx+vw*.52f,vy+vh*.31f,vh*.19f,p);
            p.setColor(Color.rgb(42,27,18));
            float px=vx+vw*.78f, py=vy+vh*.64f;
            Path pagoda=new Path(); pagoda.moveTo(px-vw*.09f,py); pagoda.lineTo(px,py-vh*.12f);
            pagoda.lineTo(px+vw*.09f,py); pagoda.lineTo(px+vw*.055f,py+vh*.025f);
            pagoda.lineTo(px+vw*.045f,py+vh*.18f); pagoda.lineTo(px-vw*.045f,py+vh*.18f);
            pagoda.lineTo(px-vw*.055f,py+vh*.025f); pagoda.close(); c.drawPath(pagoda,p);
            p.setStrokeWidth(Math.max(1f,w*.001f)); p.setStyle(Paint.Style.STROKE);
            p.setColor(Color.argb(105,235,190,105));
            c.drawLine(vx+vw*.03f,vy+vh*.94f,vx+vw*.97f,vy+vh*.94f,p);
            p.setStyle(Paint.Style.FILL);
            p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL)); p.setTextAlign(Paint.Align.RIGHT);
            p.setColor(Color.rgb(246,221,157)); p.setTextSize(Math.min(w*.029f,20));
            c.drawText(difficultyName(),w*.96f,h*.052f,p);
            p.setColor(cream); p.setTextSize(Math.min(w*.026f,18));
            c.drawText("Pary: "+pairsRemoved+"/"+(tiles.size()/2)+"   Ruchy: "+moves,w*.96f,h*.102f,p);

            // Rack is anchored to the top of the playing field, never over the board.
            float rackW=w*.84f, rackX=(w-rackW)/2f;
            rackTop=h*.155f; rackBottom=h*.255f;
            rackRect[0]=rackX; rackRect[1]=rackTop; rackRect[2]=rackX+rackW; rackRect[3]=rackBottom;
            p.setColor(Color.rgb(103,65,37));
            c.drawRoundRect(new RectF(rackX,rackTop,rackX+rackW,rackBottom),12,12,p);
            float slotW=rackW/5f;
            for(int s=0;s<5;s++) {
                float l=rackX+s*slotW+3, t=rackTop+3, r=l+slotW-6, b=rackBottom-3;
                p.setColor(Color.rgb(37,28,21)); c.drawRoundRect(new RectF(l,t,r,b),7,7,p);
                if(s<rack.size()) drawTileFace(c,l+2,t+2,slotW-10,b-t-4,rack.get(s),false);
            }
            p.setTextAlign(Paint.Align.CENTER); p.setColor(cream);
            p.setTextSize(Math.min(w*.029f,20));
            c.drawText("Schowek "+rack.size()+"/5",w/2f,h*.285f,p);

            // Responsive board: tile rectangles are computed once and reused for hit testing.
            boardLeft=w*.035f; boardRight=w*.965f;
            boardTop=h*.305f; boardBottom=h*.875f;
            float usableW=boardRight-boardLeft, usableH=boardBottom-boardTop;
            tileW=usableW/5.0f; // Enlarge tiles about 16% and use more of the board width.
            tileH=tileW*1.20f;
            if(tileH*3.55f>usableH) { tileH=usableH/3.55f; tileW=tileH/1.20f; }
            for(int i=0;i<tileRects.length;i++) { tileRects[i][0]=-1; tileRects[i][1]=-1; tileRects[i][2]=-1; tileRects[i][3]=-1; }

            // Keep every layer inside the board without clamping. Clamping made edge tiles
            // from different columns share the same screen rectangle while availability used
            // their original grid coordinates — the source of false blocked/free tiles.
            // Keep layer offsets visually restrained. Large offsets made the borders of
            // several neighboring tiles show through as multiple ghost frames.
            // Give stacked layers a visible but restrained offset so lower tiles remain identifiable.
            // Keep layers aligned horizontally to avoid neighboring frames ghosting over each other.
            // A small vertical offset still reveals the lower tile edges.
            float layerOffsetX=layerX(), layerOffsetY=layerY();
            float stepX=stepX(usableW), stepY=stepY(usableH);
            for(int layer=0;layer<3;layer++) for(int i=0;i<tiles.size();i++) {
                Tile t=tiles.get(i);
                if(t.removed || t.layer!=layer || (dragging && i==dragIndex)) continue;
                float x=tileX(t,boardLeft,usableW);
                float y=tileY(t,boardTop,usableH);
                tileRects[i][0]=x; tileRects[i][1]=y; tileRects[i][2]=x+tileW; tileRects[i][3]=y+tileH;
                boolean available=isAvailable(i);
                drawTileFace(c,x,y,tileW,tileH,t.kind,!available);
            }

            // Hint: outline only the part of each hinted tile that is actually visible.
            // Later-drawn tiles are subtracted from the canvas clip so the glow never crosses
            // a tile lying above it. No fill, numbers or extra inner frames are added.
            p.setShader(null);
            p.setAlpha(255);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeJoin(Paint.Join.ROUND);
            p.setStrokeJoin(Paint.Join.ROUND);
            for(int idx : new int[]{hintA, hintB}) {
                if(idx<0 || idx>=tiles.size() || tiles.get(idx).removed) continue;
                float[] r=tileRects[idx];
                if(r[0]<0) continue;
                int save=c.save();
                Tile target=tiles.get(idx);
                // Subtract every tile painted after this tile. This follows the exact
                // layer/index draw order used above, including partial overlap.
                for(int j=0;j<tiles.size();j++) {
                    if(j==idx || tiles.get(j).removed) continue;
                    Tile other=tiles.get(j);
                    boolean paintedAfter = other.layer>target.layer || (other.layer==target.layer && j>idx);
                    if(!paintedAfter) continue;
                    float[] cover=tileRects[j];
                    if(cover[0]<0) continue;
                    if(Math.min(r[2],cover[2])>Math.max(r[0],cover[0]) &&
                       Math.min(r[3],cover[3])>Math.max(r[1],cover[1])) {
                        // Subtract the rounded tile silhouette, not its rectangular bounds.
                        // This keeps the hint from leaving square gaps around rounded corners.
                        Path coverShape=new Path();
                        coverShape.addRoundRect(new RectF(cover[0],cover[1],cover[2],cover[3]),
                                Math.max(5f,tileW*.09f),Math.max(5f,tileW*.09f),Path.Direction.CW);
                        c.clipPath(coverShape,Region.Op.DIFFERENCE);
                    }
                }
                RectF outline=new RectF(r[0]+2f,r[1]+2f,r[2]-2f,r[3]-2f);
                p.setColor(Color.rgb(88,53,18));
                p.setStrokeWidth(Math.max(3.5f,tileW*.027f));
                p.setShadowLayer(Math.max(2f,tileW*.022f),0f,0f,Color.argb(190,255,190,55));
                c.drawRoundRect(outline,7f,7f,p);
                p.clearShadowLayer();
                p.setColor(Color.rgb(255,205,83));
                p.setStrokeWidth(Math.max(2f,tileW*.014f));
                c.drawRoundRect(outline,7f,7f,p);
                c.restoreToCount(save);
            }
            p.clearShadowLayer();
            p.setStyle(Paint.Style.FILL);

            if(dragging && dragIndex>=0 && dragIndex<tiles.size()) {
                p.setColor(Color.argb(75,0,0,0));
                c.drawRoundRect(new RectF(dragX+4,dragY+5,dragX+tileW+4,dragY+tileH+5),8,8,p);
                drawTileFace(c,dragX,dragY,tileW,tileH,tiles.get(dragIndex).kind,false);
            }
            if(selectedTile>=0 && selectedTile<tiles.size() && !tiles.get(selectedTile).removed && !dragging
                    && selectedTile!=hintA && selectedTile!=hintB) {
                float[] sr=tileRects[selectedTile];
                if(sr[0]>=0) { p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(3f); p.setColor(Color.rgb(255,211,105)); c.drawRoundRect(new RectF(sr[0]-3,sr[1]-3,sr[2]+3,sr[3]+3),8,8,p); p.setStyle(Paint.Style.FILL); }
            }
            controlTop=h*.875f;
            float left=w*.025f, right=w*.975f, bw=(right-left)/5f;
            String[] labels={"Cofnij ("+undosLeft+")","Nowa gra","Podpowiedź","Pauza","Tasuj ("+shufflesLeft+")"};
            for(int i=0;i<5;i++) {
                setRect(buttonRects[i],left+i*bw+2,controlTop,left+(i+1)*bw-2,h*.945f);
                drawButton(c,buttonRects[i],labels[i]);
            }
            p.setColor(cream); p.setTextAlign(Paint.Align.CENTER); p.setTextSize(Math.min(w*.027f,18));
            c.drawText(message,w/2f,h*.975f,p);
            if(paused || won || difficultyMenu) drawOverlay(c,w,h);
        }

        // Kept separate to make the responsive sizing calculation explicit.
        void gapX(float usableW,float tw) { gap=Math.max(2f,(usableW-8*tw)/7f); }

        void drawTileFace(Canvas c,float x,float y,float tw,float th,int kind,boolean dim) {
            // Tile is constructed as a single 3D body: the visible top face is inset
            // from the right and bottom edges, while the side planes occupy that space.
            // This avoids the old appearance of dark strips glued onto a flat rectangle.
            p.reset();
            p.setAntiAlias(true);
            p.setFilterBitmap(true);
            p.setDither(true);
            p.setAlpha(255);
            p.setStyle(Paint.Style.FILL);
            p.setShader(null);

            // One coherent tile body: side planes are drawn first, then the opaque top.
            // Preserve visible ceramic thickness, but keep the side planes proportional
            // to the top face so they read as one solid object rather than attached strips.
            float depthX=Math.max(3f,tw*.072f);
            float depthY=Math.max(4f,th*.082f);
            float faceW=tw-depthX;
            float faceH=th-depthY;
            float rad=Math.max(4f,Math.min(faceW,faceH)*.075f);

            // Cast shadow sits behind the complete body; it never changes tile opacity.
            p.setStyle(Paint.Style.FILL);
            p.setShader(null);
            p.setColor(Color.argb(105,7,5,3));
            p.setShadowLayer(Math.max(2f,tw*.035f),tw*.012f,depthY*.45f,Color.argb(100,0,0,0));
            c.drawRoundRect(new RectF(x+1f,y+2f,x+tw+1f,y+th+depthY*.28f),rad,rad,p);
            p.clearShadowLayer();

            // Right side is a single attached plane between the top face and outer edge.
            Path rightSide=new Path();
            rightSide.moveTo(x+faceW-rad*.30f,y+rad*.55f);
            rightSide.lineTo(x+tw-rad*.20f,y+depthY*.18f);
            rightSide.lineTo(x+tw,y+depthY*.62f);
            rightSide.lineTo(x+tw,y+faceH-rad*.30f+depthY);
            rightSide.lineTo(x+faceW-rad*.22f,y+faceH);
            rightSide.close();
            p.setShader(new LinearGradient(x+faceW,y,x+tw,y+depthY,
                    new int[]{Color.rgb(181,137,79),Color.rgb(119,76,39),Color.rgb(62,38,22)},
                    null,Shader.TileMode.CLAMP));
            c.drawPath(rightSide,p);
            p.setShader(null);

            // Bottom plane joins the left and right sides continuously, with no extra outline.
            Path bottomSide=new Path();
            bottomSide.moveTo(x+rad*.55f,y+faceH-rad*.22f);
            bottomSide.lineTo(x+faceW-rad*.22f,y+faceH);
            bottomSide.lineTo(x+tw,y+th-depthY*.05f);
            bottomSide.lineTo(x+depthX*.22f,y+th);
            bottomSide.lineTo(x,y+faceH-rad*.40f);
            bottomSide.close();
            p.setShader(new LinearGradient(x,y+faceH,x,y+th,
                    new int[]{Color.rgb(190,145,83),Color.rgb(126,78,39),Color.rgb(57,34,20)},
                    null,Shader.TileMode.CLAMP));
            c.drawPath(bottomSide,p);
            p.setShader(null);

            // No separate edge stroke: the joined side plane itself defines the front edge.

            // The top face is a single fully opaque ceramic surface.
            RectF face=new RectF(x,y,x+faceW,y+faceH);
            p.setAlpha(255);
            p.setShader(new LinearGradient(x,y,x+faceW,y+faceH,
                    dim?Color.rgb(216,207,184):Color.rgb(255,251,235),
                    dim?Color.rgb(188,174,143):Color.rgb(237,220,181),
                    Shader.TileMode.CLAMP));
            c.drawRoundRect(face,rad,rad,p);
            p.setShader(null);
            p.setAlpha(255);

            // Fine antique-gold inset and restrained corner filigree, matching the approved tile reference.
            // These details are drawn on the ceramic face itself, never as a second heavy frame.
            float inset=Math.max(2f,Math.min(faceW,faceH)*.045f);
            float line=Math.max(0.7f,Math.min(faceW,faceH)*.006f);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(line);
            p.setColor(Color.argb(dim?95:145,164,119,54));
            RectF innerEdge=new RectF(x+inset,y+inset,x+faceW-inset,y+faceH-inset);
            c.drawRoundRect(innerEdge,Math.max(2f,rad*.48f),Math.max(2f,rad*.48f),p);
            p.setStyle(Paint.Style.FILL);
            // Small leaf-like corner ornaments; deliberately subtle so the artwork remains dominant.
            float orn=Math.min(faceW,faceH)*.105f;
            int ornamentColor=Color.argb(dim?115:205,177,126,51);
            for(int corner=0;corner<4;corner++) {
                float ox=(corner==0||corner==2)?x+inset*1.45f:x+faceW-inset*1.45f;
                float oy=(corner==0||corner==1)?y+inset*1.45f:y+faceH-inset*1.45f;
                float sx=(corner==0||corner==2)?1f:-1f;
                float sy=(corner==0||corner==1)?1f:-1f;
                p.setColor(ornamentColor);
                Path flourish=new Path();
                flourish.moveTo(ox,oy+sy*orn*.78f);
                flourish.quadTo(ox+sx*orn*.05f,oy+sy*orn*.05f,ox+sx*orn*.78f,oy);
                flourish.quadTo(ox+sx*orn*.48f,oy+sy*orn*.08f,ox+sx*orn*.32f,oy+sy*orn*.36f);
                flourish.quadTo(ox+sx*orn*.12f,oy+sy*orn*.25f,ox,oy+sy*orn*.78f);
                flourish.close();
                c.drawPath(flourish,p);
                p.setColor(Color.argb(dim?90:155,125,87,38));
                p.setStrokeWidth(line);
                c.drawLine(ox,oy,ox+sx*orn*.78f,oy,p);
                c.drawLine(ox,oy,ox,oy+sy*orn*.78f,p);
            }
            p.setStyle(Paint.Style.FILL);

            float cx=x+faceW/2f, cy=y+faceH*.49f;
            int animalIndex=-1;
            for(int ai=0;ai<animalKinds.length;ai++) if(animalKinds[ai]==kind){animalIndex=ai;break;}
            if(animalIndex>=0) {
                Bitmap art=animalTiles[animalIndex];
                if(art==null || art.isRecycled() || art.getWidth()<=0 || art.getHeight()<=0) {
                    p.setColor(dim?Color.rgb(103,102,88):Color.rgb(37,105,69));
                    p.setTextAlign(Paint.Align.CENTER); p.setFakeBoldText(true);
                    p.setTextSize(Math.min(faceW*.42f,faceH*.34f));
                    c.drawText("動物",cx,y+faceH*.55f,p); p.setFakeBoldText(false);
                    return;
                }
                // Art is drawn directly on the ceramic face. No additional picture frame is added.
                RectF inner=new RectF(x+faceW*.13f,y+faceH*.12f,x+faceW*.87f,y+faceH*.86f);
                float sourceRatio=(float)art.getWidth()/(float)art.getHeight();
                float targetRatio=inner.width()/inner.height();
                RectF artDst=new RectF(inner);
                if(sourceRatio>targetRatio) {
                    float fittedHeight=inner.width()/sourceRatio;
                    float top=inner.centerY()-fittedHeight/2f;
                    artDst.set(inner.left,top,inner.right,top+fittedHeight);
                } else {
                    float fittedWidth=inner.height()*sourceRatio;
                    float left=inner.centerX()-fittedWidth/2f;
                    artDst.set(left,inner.top,left+fittedWidth,inner.bottom);
                }
                p.setAlpha(255); p.setFilterBitmap(true); p.setShader(null);
                c.drawBitmap(art,null,artDst,p);
            } else {
                int[] inks={Color.rgb(37,105,69),Color.rgb(37,105,69),Color.rgb(37,105,69),Color.rgb(37,105,69),Color.rgb(37,105,69),Color.rgb(37,105,69),Color.rgb(37,105,69),Color.rgb(37,105,69),Color.rgb(37,105,69),Color.rgb(37,105,69),Color.rgb(37,105,69),Color.rgb(37,105,69),Color.rgb(37,105,69),Color.rgb(164,43,37),Color.rgb(35,112,67),Color.rgb(42,54,48)};
                int symbolIndex=Math.floorMod(kind-38,symbols.length);
                float rr=Math.min(faceW,faceH)*.325f;
                p.setShader(new RadialGradient(cx-rr*.25f,cy-rr*.3f,rr,
                        new int[]{Color.rgb(255,255,246),Color.rgb(244,229,194),Color.rgb(218,193,143)},
                        null,Shader.TileMode.CLAMP));
                c.drawCircle(cx,cy,rr,p); p.setShader(null);
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(Math.max(1f,faceW*.012f));
                p.setColor(Color.argb(170,151,112,55)); c.drawCircle(cx,cy,rr,p); p.setStyle(Paint.Style.FILL);
                p.setColor(dim?Color.rgb(103,102,88):inks[symbolIndex]);
                p.setTextAlign(Paint.Align.CENTER); p.setFakeBoldText(true);
                p.setTextSize(Math.min(faceW*.53f,faceH*.43f));
                c.drawText(symbols[symbolIndex],cx,y+faceH*.61f,p); p.setFakeBoldText(false);
                p.setColor(Color.argb(dim?70:145,151,112,55)); p.setStrokeWidth(Math.max(1f,faceW*.012f));
                c.drawLine(x+faceW*.29f,y+faceH*.79f,x+faceW*.71f,y+faceH*.79f,p);
                c.drawCircle(cx,y+faceH*.79f,Math.max(1f,faceW*.018f),p);
            }
            p.setShader(null); p.setAlpha(255); p.setStyle(Paint.Style.FILL);
        }

        boolean inside(float[] r,float x,float y) { return x>=r[0]&&x<=r[2]&&y>=r[1]&&y<=r[3]; }

        void drawButton(Canvas c,float[] r,String label) {
            // Walnut control with a warm inset highlight and gold trim, matching the target UI.
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.argb(100,0,0,0));
            c.drawRoundRect(new RectF(r[0]+2,r[1]+3,r[2]+2,r[3]+4),9,9,p);
            p.setShader(new LinearGradient(r[0],r[1],r[2],r[3],
                    new int[]{Color.rgb(118,70,35),Color.rgb(58,31,19),Color.rgb(95,53,27)},
                    null,Shader.TileMode.CLAMP));
            c.drawRoundRect(new RectF(r[0],r[1],r[2],r[3]),9,9,p);
            p.setShader(null);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(Math.max(1f,getWidth()*.002f));
            p.setColor(Color.rgb(205,157,75));
            c.drawRoundRect(new RectF(r[0]+1,r[1]+1,r[2]-1,r[3]-1),8,8,p);
            p.setStrokeWidth(Math.max(.7f,getWidth()*.0008f));
            p.setColor(Color.argb(190,244,211,139));
            c.drawRoundRect(new RectF(r[0]+4,r[1]+4,r[2]-4,r[3]-4),6,6,p);
            p.setStyle(Paint.Style.FILL); p.setColor(cream);
            p.setTextAlign(Paint.Align.CENTER); p.setTextSize(Math.min(getWidth()*.027f,18));
            c.drawText(label,(r[0]+r[2])/2f,(r[1]+r[3])/2f-(p.ascent()+p.descent())/2f,p);
        }

        void drawOverlay(Canvas c,float w,float h) {
            p.setColor(Color.argb(185,0,0,0)); c.drawRect(0,0,w,h,p);
            float l=w*.12f,t=h*.30f,r=w*.88f,b=h*.70f;
            p.setColor(wood); c.drawRoundRect(new RectF(l,t,r,b),18,18,p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(3);
            p.setColor(Color.rgb(201,157,82)); c.drawRoundRect(new RectF(l+2,t+2,r-2,b-2),16,16,p);
            p.setStyle(Paint.Style.FILL); p.setTextAlign(Paint.Align.CENTER); p.setColor(cream);
            p.setTextSize(Math.min(w*.065f,40));
            c.drawText(difficultyMenu?"Wybierz poziom":won?"Wygrana!":"Pauza",w/2f,t+h*.09f,p);
            p.setTextSize(Math.min(w*.034f,22));
            c.drawText(difficultyMenu?"Rozpocznij nowa partie":won?"Wszystkie pary znalezione":"Gra zostala zapisana",w/2f,t+h*.16f,p);
            if(difficultyMenu) {
                setRect(modalRects[0],w*.2f,h*.43f,w*.8f,h*.49f);
                setRect(modalRects[1],w*.2f,h*.51f,w*.8f,h*.57f);
                setRect(modalRects[2],w*.2f,h*.59f,w*.8f,h*.65f);
                drawButton(c,modalRects[0],"Latwy");
                drawButton(c,modalRects[1],"Normalny");
                drawButton(c,modalRects[2],"Trudny");
            } else {
                // Pause overlay has exactly one action: resume the current game.
                // Difficulty selection belongs to the "Nowa gra" button on the main screen.
                setRect(modalRects[0],w*.2f,h*.53f,w*.8f,h*.61f);
                drawButton(c,modalRects[0],won?"Nowa gra":"Wznow gre");
                modalRects[1][0]=modalRects[1][1]=modalRects[1][2]=modalRects[1][3]=-1;
            }
        }

        @Override public boolean onTouchEvent(MotionEvent e) {
            float x=e.getX(), y=e.getY();
            if(e.getAction()==MotionEvent.ACTION_DOWN) {
                downX=x; downY=y; dragX=x; dragY=y; dragging=false; dragIndex=-1; selectionBeforeTouch=selectedTile;
                if(paused || won || difficultyMenu) return true;
                for(int b=0;b<5;b++) if(inside(buttonRects[b],x,y)) return true;
                int blockedHit=-1;
                // Hit-test in reverse drawing order. If a blocked tile overlaps an exposed
                // part of another tile, do not consume the touch immediately: keep searching
                // for the topmost AVAILABLE tile under the finger.
                for(int layer=2;layer>=0;layer--) {
                    for(int i=tiles.size()-1;i>=0;i--) {
                        if(tiles.get(i).layer!=layer || tiles.get(i).removed) continue;
                        float[] r=tileRects[i];
                        if(r[0]>=0 && x>=r[0] && x<=r[2] && y>=r[1] && y<=r[3]) {
                            if(!isAvailable(i)) { if(blockedHit<0) blockedHit=i; continue; }
                            dragIndex=i; dragOffsetX=x-r[0]; dragOffsetY=y-r[1];
                            selectedTile=i; invalidate(); return true;
                        }
                    }
                }
                if(blockedHit>=0) message="Kafelek jest zakryty lub ma zablokowane oba boki";
                invalidate();
                return true;
            }
            if(e.getAction()==MotionEvent.ACTION_MOVE) {
                if(dragIndex>=0 && !paused && !won) {
                    // Use Android touch slop (density-aware) so tiny finger movement does not turn a tap into a drag.
                    if(Math.abs(x-downX)>touchSlop || Math.abs(y-downY)>touchSlop) dragging=true;
                    if(dragging) { dragX=x-dragOffsetX; dragY=y-dragOffsetY; invalidate(); }
                }
                return true;
            }
            if(e.getAction()==MotionEvent.ACTION_CANCEL) {
                dragging=false; dragIndex=-1; invalidate(); return true;
            }
            if(e.getAction()!=MotionEvent.ACTION_UP) return true;

            if(paused || won || difficultyMenu) {
                if(difficultyMenu) {
                    if(inside(modalRects[0],x,y)) { newGame(0); return true; }
                    if(inside(modalRects[1],x,y)) { newGame(1); return true; }
                    if(inside(modalRects[2],x,y)) { newGame(2); return true; }
                    return true;
                }
                if(inside(modalRects[0],x,y)) {
                    if(won) newGame(difficulty);
                    else { paused=false; message="Rozgrywka wznowiona"; saveGame(); invalidate(); }
                    return true;
                }
                return true;
            }
            if(dragIndex>=0) {
                int target=dragIndex; boolean wasDrag=dragging;
                dragging=false; dragIndex=-1;
                if(wasDrag && x>=rackRect[0] && x<=rackRect[2] && y>=rackRect[1]-tileH*.35f && y<=rackRect[3]+tileH*.35f) {
                    pick(target); selectedTile=-1;
                } else if(wasDrag) {
                    message="Upuść kafelek w schowku";
                } else {
                    // A tap on a tile that matches something already in the rack should
                    // complete the pair immediately. Dragging is only needed to add a new tile.
                    int rackMatch=-1;
                    for(int r=0;r<rack.size();r++) {
                        if(sameTileType(rack.get(r),tiles.get(target).kind)) { rackMatch=r; break; }
                    }
                    if(rackMatch>=0) {
                        pick(target);
                        selectedTile=-1;
                    } else if(selectionBeforeTouch>=0 && selectionBeforeTouch!=target
                            && selectionBeforeTouch<tiles.size()
                            && !tiles.get(selectionBeforeTouch).removed
                            && isAvailable(selectionBeforeTouch)
                            && sameTileType(tiles.get(selectionBeforeTouch).kind, tiles.get(target).kind)) {
                        removeBoardPair(selectionBeforeTouch, target);
                        selectedTile=-1;
                    } else {
                        selectedTile=target;
                        message="Wybierz drugi identyczny kafelek albo przeciągnij do schowka";
                    }
                }
                invalidate(); return true;
            }
            for(int b=0;b<5;b++) if(inside(buttonRects[b],x,y)) {
                selectedTile=-1;
                if(b==0) undo();
                else if(b==1) { paused=true; difficultyMenu=true; invalidate(); }
                else if(b==2) hint();
                else if(b==3) { paused=true; saveGame(); invalidate(); }
                else shuffleRemainingTiles();
                return true;
            }
            return true;
        }
    }
}
