package pl.mahjong.d;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Color;
import android.graphics.RectF;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Path;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;

public class MainActivity extends Activity {
    private Board board;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        board = new Board(this);
        setContentView(board);
        board.restoreSavedGame();
    }

    @Override protected void onPause() {
        if (board != null) board.saveGame();
        super.onPause();
    }

    @Override protected void onResume() {
        super.onResume();
        if (board != null) board.invalidate();
    }

    static class Tile {
        int kind, layer, col, row;
        boolean removed;
        Tile(int kind, int layer, int col, int row) {
            this.kind = kind; this.layer = layer; this.col = col; this.row = row;
        }
    }

    static class Snapshot {
        final String json;
        Snapshot(String json) { this.json = json; }
    }

    static class PathRoundClip {
        static void clip(Canvas canvas, RectF rect, float radius) {
            Path path = new Path();
            path.addRoundRect(rect, radius, radius, Path.Direction.CW);
            canvas.clipPath(path);
        }
    }

    class Board extends View {
        static final int MAX_UNDOS = 5, RACK_SIZE = 5;
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        final ArrayList<Tile> tiles = new ArrayList<>();
        final ArrayList<Integer> rack = new ArrayList<>();
        final ArrayList<Snapshot> history = new ArrayList<>();
        final SharedPreferences prefs = getSharedPreferences("mahjong_d_save", MODE_PRIVATE);
        final String[] symbols = {"一","二","三","四","五","六","七","八","九","東","南","西","北","中","發","白","🐈","🐈","🐈","🐈","🐈","🐈"};
        final Bitmap[] catBitmaps = new Bitmap[6];
        int dragIndex = -1;
        int selectedTile = -1;
        float downX, downY, dragX, dragY;
        boolean dragging = false;
        final int[] colors = {
            Color.rgb(35,54,74),Color.rgb(35,54,74),Color.rgb(35,54,74),Color.rgb(35,54,74),
            Color.rgb(35,54,74),Color.rgb(35,54,74),Color.rgb(35,54,74),Color.rgb(35,54,74),
            Color.rgb(35,54,74),Color.rgb(35,54,74),Color.rgb(35,54,74),Color.rgb(35,54,74),
            Color.rgb(35,54,74),Color.rgb(180,35,35),Color.rgb(20,115,62),Color.rgb(35,54,74)
        };

        int difficulty = 1;
        int undosLeft = MAX_UNDOS;
        int moves = 0, pairsRemoved = 0;
        boolean paused = false, won = false, lost = false, difficultyMenu = false;
        int selectedHintA = -1, selectedHintB = -1;
        String message = "Wybierz dostepna plytke";
        float tileW, tileH, boardLeft, boardTop, boardW, boardH;
        final float[] btnNew = new float[4], btnUndo = new float[4], btnHint = new float[4], btnPause = new float[4];
        final float[] btnEasy = new float[4], btnNormal = new float[4], btnHard = new float[4];
        final float[] btnResume = new float[4], btnMenu = new float[4];

        Board(Activity activity) {
            super(activity);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            catBitmaps[0] = BitmapFactory.decodeResource(getResources(), R.drawable.kot_rudy_01);
            catBitmaps[1] = BitmapFactory.decodeResource(getResources(), R.drawable.kot_rudy_02);
            catBitmaps[2] = BitmapFactory.decodeResource(getResources(), R.drawable.kot_rudy_03);
            catBitmaps[3] = BitmapFactory.decodeResource(getResources(), R.drawable.kot_2_01);
            catBitmaps[4] = BitmapFactory.decodeResource(getResources(), R.drawable.kot_2_02);
            catBitmaps[5] = BitmapFactory.decodeResource(getResources(), R.drawable.kot_2_03);
            newGame(1);
        }

        void newGame(int level) {
            difficulty = Math.max(0, Math.min(2, level));
            tiles.clear(); rack.clear(); history.clear();
            undosLeft = MAX_UNDOS; moves = 0; pairsRemoved = 0;
            paused = false; won = false; lost = false; difficultyMenu = false;
            selectedHintA = selectedHintB = -1;
            selectedTile = -1;
            message = "Dotknij kafelka, aby wybrac pare; przeciagnij do schowka, aby odlozyc";
            int pairs = difficulty == 0 ? 12 : difficulty == 1 ? 18 : 24;
            ArrayList<Integer> kinds = new ArrayList<>();
            for (int i = 0; i < pairs; i++) {
                // Include all six approved cat illustrations in every difficulty.
                int k = i < 6 ? 16 + i : (i - 6) % 16;
                kinds.add(k); kinds.add(k);
            }
            Collections.shuffle(kinds);
            ArrayList<int[]> positions = makeLayout(difficulty);
            for (int i = 0; i < positions.size(); i++) {
                int[] pos = positions.get(i);
                tiles.add(new Tile(kinds.get(i), pos[0], pos[1], pos[2]));
            }
            invalidate();
            saveGame();
        }

        ArrayList<int[]> makeLayout(int level) {
            ArrayList<int[]> out = new ArrayList<>();
            if (level == 0) {
                for (int r = 1; r <= 4; r++)
                    for (int c = 1; c <= 6; c++) out.add(new int[]{0, c, r});
            } else if (level == 1) {
                for (int r = 0; r < 4; r++)
                    for (int c = 0; c < 8; c++) {
                        if ((r == 0 || r == 3) && (c == 0 || c == 7)) continue;
                        out.add(new int[]{0, c, r});
                    }
                for (int r = 1; r <= 2; r++)
                    for (int c = 2; c <= 5; c++) out.add(new int[]{1, c, r});
            } else {
                for (int r = 0; r < 4; r++)
                    for (int c = 0; c < 8; c++) out.add(new int[]{0, c, r});
                for (int r = 1; r <= 3; r++)
                    for (int c = 2; c <= 5; c++) out.add(new int[]{1, c, r});
                for (int r = 1; r <= 2; r++)
                    for (int c = 3; c <= 4; c++) out.add(new int[]{2, c, r});
            }
            return out;
        }

        String serialize() { return serialize(true); }

        String serialize(boolean includeHistory) {
            try {
                JSONObject root = new JSONObject();
                root.put("difficulty", difficulty); root.put("undosLeft", undosLeft);
                root.put("moves", moves); root.put("pairsRemoved", pairsRemoved);
                root.put("paused", paused); root.put("won", won); root.put("lost", lost);
                root.put("difficultyMenu", difficultyMenu); root.put("message", message);
                JSONArray ts = new JSONArray();
                for (Tile t : tiles) {
                    JSONObject o = new JSONObject();
                    o.put("kind", t.kind); o.put("layer", t.layer); o.put("col", t.col);
                    o.put("row", t.row); o.put("removed", t.removed); ts.put(o);
                }
                root.put("tiles", ts);
                JSONArray rs = new JSONArray();
                for (Integer k : rack) rs.put(k);
                root.put("rack", rs);
                if (includeHistory) {
                    JSONArray hs = new JSONArray();
                    for (Snapshot snapshot : history) hs.put(snapshot.json);
                    root.put("history", hs);
                }
                return root.toString();
            } catch (Exception e) {
                return "";
            }
        }

        void saveGame() {
            if (tiles.isEmpty()) return;
            String state = serialize(true);
            if (!state.isEmpty()) prefs.edit().putString("state", state).apply();
        }

        void restoreSavedGame() {
            String saved = prefs.getString("state", "");
            if (saved.isEmpty()) { invalidate(); return; }
            try {
                JSONObject root = new JSONObject(saved);
                tiles.clear(); rack.clear(); history.clear();
                difficulty = Math.max(0, Math.min(2, root.optInt("difficulty", 1)));
                undosLeft = Math.max(0, Math.min(MAX_UNDOS, root.optInt("undosLeft", MAX_UNDOS)));
                moves = Math.max(0, root.optInt("moves", 0));
                pairsRemoved = Math.max(0, root.optInt("pairsRemoved", 0));
                paused = root.optBoolean("paused", false);
                won = root.optBoolean("won", false);
                lost = root.optBoolean("lost", false);
                difficultyMenu = root.optBoolean("difficultyMenu", false);
                message = root.optString("message", "Wybierz dostepna plytke");
                JSONArray ts = root.getJSONArray("tiles");
                for (int i = 0; i < ts.length(); i++) {
                    JSONObject o = ts.getJSONObject(i);
                    int kind = o.getInt("kind");
                    if (kind < 0 || kind >= symbols.length) continue;
                    Tile t = new Tile(kind, o.getInt("layer"), o.getInt("col"), o.getInt("row"));
                    t.removed = o.optBoolean("removed", false);
                    tiles.add(t);
                }
                JSONArray rs = root.getJSONArray("rack");
                for (int i = 0; i < rs.length() && i < RACK_SIZE; i++) {
                    int k = rs.getInt(i);
                    if (k >= 0 && k < symbols.length) rack.add(k);
                }
                JSONArray hs = root.optJSONArray("history");
                if (hs != null) {
                    for (int i = Math.max(0, hs.length() - MAX_UNDOS); i < hs.length(); i++)
                        history.add(new Snapshot(hs.getString(i)));
                }
                if (tiles.isEmpty()) newGame(1);
            } catch (Exception e) {
                newGame(1);
            }
            invalidate();
        }

        String difficultyName() {
            return difficulty == 0 ? "Latwy" : difficulty == 1 ? "Normalny" : "Trudny";
        }

        boolean isAvailable(int index) {
            if (index < 0 || index >= tiles.size()) return false;
            Tile t = tiles.get(index);
            if (t.removed) return false;
            boolean covered = false;
            boolean leftBlocked = false, rightBlocked = false;
            float tx = tileX(t), ty = tileY(t);
            // Test actual rendered rectangles rather than assuming neighbouring grid
            // coordinates necessarily cover a tile. This board has a visible gap
            // between same-layer tiles, so those neighbours do not block a side.
            for (int j = 0; j < tiles.size(); j++) {
                if (j == index) continue;
                Tile o = tiles.get(j);
                if (o.removed) continue;
                float ox = tileX(o), oy = tileY(o);
                float overlapX = Math.min(tx + tileW, ox + tileW) - Math.max(tx, ox);
                float overlapY = Math.min(ty + tileH, oy + tileH) - Math.max(ty, oy);
                if (overlapX <= 0 || overlapY <= 0) continue;
                if (o.layer > t.layer) {
                    // A higher tile blocks only when its face covers the centre of
                    // the lower tile, not merely because its edge overlaps a corner.
                    float cx = tx + tileW * 0.5f, cy = ty + tileH * 0.5f;
                    if (cx >= ox && cx <= ox + tileW && cy >= oy && cy <= oy + tileH) covered = true;
                } else if (o.layer == t.layer && oy < ty + tileH * 0.15f && oy + tileH > ty + tileH * 0.85f) {
                    // A same-layer tile blocks a side only when the rectangles touch
                    // or overlap horizontally; a visible gap means the side is free.
                    if (ox + tileW >= tx - 1f && ox < tx) leftBlocked = true;
                    if (ox <= tx + tileW + 1f && ox > tx) rightBlocked = true;
                }
            }
            return !covered && (!leftBlocked || !rightBlocked);
        }

        void doPick(int index) {
            if (index < 0 || index >= tiles.size() || !isAvailable(index)
                    || paused || won || lost) return;
            int kind = tiles.get(index).kind;
            int match = rack.indexOf(kind);
            if (match < 0 && rack.size() >= RACK_SIZE) {
                lost = true;
                paused = false;
                message = "Schowek pelny. Cofnij ruch lub rozpocznij nowa gre.";
                invalidate();
                saveGame();
                return;
            }
            saveUndo();
            tiles.get(index).removed = true;
            moves++;
            if (match >= 0) {
                rack.remove(match);
                pairsRemoved++;
                message = "Para usunieta automatycznie!";
            } else {
                rack.add(kind);
                message = "Plytka trafila do schowka";
            }
            selectedHintA = selectedHintB = -1;
            if (allTilesRemoved()) {
                won = true;
                lost = false;
                message = "WYGRANA! Swietna gra!";
            } else if (rack.size() == RACK_SIZE) {
                message = "Schowek pelny. Dopasuj plytke lub cofnij ruch.";
            }
            saveGame();
            invalidate();
        }

        void handleTileTap(int index) {
            if (index < 0 || index >= tiles.size() || !isAvailable(index)
                    || paused || won || lost) return;
            if (selectedTile >= 0 && selectedTile < tiles.size()
                    && selectedTile != index && !tiles.get(selectedTile).removed
                    && isAvailable(selectedTile)
                    && tiles.get(selectedTile).kind == tiles.get(index).kind) {
                saveUndo();
                tiles.get(selectedTile).removed = true;
                tiles.get(index).removed = true;
                moves++;
                pairsRemoved++;
                selectedTile = -1;
                selectedHintA = selectedHintB = -1;
                message = "Para usunieta!";
                if (allTilesRemoved()) { won = true; message = "WYGRANA! Swietna gra!"; }
                saveGame();
                invalidate();
                return;
            }
            selectedTile = index;
            message = "Wybrano kafelek. Wybierz identyczny lub przeciagnij do schowka.";
            invalidate();
        }

        boolean allTilesRemoved() {
            for (Tile t : tiles) if (!t.removed) return false;
            return true;
        }

        void saveUndo() {
            if (history.size() >= MAX_UNDOS) history.remove(0);
            history.add(new Snapshot(serialize(false)));
        }

        void undo() {
            if (undosLeft <= 0 || history.isEmpty()) {
                message = undosLeft <= 0 ? "Wykorzystano limit cofniec" : "Nie ma ruchu do cofniecia";
                invalidate();
                return;
            }
            Snapshot snapshot = history.remove(history.size() - 1);
            try {
                JSONObject root = new JSONObject(snapshot.json);
                ArrayList<Tile> restoredTiles = new ArrayList<>();
                ArrayList<Integer> restoredRack = new ArrayList<>();
                JSONArray ts = root.getJSONArray("tiles");
                for (int i = 0; i < ts.length(); i++) {
                    JSONObject o = ts.getJSONObject(i);
                    Tile t = new Tile(o.getInt("kind"), o.getInt("layer"), o.getInt("col"), o.getInt("row"));
                    t.removed = o.optBoolean("removed", false);
                    restoredTiles.add(t);
                }
                JSONArray rs = root.getJSONArray("rack");
                for (int i = 0; i < rs.length(); i++) restoredRack.add(rs.getInt(i));
                tiles.clear(); tiles.addAll(restoredTiles);
                rack.clear(); rack.addAll(restoredRack);
                difficulty = root.optInt("difficulty", difficulty);
                moves = root.optInt("moves", moves);
                pairsRemoved = root.optInt("pairsRemoved", pairsRemoved);
                undosLeft--;
                lost = false; won = false; paused = false; difficultyMenu = false;
                message = "Cofnieto ostatni ruch";
                selectedHintA = selectedHintB = -1;
            } catch (Exception e) {
                message = "Nie udalo sie cofnac ruchu";
            }
            saveGame();
            invalidate();
        }

        void hint() {
            selectedHintA = selectedHintB = -1;
            for (int i = 0; i < tiles.size(); i++) {
                if (!isAvailable(i)) continue;
                for (int j = i + 1; j < tiles.size(); j++) {
                    if (isAvailable(j) && tiles.get(i).kind == tiles.get(j).kind) {
                        selectedHintA = i; selectedHintB = j;
                        message = "Podswietlono dostepna pare";
                        invalidate();
                        return;
                    }
                }
            }
            message = "Brak widocznej pary. Sprobuj schowka lub cofnij ruch.";
            invalidate();
        }

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            float w = getWidth(), h = getHeight();
            p.setStyle(Paint.Style.FILL); p.setColor(Color.rgb(37,20,12)); c.drawRect(0,0,w,h,p);
            p.setColor(Color.rgb(53,29,17)); c.drawRect(0,0,w,h*.13f,p);
            p.setColor(Color.rgb(16,100,76)); c.drawRect(0,h*.13f,w,h*.86f,p);
            p.setColor(Color.rgb(29,49,36)); c.drawRect(0,h*.86f,w,h,p);

            p.setTextAlign(Paint.Align.LEFT); p.setColor(Color.rgb(255,241,211));
            p.setTextSize(Math.min(w*.065f,42)); p.setFakeBoldText(true);
            c.drawText("Mahjong D",w*.04f,h*.075f,p); p.setFakeBoldText(false);
            p.setTextAlign(Paint.Align.RIGHT); p.setTextSize(Math.min(w*.033f,22));
            c.drawText(difficultyName(),w*.96f,h*.055f,p);
            c.drawText("Cofniecia: "+undosLeft+"/"+MAX_UNDOS,w*.96f,h*.10f,p);

            float rackW = w*.82f, rackX = (w-rackW)/2f, rackY = h*.145f, rackH = h*.105f;
            p.setColor(Color.rgb(107,62,27));
            c.drawRoundRect(new RectF(rackX,rackY,rackX+rackW,rackY+rackH),12,12,p);
            float slotW = rackW/5f;
            for (int s = 0; s < 5; s++) {
                float l = rackX+s*slotW+3, top = rackY+3;
                p.setColor(Color.rgb(34,20,13));
                c.drawRoundRect(new RectF(l,top,l+slotW-6,rackY+rackH-3),7,7,p);
                if (s < rack.size())
                    drawTileFace(c,l+2,top+2,slotW-10,rackY+rackH-top-7,rack.get(s),false);
            }
            p.setTextAlign(Paint.Align.CENTER); p.setColor(Color.rgb(255,241,211));
            p.setTextSize(Math.min(w*.03f,20));
            c.drawText("Schowek "+rack.size()+"/5",w/2f,rackY+rackH+h*.025f,p);

            boardLeft = w*.04f; boardTop = h*.28f; boardW = w*.92f; boardH = h*.52f;
            // Kafelki dopasowane do siatki: odstępy zapobiegają przypadkowemu nakładaniu.
            tileW = Math.min(boardW/8.8f, boardH/5.8f);
            tileH = Math.min(tileW*1.22f, boardH/4.35f);
            for (int layer = 0; layer < 3; layer++) {
                for (int i = 0; i < tiles.size(); i++) {
                    Tile t = tiles.get(i);
                    if (t.removed || t.layer != layer) continue;
                    float x = tileX(t), y = tileY(t);
                    boolean available = isAvailable(i);
                    if (i == selectedTile) {
                        p.setColor(Color.rgb(255,190,55));
                        c.drawRoundRect(new RectF(x-4,y-4,x+tileW+4,y+tileH+4),9,9,p);
                    }
                    if (i == selectedHintA || i == selectedHintB) {
                        p.setColor(Color.rgb(255,218,75));
                        c.drawRoundRect(new RectF(x-3,y-3,x+tileW+3,y+tileH+3),8,8,p);
                    }
                    drawTileFace(c,x,y,tileW,tileH,t.kind,!available);
                }
            }
            if (dragging && dragIndex >= 0 && dragIndex < tiles.size()) {
                Tile dt = tiles.get(dragIndex);
                drawTileFace(c, dragX-tileW*.5f, dragY-tileH*.5f, tileW, tileH, dt.kind, false);
            }

            float by = h*.88f, bh = h*.085f;
            setRect(btnUndo,w*.025f,by-bh/2,w*.25f,by+bh/2);
            setRect(btnNew,w*.27f,by-bh/2,w*.50f,by+bh/2);
            setRect(btnHint,w*.52f,by-bh/2,w*.75f,by+bh/2);
            setRect(btnPause,w*.77f,by-bh/2,w*.975f,by+bh/2);
            drawButton(c,btnUndo,"Cofnij",false);
            drawButton(c,btnNew,"Nowa gra",false);
            drawButton(c,btnHint,"Podpowiedz",false);
            drawButton(c,btnPause,"Pauza",false);
            p.setTextAlign(Paint.Align.CENTER); p.setColor(Color.WHITE);
            p.setTextSize(Math.min(w*.03f,20));
            c.drawText(message,w/2f,h*.975f,p);
            if (paused || won || lost) drawOverlay(c,w,h);
        }

        float tileX(Tile t) {
            // Stały krok siatki. Wyższe warstwy są przesunięte tylko nieznacznie,
            // dzięki czemu widać ich wysokość, ale nie tworzą chaotycznego stosu.
            float stepX = tileW * 1.08f;
            float totalW = 7f * stepX + tileW;
            float startX = (getWidth() - totalW) / 2f;
            return startX + t.col * stepX + t.layer * tileW * .10f;
        }

        float tileY(Tile t) {
            float stepY = tileH * 1.08f;
            float startY = getHeight() * .285f;
            return startY + t.row * stepY - t.layer * tileH * .10f;
        }

        void drawTileFace(Canvas c,float x,float y,float tw,float th,int kind,boolean dim) {
            p.setStyle(Paint.Style.FILL); p.setColor(Color.rgb(0,0,0));
            c.drawRoundRect(new RectF(x+3,y+4,x+tw+3,y+th+4),6,6,p);
            p.setColor(dim?Color.rgb(204,195,169):Color.rgb(248,239,210));
            c.drawRoundRect(new RectF(x,y,x+tw,y+th),6,6,p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1.5f);
            p.setColor(Color.rgb(151,112,55));
            c.drawRoundRect(new RectF(x+2,y+2,x+tw-2,y+th-2),5,5,p);
            p.setStyle(Paint.Style.FILL);
            if (kind >= 16 && kind <= 21 && catBitmaps[kind-16] != null) {
                Bitmap bmp = catBitmaps[kind-16];
                p.setStyle(Paint.Style.FILL);
                RectF dst = new RectF(x+tw*.07f,y+th*.05f,x+tw*.93f,y+th*.95f);
                c.save();
                PathRoundClip.clip(c, dst, Math.min(tw*.08f, 8));
                c.drawBitmap(bmp, null, dst, p);
                c.restore();
            } else {
                p.setColor(colors[kind%colors.length]); p.setTextAlign(Paint.Align.CENTER);
                p.setTextSize(Math.min(tw*.55f,38)); p.setFakeBoldText(true);
                c.drawText(symbols[kind%symbols.length],x+tw/2f,y+th*.64f,p);
                p.setFakeBoldText(false);
            }
        }

        void setRect(float[] r,float l,float t,float right,float b) {
            r[0]=l; r[1]=t; r[2]=right; r[3]=b;
        }

        boolean inside(float[] r,float x,float y) {
            return x>=r[0] && x<=r[2] && y>=r[1] && y<=r[3];
        }

        void drawButton(Canvas c,float[] r,String label,boolean disabled) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(disabled?Color.GRAY:Color.rgb(248,239,210));
            c.drawRoundRect(new RectF(r[0],r[1],r[2],r[3]),10,10,p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2);
            p.setColor(Color.rgb(151,112,55));
            c.drawRoundRect(new RectF(r[0]+2,r[1]+2,r[2]-2,r[3]-2),9,9,p);
            p.setStyle(Paint.Style.FILL); p.setColor(Color.rgb(40,55,45));
            p.setTextAlign(Paint.Align.CENTER);
            p.setTextSize(Math.min(getWidth()*.035f,23));
            c.drawText(label,(r[0]+r[2])/2f,(r[1]+r[3])/2f-(p.ascent()+p.descent())/2f,p);
        }

        void drawOverlay(Canvas c,float w,float h) {
            p.setColor(Color.argb(175,0,0,0)); c.drawRect(0,0,w,h,p);
            float l=w*.12f,t=h*.29f,r=w*.88f,b=h*.72f;
            p.setColor(Color.rgb(54,29,17)); c.drawRoundRect(new RectF(l,t,r,b),18,18,p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(4);
            p.setColor(Color.rgb(201,145,57));
            c.drawRoundRect(new RectF(l+3,t+3,r-3,b-3),16,16,p);
            p.setStyle(Paint.Style.FILL); p.setTextAlign(Paint.Align.CENTER);
            p.setColor(Color.rgb(255,241,211)); p.setTextSize(Math.min(w*.075f,44));
            String title = difficultyMenu ? "Wybierz poziom" : paused ? "Pauza" : won ? "Wygrana!" : "Schowek pelny";
            c.drawText(title,w/2f,t+h*.085f,p);
            p.setTextSize(Math.min(w*.036f,23));
            String subtitle = difficultyMenu ? "Rozpocznij nowa partie" : paused ? "Gra zostala zapisana."
                    : won ? "Usunieto wszystkie plytki." : "Cofnij ruch, aby kontynuowac.";
            c.drawText(subtitle,w/2f,t+h*.16f,p);
            if (difficultyMenu) {
                setRect(btnEasy,w*.16f,h*.43f,w*.84f,h*.49f);
                setRect(btnNormal,w*.16f,h*.51f,w*.84f,h*.57f);
                setRect(btnHard,w*.16f,h*.59f,w*.84f,h*.65f);
                drawButton(c,btnEasy,"Latwy",false);
                drawButton(c,btnNormal,"Normalny",false);
                drawButton(c,btnHard,"Trudny",false);
            } else {
                setRect(btnResume,w*.2f,h*.49f,w*.8f,h*.57f);
                drawButton(c,btnResume,paused?"Wznow gre":won?"Nowa gra":"Cofnij ruch",false);
                setRect(btnMenu,w*.2f,h*.60f,w*.8f,h*.67f);
                drawButton(c,btnMenu,"Menu poziomow",false);
            }
        }

        @Override public boolean onTouchEvent(MotionEvent e) {
            float x=e.getX(), y=e.getY(), h=getHeight();
            if (e.getAction() == MotionEvent.ACTION_DOWN) {
                downX=x; downY=y; dragX=x; dragY=y; dragging=false; dragIndex=-1;
                if (!(paused || won || lost) && y >= getHeight()*.28f && y <= getHeight()*.82f) {
                    // Hit-test in the same front-to-back order as drawing: upper layers first.
                    // This prevents a hidden tile from stealing the touch from the visible tile.
                    for (int layer=2; layer>=0 && dragIndex<0; layer--) {
                        for (int i=tiles.size()-1;i>=0;i--) {
                            Tile t=tiles.get(i);
                            if (t.removed || t.layer!=layer || !isAvailable(i)) continue;
                            float xx=tileX(t), yy=tileY(t);
                            if (x>=xx && x<=xx+tileW && y>=yy && y<=yy+tileH) { dragIndex=i; break; }
                        }
                    }
                }
                return true;
            }
            if (e.getAction() == MotionEvent.ACTION_MOVE) {
                if (dragIndex >= 0) {
                    dragX=x; dragY=y;
                    if (Math.abs(x-downX)+Math.abs(y-downY) > 18) dragging=true;
                    if (dragging) invalidate();
                }
                return true;
            }
            if (e.getAction() == MotionEvent.ACTION_CANCEL) { dragIndex=-1; dragging=false; invalidate(); return true; }
            if (e.getAction() != MotionEvent.ACTION_UP) return true;
            if (dragIndex >= 0) {
                int picked=dragIndex; boolean wasDragging=dragging;
                dragIndex=-1; dragging=false;
                float rackW=getWidth()*.82f, rackX=(getWidth()-rackW)/2f, rackY=getHeight()*.145f, rackH=getHeight()*.105f;
                // Count the drop when the dragged tile overlaps the rack, not only when
                // the finger itself lands inside the narrow rack rectangle.
                float halfW=tileW*.5f, halfH=tileH*.5f;
                boolean overRack = (x+halfW)>=rackX && (x-halfW)<=(rackX+rackW)
                        && (y+halfH)>=rackY && (y-halfH)<=(rackY+rackH);
                if (wasDragging && overRack) {
                    selectedTile = -1;
                    doPick(picked);
                } else if (!wasDragging) {
                    handleTileTap(picked);
                } else {
                    invalidate();
                }
                return true;
            }
            if (paused || won || lost) {
                if (difficultyMenu) {
                    if (inside(btnEasy,x,y)) { newGame(0); return true; }
                    if (inside(btnNormal,x,y)) { newGame(1); return true; }
                    if (inside(btnHard,x,y)) { newGame(2); return true; }
                    return true;
                }
                if (inside(btnResume,x,y)) {
                    if (paused) { paused=false; message="Rozgrywka wznowiona"; saveGame(); }
                    else if (won) newGame(difficulty);
                    else undo();
                    invalidate();
                    return true;
                }
                if (inside(btnMenu,x,y)) {
                    paused=true; difficultyMenu=true; message="Wybierz poziom trudnosci";
                    saveGame(); invalidate(); return true;
                }
                return true;
            }
            if (inside(btnUndo,x,y)) { undo(); return true; }
            if (inside(btnNew,x,y)) {
                paused=true; difficultyMenu=true; message="Wybierz poziom trudnosci";
                saveGame(); invalidate(); return true;
            }
            if (inside(btnHint,x,y)) { hint(); return true; }
            if (inside(btnPause,x,y)) {
                paused=true; message="Gra zostala zapisana"; saveGame(); invalidate(); return true;
            }
            return true;
        }
    }
}
