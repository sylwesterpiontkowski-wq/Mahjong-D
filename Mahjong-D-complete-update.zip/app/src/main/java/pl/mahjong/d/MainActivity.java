package pl.mahjong.d;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.view.*;
import java.io.InputStream;
import java.util.*;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(32,48,39));
        getWindow().setNavigationBarColor(Color.rgb(32,48,39));
        setContentView(new GameView());
    }

    class Tile {
        int kind, row, col, layer;
        boolean removed;
        Tile(int k, int r, int c, int l) { kind=k; row=r; col=c; layer=l; }
    }

    class GameView extends View {
        class Snapshot {
            boolean[] removed;
            ArrayList<Integer> tray;
            int moves, pairs;
            Snapshot() {
                removed=new boolean[tiles.size()];
                for(int i=0;i<tiles.size();i++) removed[i]=tiles.get(i).removed;
                tray=new ArrayList<>(rack);
                moves=GameView.this.moves;
                pairs=GameView.this.pairs;
            }
        }

        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        ArrayList<Tile> tiles = new ArrayList<>();
        ArrayList<Integer> rack = new ArrayList<>();
        ArrayList<Snapshot> history = new ArrayList<>();
        Bitmap[] tileArt = new Bitmap[30];
        String[] artFiles = {
            "cat_rudy_sitting.jpg","cat_rudy_lying.jpg","cat_rudy_curled.jpg",
            "cat2_sitting.jpg","cat2_lying.jpg","cat2_curled.jpg",
            "tiger_1.jpg","tiger_2.jpg","tiger_3.jpg",
            "lion_1.jpg","lion_2.jpg","lion_3.jpg",
            "leopard_1.jpg","leopard_2.jpg","leopard_3.jpg",
            "snow_leopard_1.jpg","snow_leopard_2.jpg","snow_leopard_3.jpg",
            "special_paw.jpg","special_yarn.jpg","special_fish.jpg","special_bowl.jpg",
            "special_butterfly.jpg","special_bird.jpg","special_plant.jpg","special_lantern.jpg",
            "special_bamboo.jpg","special_flower.jpg","special_rocks.jpg","special_mountain.jpg"
        };
        int moves=0, pairs=0, difficulty=1, undos=5;
        boolean paused=false, showDifficulty=false;
        String message="Wybierz dwa takie same kafelki";
        String[] symbols={"一","二","三","四","五","六","七","八","九","東","南","西","北","中","發","白"};
        RectF[] tileRects=new RectF[40], buttons=new RectF[5], rackRects=new RectF[5], levelRects=new RectF[3];
        final int BG=Color.rgb(16,100,76), CREAM=Color.rgb(248,239,210), INK=Color.rgb(35,54,74), GOLD=Color.rgb(225,184,91);
        float tileW, tileH, gap, boardTop;
        int dragTile=-1, selectedTile=-1, touchedRackSlot=-1;
        float downX, downY, dragX, dragY;
        boolean dragging=false;

        GameView() {
            super(MainActivity.this);
            setLayerType(View.LAYER_TYPE_SOFTWARE,null);
            for(int i=0;i<artFiles.length;i++) {
                try { tileArt[i]=loadAsset(artFiles[i]); } catch(Exception ignored) {}
            }
            newGame();
        }

        Bitmap loadAsset(String n)throws Exception {
            InputStream s=getAssets().open(n);
            try { return BitmapFactory.decodeStream(s); } finally { s.close(); }
        }

        int pairTarget(){ return difficulty==0?12:difficulty==1?16:20; }

        void newGame() {
            selectedTile=-1;
            tiles.clear(); rack.clear(); history.clear();
            int count=pairTarget()*2;
            ArrayList<Integer> kinds=new ArrayList<>();
            ArrayList<Integer> pool=new ArrayList<>();
            for(int i=0;i<46;i++) pool.add(i);
            Collections.shuffle(pool);
            for(int i=0;i<pairTarget();i++){ kinds.add(pool.get(i)); kinds.add(pool.get(i)); }
            Collections.shuffle(kinds);
            int idx=0;
            if(difficulty==0) {
                // Easy: one layer, 6 x 4 rectangle.
                for(int r=0;r<4;r++) for(int c=0;c<6;c++) tiles.add(new Tile(kinds.get(idx++),r,c,0));
            } else if(difficulty==1) {
                // Normal: 5 x 5 base plus 7 tiles on the upper layer.
                for(int r=0;r<5;r++) for(int c=0;c<5;c++) tiles.add(new Tile(kinds.get(idx++),r,c,0));
                int[][] upper={{1,1},{1,2},{1,3},{2,1},{2,2},{2,3},{3,2}};
                for(int[] pos:upper) tiles.add(new Tile(kinds.get(idx++),pos[0],pos[1],1));
            } else {
                // Hard: 6 x 5 base, 8 tiles on layer 1, and 2 tiles on layer 2.
                for(int r=0;r<5;r++) for(int c=0;c<6;c++) tiles.add(new Tile(kinds.get(idx++),r,c,0));
                int[][] upper={{0,1},{0,2},{0,3},{0,4},{1,1},{1,2},{1,3},{1,4}};
                for(int[] pos:upper) tiles.add(new Tile(kinds.get(idx++),pos[0],pos[1],1));
                int[][] top={{1,2},{1,3}};
                for(int[] pos:top) tiles.add(new Tile(kinds.get(idx++),pos[0],pos[1],2));
            }
            moves=0; pairs=0; undos=5; paused=false; showDifficulty=false;
            message="Wybierz dwa takie same kafelki";
            invalidate();
        }

        void saveUndo() {
            history.add(new Snapshot());
            if(history.size()>5) history.remove(0);
        }

        void undo() {
            if(history.isEmpty() || undos<=0) {
                message="Brak cofnięć"; invalidate(); return;
            }
            Snapshot s=history.remove(history.size()-1);
            for(int i=0;i<tiles.size();i++) tiles.get(i).removed=s.removed[i];
            rack.clear(); rack.addAll(s.tray);
            moves=s.moves; pairs=s.pairs; undos--;
            message="Cofnięto ruch"; invalidate();
        }

        boolean isFree(int i) {
            if(i<0 || i>=tiles.size() || tiles.get(i).removed || rack.contains(i)) return false;
            Tile t=tiles.get(i);

            // Only a higher tile that visibly overlaps this tile can cover it.
            RectF target = tileRects[i];
            for(int j=0;j<tiles.size();j++) {
                if(j==i) continue;
                Tile other=tiles.get(j);
                if(other.removed || rack.contains(j) || other.layer<=t.layer) continue;
                RectF upper = tileRects[j];
                if(target!=null && upper!=null) {
                    float overlapW=Math.min(target.right,upper.right)-Math.max(target.left,upper.left);
                    float overlapH=Math.min(target.bottom,upper.bottom)-Math.max(target.top,upper.top);
                    if(overlapW>target.width()*.45f && overlapH>target.height()*.45f) return false;
                } else if(other.row==t.row && other.col==t.col) {
                    return false;
                }
            }

            // A same-layer neighbour blocks a side only when it is actually beside this tile
            // in the same row and is still present on the board.
            boolean leftBlocked=false, rightBlocked=false;
            for(int j=0;j<tiles.size();j++) {
                if(j==i) continue;
                Tile other=tiles.get(j);
                if(other.removed || rack.contains(j) || other.layer!=t.layer || other.row!=t.row) continue;
                if(other.col==t.col-1) leftBlocked=true;
                if(other.col==t.col+1) rightBlocked=true;
            }
            return !leftBlocked || !rightBlocked;
        }

        void chooseTile(int i) {
            if(!isFree(i)) {
                message="Kafelek zablokowany"; invalidate(); return;
            }
            if(rack.size()>=5) {
                message="Schowek pełny — znajdź parę lub cofnij";
                invalidate(); return;
            }
            saveUndo();
            rack.add(i);
            int found=-1, kind=tiles.get(i).kind;
            for(int j=0;j<rack.size()-1;j++) if(tiles.get(rack.get(j)).kind==kind) { found=j; break; }
            if(found>=0) {
                int first=rack.remove(found), second=rack.remove(rack.size()-1);
                tiles.get(first).removed=true; tiles.get(second).removed=true;
                pairs++; moves++;
                message=pairs==pairTarget()?"Wygrana!":"Para znaleziona";
            } else {
                moves++;
                message="Schowek: "+rack.size()+"/5";
            }
            invalidate();
        }

        void hint() {
            for(int i=0;i<tiles.size();i++) if(isFree(i))
                for(int j=i+1;j<tiles.size();j++)
                    if(isFree(j) && tiles.get(i).kind==tiles.get(j).kind) {
                        message="Jest dostępna para";
                        invalidate(); return;
                    }
            message="Brak dostępnej pary"; invalidate();
        }

        void drawTile(Canvas c, int kind, RectF r, boolean blocked) {
            float x=r.left,y=r.top,tw=r.width(),th=r.height();
            p.setStyle(Paint.Style.FILL); p.setColor(Color.rgb(8,47,35));
            c.drawRoundRect(new RectF(x+2,y+4,x+tw+2,y+th+4),10,10,p);
            p.setColor(CREAM); c.drawRoundRect(r,10,10,p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2); p.setColor(Color.rgb(151,111,62));
            c.drawRoundRect(new RectF(x+3,y+3,x+tw-3,y+th-3),7,7,p);
            p.setStyle(Paint.Style.FILL);
            if(kind<tileArt.length && tileArt[kind]!=null) {
                RectF dst=new RectF(x+tw*.07f,y+th*.05f,x+tw*.93f,y+th*.95f);
                c.save();
                Path clip=new Path(); clip.addRoundRect(dst,6,6,Path.Direction.CW); c.clipPath(clip);
                c.drawBitmap(tileArt[kind],null,dst,p); c.restore();
            } else {
                int si=(kind-tileArt.length)%symbols.length;
                p.setTextAlign(Paint.Align.CENTER); p.setTextSize(Math.min(tw*.48f,42)); p.setFakeBoldText(true);
                p.setColor(si==13?Color.rgb(180,35,35):si==14?Color.rgb(20,115,62):INK);
                c.drawText(symbols[si],x+tw/2,y+th*.62f,p); p.setFakeBoldText(false);
                p.setColor(Color.rgb(151,111,62)); p.setTextSize(Math.min(tw*.12f,12));
                c.drawText("✦",x+tw/2,y+th*.84f,p);
            }
            if(blocked) {
                p.setColor(0x30000000);
                c.drawRoundRect(r,10,10,p);
            }
        }

        void layoutTiles(float w, float h) {
            int maxCols=6;
            gap=w*.018f;
            tileW=(w-gap*(maxCols+1))/maxCols;
            tileH=Math.min(tileW*1.14f,h*.072f);
            float areaTop=h*.355f, areaBottom=h*.665f;
            int rows=difficulty==0?4:5;
            float boardH=rows*tileH+(rows-1)*gap;
            boardTop=areaTop+Math.max(0,(areaBottom-areaTop-boardH)*.5f);
            Arrays.fill(tileRects,null);
            for(int i=0;i<tiles.size();i++) {
                Tile t=tiles.get(i);
                if(t.removed || rack.contains(i)) continue;
                float totalW=6*tileW+5*gap;
                float left=(w-totalW)/2f;
                float x=left+t.col*(tileW+gap)+t.layer*tileW*.20f;
                float y=boardTop+t.row*(tileH+gap)-t.layer*tileH*.20f;
                tileRects[i]=new RectF(x,y,x+tileW,y+tileH);
            }
        }

        @Override protected void onDraw(Canvas c) {
            float w=getWidth(),h=getHeight();
            p.setStyle(Paint.Style.FILL); p.setColor(Color.rgb(37,20,12)); c.drawRect(0,0,w,h,p);
            p.setColor(Color.rgb(53,29,17)); c.drawRect(0,0,w,h*.14f,p);
            p.setColor(BG); c.drawRect(0,h*.14f,w,h*.72f,p);
            p.setColor(Color.rgb(29,49,36)); c.drawRect(0,h*.72f,w,h,p);

            p.setColor(CREAM); p.setTextAlign(Paint.Align.LEFT); p.setFakeBoldText(true);
            p.setTextSize(Math.min(w*.065f,42)); c.drawText("Mahjong D",w*.04f,h*.075f,p); p.setFakeBoldText(false);
            p.setTextAlign(Paint.Align.RIGHT); p.setTextSize(Math.min(w*.031f,22));
            c.drawText(difficulty==0?"ŁATWY":difficulty==1?"NORMALNY":"TRUDNY",w*.96f,h*.055f,p);
            c.drawText("Pary: "+pairs+"/"+pairTarget()+"   Ruchy: "+moves,w*.96f,h*.105f,p);
            p.setTextAlign(Paint.Align.CENTER); p.setTextSize(Math.min(w*.032f,22));
            c.drawText(message,w/2,h*.18f,p);

            // Schowek u góry.
            p.setColor(CREAM); p.setTextAlign(Paint.Align.LEFT); p.setTextSize(Math.min(w*.033f,22));
            c.drawText("Schowek  "+rack.size()+"/5",w*.04f,h*.225f,p);
            float rg=w*.018f,rw=(w-rg*6)/5f,rh=Math.min(rw*1.12f,h*.075f),ry=h*.245f;
            for(int slot=0;slot<5;slot++) {
                float rx=rg+(rw+rg)*slot;
                rackRects[slot]=new RectF(rx,ry,rx+rw,ry+rh);
                p.setColor(Color.rgb(7,72,54)); c.drawRoundRect(rackRects[slot],10,10,p);
                if(slot<rack.size()) drawTile(c,tiles.get(rack.get(slot)).kind,rackRects[slot],false);
                else {
                    p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2); p.setColor(Color.rgb(134,178,157));
                    c.drawRoundRect(rackRects[slot],10,10,p); p.setStyle(Paint.Style.FILL);
                }
            }

            layoutTiles(w,h);
            for(int layer=0;layer<=2;layer++) {
                for(int i=0;i<tiles.size();i++) {
                    Tile t=tiles.get(i);
                    if(t.layer!=layer || tileRects[i]==null) continue;
                    drawTile(c,t.kind,tileRects[i],!isFree(i));
                    if(i==selectedTile) {
                        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(4); p.setColor(GOLD);
                        c.drawRoundRect(tileRects[i],10,10,p); p.setStyle(Paint.Style.FILL);
                    }
                }
            }
            if(dragging && dragTile>=0 && dragTile<tiles.size() && tileRects[dragTile]!=null) {
                RectF r=tileRects[dragTile];
                float dx=dragX-downX,dy=dragY-downY;
                RectF moving=new RectF(r.left+dx,r.top+dy,r.right+dx,r.bottom+dy);
                drawTile(c,tiles.get(dragTile).kind,moving,false);
            }

            String[] labels={"Nowa gra","Cofnij ("+undos+")","Podpowiedź","Pauza","Poziom"};
            float bw=w*.176f,bh=h*.055f,space=(w-5*bw)/6f,by=h*.84f;
            for(int i=0;i<5;i++) {
                float x=space+i*(bw+space); buttons[i]=new RectF(x,by-bh/2,x+bw,by+bh/2);
                p.setColor(CREAM); c.drawRoundRect(buttons[i],12,12,p);
                p.setColor(INK); p.setTextAlign(Paint.Align.CENTER); p.setTextSize(Math.min(w*.028f,19));
                c.drawText(labels[i],x+bw/2,by+bh*.12f,p);
            }

            if(paused || showDifficulty || pairs==pairTarget()) {
                p.setColor(0xB8000000); c.drawRect(0,0,w,h,p);
                p.setColor(CREAM); p.setTextAlign(Paint.Align.CENTER); p.setTextSize(Math.min(w*.065f,40));
                c.drawText(paused?"Pauza":showDifficulty?"Wybierz poziom":"Wygrana!",w/2,h*.42f,p);
                if(showDifficulty) {
                    String[] names={"Łatwy","Normalny","Trudny"},desc={"12 par","16 par","20 par"};
                    for(int d=0;d<3;d++) {
                        float dbw=w*.78f,dbh=h*.065f,dx=(w-dbw)/2f,dy=h*.46f+d*h*.085f;
                        levelRects[d]=new RectF(dx,dy,dx+dbw,dy+dbh);
                        p.setColor(d==difficulty?Color.rgb(20,115,82):CREAM);
                        c.drawRoundRect(levelRects[d],14,14,p);
                        p.setColor(d==difficulty?Color.WHITE:INK); p.setTextSize(Math.min(w*.043f,26));
                        c.drawText(names[d]+" — "+desc[d],w/2,dy+dbh*.62f,p);
                    }
                } else {
                    p.setTextSize(Math.min(w*.04f,25));
                    c.drawText(paused?"Dotknij, aby wrócić":"Świetna gra!",w/2,h*.52f,p);
                }
            }
        }

        @Override public boolean onTouchEvent(MotionEvent e) {
            float x=e.getX(), y=e.getY();
            if(e.getAction()==MotionEvent.ACTION_DOWN) {
                downX=x; downY=y; dragX=x; dragY=y; dragging=false; dragTile=-1; touchedRackSlot=-1;
                if(paused || showDifficulty || pairs==pairTarget()) return true;
                for(int b=0;b<5;b++) if(buttons[b]!=null && buttons[b].contains(x,y)) return true;
                for(int slot=0;slot<rack.size();slot++) {
                    if(rackRects[slot]!=null && rackRects[slot].contains(x,y)) {
                        touchedRackSlot=slot;
                        return true;
                    }
                }
                for(int i=tiles.size()-1;i>=0;i--) {
                    if(tileRects[i]!=null && tileRects[i].contains(x,y)) { dragTile=i; return true; }
                }
                return true;
            }
            if(e.getAction()==MotionEvent.ACTION_MOVE) {
                if(dragTile>=0 && !paused && !showDifficulty && pairs!=pairTarget()) {
                    dragX=x; dragY=y;
                    if(Math.hypot(x-downX,y-downY)>10) dragging=true;
                    invalidate();
                }
                return true;
            }
            if(e.getAction()!=MotionEvent.ACTION_UP) return true;

            if(paused) { paused=false; message="Gra wznowiona"; invalidate(); return true; }
            if(showDifficulty) {
                for(int d=0;d<3;d++) if(levelRects[d]!=null&&levelRects[d].contains(x,y)) {
                    difficulty=d; newGame(); return true;
                }
                showDifficulty=false; invalidate(); return true;
            }
            if(pairs==pairTarget()) { newGame(); return true; }

            for(int b=0;b<5;b++) if(buttons[b]!=null&&buttons[b].contains(x,y)) {
                switch(b) {
                    case 0: newGame(); break;
                    case 1: undo(); break;
                    case 2: hint(); break;
                    case 3: paused=true; message="Pauza"; invalidate(); break;
                    case 4: showDifficulty=true; invalidate(); break;
                }
                dragTile=-1; dragging=false;
                return true;
            }

            boolean droppedInTray=false;
            for(int slot=0;slot<5;slot++)
                if(rackRects[slot]!=null && rackRects[slot].contains(x,y)) { droppedInTray=true; break; }

            // Tap a board tile, then tap its matching tile in the rack to clear the pair.
            if(touchedRackSlot>=0 && !dragging && selectedTile>=0 && touchedRackSlot<rack.size()) {
                int rackTile=rack.get(touchedRackSlot);
                if(isFree(selectedTile) && tiles.get(selectedTile).kind==tiles.get(rackTile).kind) {
                    saveUndo();
                    tiles.get(selectedTile).removed=true;
                    rack.remove(touchedRackSlot);
                    tiles.get(rackTile).removed=true;
                    selectedTile=-1;
                    pairs++; moves++;
                    message=pairs==pairTarget()?"Wygrana!":"Para znaleziona — miejsce zwolnione";
                } else {
                    message="To nie para — wybierz taki sam kafelek";
                }
                dragTile=-1; dragging=false; touchedRackSlot=-1; invalidate();
                return true;
            }

            if(dragTile>=0 && dragging && droppedInTray) {
                if(isFree(dragTile)) chooseTile(dragTile);
                else { message="Kafelek zablokowany"; invalidate(); }
            } else if(dragTile>=0 && !dragging) {
                if(!isFree(dragTile)) {
                    message="Kafelek zablokowany";
                } else if(selectedTile<0) {
                    selectedTile=dragTile;
                    message="Wybierz pasujący kafelek";
                } else if(selectedTile==dragTile) {
                    selectedTile=-1;
                    message="Wybierz dwa takie same kafelki";
                } else if(tiles.get(selectedTile).kind==tiles.get(dragTile).kind && isFree(selectedTile)) {
                    saveUndo();
                    tiles.get(selectedTile).removed=true;
                    tiles.get(dragTile).removed=true;
                    selectedTile=-1;
                    pairs++; moves++;
                    message=pairs==pairTarget()?"Wygrana!":"Para znaleziona";
                } else {
                    selectedTile=dragTile;
                    message="To nie para — wybierz pasujący kafelek";
                }
                invalidate();
            }
            dragTile=-1; dragging=false; touchedRackSlot=-1; invalidate();
            return true;
        }
    }
}
