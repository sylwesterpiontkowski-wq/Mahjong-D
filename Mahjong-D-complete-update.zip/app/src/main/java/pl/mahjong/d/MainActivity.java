package pl.mahjong.d;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.view.*;
import java.io.InputStream;
import java.util.*;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) { super.onCreate(b); getWindow().setStatusBarColor(Color.rgb(32,48,39)); getWindow().setNavigationBarColor(Color.rgb(32,48,39)); setContentView(new GameView()); }

    class Tile {
        int kind; boolean removed;
        Tile(int k){kind=k;}
    }
    class GameView extends View {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        ArrayList<Tile> tiles = new ArrayList<>();
        ArrayList<int[]> history = new ArrayList<>();
        Bitmap[] cats = new Bitmap[2];
        int selected=-1, moves=0, pairs=0, difficulty=1, undos=5;
        boolean paused=false, showDifficulty=false;
        String message="Wybierz dwie takie same płytki";
        String[] symbols={"一","二","三","四","五","六","七","八","九","東","南","西","北","中","發","白"};
        RectF[] tileRects=new RectF[32], buttons=new RectF[5];
        final int BG=Color.rgb(16,100,76), CREAM=Color.rgb(248,239,210), INK=Color.rgb(35,54,74), GOLD=Color.rgb(225,184,91);
        GameView(){
            super(MainActivity.this);
            setLayerType(View.LAYER_TYPE_SOFTWARE,null);
            try { cats[0]=loadAsset("cat_rudy.jpg"); cats[1]=loadAsset("cat_nr2.jpg"); } catch(Exception ignored){}
            newGame();
        }
        Bitmap loadAsset(String n)throws Exception { InputStream s=getAssets().open(n); Bitmap b=BitmapFactory.decodeStream(s); s.close(); return b; }
        void newGame(){
            tiles.clear(); ArrayList<Integer> kinds=new ArrayList<>();
            int count=difficulty==0?12:difficulty==1?16:16;
            for(int i=0;i<count;i++){kinds.add(i);kinds.add(i);}
            Collections.shuffle(kinds);
            for(int k:kinds) tiles.add(new Tile(k));
            selected=-1;moves=0;pairs=0;undos=5;paused=false;showDifficulty=false;history.clear();
            message="Wybierz dwie takie same płytki"; invalidate();
        }
        void saveUndo(){ int[] s=new int[tiles.size()+3];s[0]=selected;s[1]=moves;s[2]=pairs;for(int i=0;i<tiles.size();i++)s[i+3]=tiles.get(i).removed?1:0;history.add(s);if(history.size()>5)history.remove(0);}
        void undo(){if(history.isEmpty()||undos<=0){message="Brak cofnięć";invalidate();return;}int[]s=history.remove(history.size()-1);selected=s[0];moves=s[1];pairs=s[2];for(int i=0;i<tiles.size();i++)tiles.get(i).removed=s[i+3]==1;undos--;message="Cofnięto ostatni ruch";invalidate();}
        void hint(){for(int i=0;i<tiles.size();i++)if(!tiles.get(i).removed)for(int j=i+1;j<tiles.size();j++)if(!tiles.get(j).removed&&tiles.get(i).kind==tiles.get(j).kind){selected=i;message="Podpowiedź: podświetlono płytkę";invalidate();return;}message="Brak dostępnej pary";invalidate();}
        @Override protected void onDraw(Canvas c){
            float w=getWidth(),h=getHeight();
            p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(37,20,12));c.drawRect(0,0,w,h,p);
            p.setColor(Color.rgb(53,29,17));c.drawRect(0,0,w,h*.14f,p);
            p.setColor(BG);c.drawRect(0,h*.14f,w,h*.86f,p);
            p.setColor(Color.rgb(29,49,36));c.drawRect(0,h*.86f,w,h,p);
            p.setColor(CREAM);p.setTextAlign(Paint.Align.LEFT);p.setFakeBoldText(true);p.setTextSize(Math.min(w*.065f,42));c.drawText("Mahjong D",w*.04f,h*.075f,p);p.setFakeBoldText(false);
            p.setTextAlign(Paint.Align.RIGHT);p.setTextSize(Math.min(w*.031f,22));c.drawText(difficulty==0?"ŁATWY":difficulty==1?"NORMALNY":"TRUDNY",w*.96f,h*.055f,p);c.drawText("Pary: "+pairs+"/"+(difficulty==0?12:16)+"   Ruchy: "+moves,w*.96f,h*.105f,p);
            p.setTextAlign(Paint.Align.CENTER);p.setTextSize(Math.min(w*.032f,22));c.drawText(message,w/2,h*.19f,p);
            int n=tiles.size(),cols=8,rows=n/cols;float gap=w*.018f,tw=(w-gap*(cols+1))/cols,th=Math.min(tw*1.14f,h*.125f);
            float boardH=rows*th+(rows-1)*gap,top=h*.24f+Math.max(0,(h*.56f-boardH)*.5f);
            for(int i=0;i<n;i++){tileRects[i]=null;Tile t=tiles.get(i);if(t.removed)continue;
                int row=i/cols,col=i%cols;float x=gap+col*(tw+gap),y=top+row*(th+gap);
                // soft shadow and raised ivory tile
                p.setColor(Color.rgb(8,47,35));c.drawRoundRect(new RectF(x+2,y+5,x+tw+2,y+th+5),10,10,p);
                p.setColor(i==selected?GOLD:CREAM);c.drawRoundRect(new RectF(x,y,x+tw,y+th),10,10,p);
                p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2);p.setColor(Color.rgb(151,111,62));c.drawRoundRect(new RectF(x+4,y+4,x+tw-4,y+th-4),7,7,p);p.setStyle(Paint.Style.FILL);
                if(t.kind<2 && cats[t.kind]!=null){
                    RectF dst=new RectF(x+tw*.10f,y+th*.08f,x+tw*.90f,y+th*.92f);
                    c.save();Path clip=new Path();clip.addRoundRect(dst,6,6,Path.Direction.CW);c.clipPath(clip);c.drawBitmap(cats[t.kind],null,dst,p);c.restore();
                } else {
                    p.setTextAlign(Paint.Align.CENTER);p.setTextSize(Math.min(tw*.48f,42));p.setFakeBoldText(true);
                    p.setColor(t.kind==13?Color.rgb(180,35,35):t.kind==14?Color.rgb(20,115,62):INK);
                    c.drawText(symbols[t.kind],x+tw/2,y+th*.62f,p);p.setFakeBoldText(false);
                    p.setColor(Color.rgb(151,111,62));p.setTextSize(Math.min(tw*.12f,12));c.drawText("✦",x+tw/2,y+th*.84f,p);
                }
                tileRects[i]=new RectF(x,y,x+tw,y+th);
            }
            String[] labels={"Nowa gra","Cofnij","Podpowiedź","Pauza","Poziom"};
            float bw=w*.176f,bh=h*.065f,space=(w-5*bw)/6f,by=h*.90f;
            for(int i=0;i<5;i++){float x=space+i*(bw+space);buttons[i]=new RectF(x,by-bh/2,x+bw,by+bh/2);p.setColor(CREAM);c.drawRoundRect(buttons[i],12,12,p);p.setColor(INK);p.setTextAlign(Paint.Align.CENTER);p.setTextSize(Math.min(w*.028f,19));c.drawText(labels[i],x+bw/2,by+bh*.12f,p);}
            if(paused||showDifficulty||pairs==(difficulty==0?12:16)){p.setColor(0xB8000000);c.drawRect(0,0,w,h,p);p.setColor(CREAM);p.setTextAlign(Paint.Align.CENTER);p.setTextSize(Math.min(w*.065f,40));c.drawText(paused?"Pauza":showDifficulty?"Wybierz poziom":"Wygrana!",w/2,h*.45f,p);p.setTextSize(Math.min(w*.04f,25));c.drawText(paused?"Dotknij, aby wrócić":showDifficulty?"Łatwy   Normalny   Trudny":"Świetna gra!",w/2,h*.52f,p);}
        }
        @Override public boolean onTouchEvent(android.view.MotionEvent e){
            if(e.getAction()!=MotionEvent.ACTION_UP)return true;float x=e.getX(),y=e.getY(),w=getWidth(),h=getHeight();
            if(paused){paused=false;message="Gra wznowiona";invalidate();return true;}
            if(showDifficulty){difficulty=x<w/3?0:x<2*w/3?1:2;newGame();return true;}
            if(pairs==(difficulty==0?12:16)){newGame();return true;}
            for(int b=0;b<5;b++)if(buttons[b]!=null&&buttons[b].contains(x,y)){switch(b){case 0:newGame();break;case 1:undo();break;case 2:hint();break;case 3:paused=true;message="Pauza";invalidate();break;case 4:showDifficulty=true;invalidate();break;}return true;}
            for(int i=0;i<tiles.size();i++)if(tileRects[i]!=null&&tileRects[i].contains(x,y)){
                if(selected<0||selected==i){selected=i;message="Wybierz pasującą płytkę";invalidate();return true;}
                if(tiles.get(selected).kind==tiles.get(i).kind){saveUndo();tiles.get(selected).removed=true;tiles.get(i).removed=true;pairs++;moves++;selected=-1;message=pairs==(difficulty==0?12:16)?"Wygrana!":"Dobra para!";}else{moves++;selected=i;message="To nie para — spróbuj ponownie";}
                invalidate();return true;
            }
            return true;
        }
    }
}
