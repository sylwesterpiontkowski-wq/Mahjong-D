plugins {
    id("com.android.application")
}

android {
    namespace = "pl.mahjong.d"
    compileSdk = 35

    defaultConfig {
        applicationId = "pl.mahjong.d"
        minSdk = 23
        targetSdk = 28
        versionCode = 1
        versionName = "1.0"
    }
}
